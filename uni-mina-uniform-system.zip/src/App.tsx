import { useState } from 'react';
import { AuthProvider, useAuth } from '@/contexts/AuthContext';
import LoginPage from '@/pages/LoginPage';
import AdminLayout from '@/components/layout/AdminLayout';
import DashboardPage from '@/pages/DashboardPage';
import PedidosPage from '@/pages/PedidosPage';
import ListaEsperaPage from '@/pages/ListaEsperaPage';
import FuncionariosPage from '@/pages/FuncionariosPage';
import FichaCadastralPage from '@/pages/FichaCadastralPage';
import ASOPage from '@/pages/ASOPage';
import TreinamentosPage from '@/pages/TreinamentosPage';
import EstoquePage from '@/pages/EstoquePage';
import RelatoriosPage from '@/pages/RelatoriosPage';
import ConfiguracoesPage from '@/pages/ConfiguracoesPage';
import SupervisorPage from '@/pages/SupervisorPage';

function AppContent() {
  const { isAuthenticated, user } = useAuth();
  const [currentPage, setCurrentPage] = useState('dashboard');

  if (!isAuthenticated) {
    return <LoginPage />;
  }

  // Supervisor gets mobile-first interface
  if (user?.role === 'supervisor') {
    return <SupervisorPage />;
  }

  // Admin gets full dashboard
  const renderPage = () => {
    switch (currentPage) {
      case 'dashboard': return <DashboardPage />;
      case 'pedidos': return <PedidosPage />;
      case 'lista-espera': return <ListaEsperaPage />;
      case 'funcionarios': return <FuncionariosPage />;
      case 'ficha-cadastral': return <FichaCadastralPage />;
      case 'asos': return <ASOPage />;
      case 'treinamentos': return <TreinamentosPage />;
      case 'estoque': return <EstoquePage />;
      case 'relatorios': return <RelatoriosPage />;
      case 'configuracoes': return <ConfiguracoesPage />;
      default: return <DashboardPage />;
    }
  };

  return (
    <AdminLayout currentPage={currentPage} onNavigate={setCurrentPage}>
      {renderPage()}
    </AdminLayout>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}
