import { useMemo, useState } from 'react';
import {
  Activity,
  AlertTriangle,
  Building2,
  CalendarDays,
  ClipboardList,
  DollarSign,
  GraduationCap,
  Package,
  TrendingUp,
  Truck,
  Users,
} from 'lucide-react';
import { Bar, BarChart, CartesianGrid, Cell, Legend, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import StatCard from '@/components/ui/StatCard';
import Badge from '@/components/ui/Badge';
import Modal from '@/components/ui/Modal';
import { getASOs, getEntregas, getEstoque, getFuncionarios, getPedidos, getRegistrosCadastrais, getTreinamentos } from '@/data/store';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { getSSTStatus, getSSTStatusVariant } from '@/utils/sst';
import type { StatusSaudeSeguranca } from '@/types';
import { getAge, getDateDay, getDateMonth, parseFlexibleDate } from '@/utils/dates';

const COLORS = ['#7b1c16', '#a12a21', '#d55242', '#5f1511', '#c23b2e', '#8f2a22'];
const SST_STATUS: StatusSaudeSeguranca[] = ['Em dia', 'A vencer', 'Vencido', 'Pendente'];

type DetailTable = {
  title: string;
  description?: string;
  columns: string[];
  rows: (string | number)[][];
};

const money = (value: number) => value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

const date = (value: string) => {
  if (!value) return '-';
  const parsed = new Date(value);
  if (Number.isNaN(parsed.getTime())) return '-';
  return format(parsed, 'dd/MM/yyyy', { locale: ptBR });
};

export default function DashboardPage() {
  const [detail, setDetail] = useState<DetailTable | null>(null);

  const data = useMemo(() => {
    const funcionarios = getFuncionarios();
    const pedidos = getPedidos();
    const estoque = getEstoque();
    const entregas = getEntregas();
    const asos = getASOs();
    const treinamentos = getTreinamentos();
    const registros = getRegistrosCadastrais();
    const currentMonth = new Date().getMonth() + 1;

    const funcionariosAtivos = funcionarios.filter(f => f.situacao === 'Ativo');
    const pedidosPendentes = pedidos.filter(p => p.status === 'Pendente');
    const estoqueCritico = estoque.filter(e => e.quantidadeAtual <= e.estoqueMinimo && e.status === 'Ativo');
    const requisicoes = pedidos.filter(p => p.status === 'Aprovado' || p.status === 'Entregue');
    const asosComStatus = asos.map(aso => ({ ...aso, sstStatus: getSSTStatus(aso.validade) }));
    const treinamentosComStatus = treinamentos.map(treinamento => ({ ...treinamento, sstStatus: getSSTStatus(treinamento.validade) }));
    const asosCriticos = asosComStatus.filter(a => a.sstStatus !== 'Em dia');
    const treinamentosCriticos = treinamentosComStatus.filter(t => t.sstStatus !== 'Em dia');

    const entregasDetalhadas = entregas.flatMap(entrega =>
      entrega.itens.map(item => {
        const estoqueItem = estoque.find(e => e.id === item.itemEstoqueId);
        const custo = (estoqueItem?.custoUnitario || 0) * item.quantidade;
        return { entrega, item, custo };
      })
    );

    const custoEntregas = entregasDetalhadas.reduce((sum, item) => sum + item.custo, 0);
    const requisicoesDetalhadas = requisicoes.map(pedido => ({
      pedido,
      custo: pedido.itens.reduce((sum, item) => sum + item.custoUnitario * item.quantidade, 0),
    }));
    const custoRequisicoes = requisicoesDetalhadas.reduce((sum, item) => sum + item.custo, 0);

    const custoPorCC: Record<string, number> = {};
    entregasDetalhadas.forEach(({ entrega, custo }) => {
      const cc = entrega.centroCusto || 'N/A';
      custoPorCC[cc] = (custoPorCC[cc] || 0) + custo;
    });
    const custoCCData = Object.entries(custoPorCC).map(([name, value]) => ({ name, value }));
    const maiorCC = custoCCData.length > 0 ? custoCCData.reduce((a, b) => a.value > b.value ? a : b).name : 'N/A';

    const statusCount: Record<string, number> = {};
    pedidos.forEach(p => { statusCount[p.status] = (statusCount[p.status] || 0) + 1; });
    const statusData = Object.entries(statusCount).map(([name, value]) => ({ name, value }));

    const custoPorTurno: Record<string, number> = {};
    pedidos.forEach(p => {
      const custo = p.itens.reduce((sum, item) => sum + item.custoUnitario * item.quantidade, 0);
      custoPorTurno[`Turno ${p.turno}`] = (custoPorTurno[`Turno ${p.turno}`] || 0) + custo;
    });
    const custoTurnoData = Object.entries(custoPorTurno).map(([name, value]) => ({ name, value }));

    const asoStatusData = SST_STATUS.map(status => ({
      name: status,
      value: asosComStatus.filter(aso => aso.sstStatus === status).length,
    }));
    const treinamentoStatusData = SST_STATUS.map(status => ({
      name: status,
      value: treinamentosComStatus.filter(treinamento => treinamento.sstStatus === status).length,
    }));

    const ultimasEntregas = [...entregas].sort((a, b) =>
      new Date(b.dataEntrega).getTime() - new Date(a.dataEntrega).getTime()
    ).slice(0, 5);

    const proximosASO = [...asosCriticos].sort((a, b) => new Date(a.validade).getTime() - new Date(b.validade).getTime()).slice(0, 6);
    const proximosTreinamentos = [...treinamentosCriticos].sort((a, b) => new Date(a.validade).getTime() - new Date(b.validade).getTime()).slice(0, 6);
    const aniversariantesMes = registros
      .filter(registro => getDateMonth(registro.dataNascimento) === currentMonth)
      .sort((a, b) => (getDateDay(a.dataNascimento) || 99) - (getDateDay(b.dataNascimento) || 99));

    return {
      funcionariosAtivos,
      pedidosPendentes,
      estoqueCritico,
      custoEntregas,
      entregasDetalhadas,
      requisicoes,
      requisicoesDetalhadas,
      custoRequisicoes,
      custoTotal: custoEntregas + custoRequisicoes,
      maiorCC,
      custoCCData,
      statusData,
      custoTurnoData,
      ultimasEntregas,
      asosComStatus,
      treinamentosComStatus,
      asosCriticos,
      treinamentosCriticos,
      asoStatusData,
      treinamentoStatusData,
      proximosASO,
      proximosTreinamentos,
      aniversariantesMes,
    };
  }, []);

  const openFuncionarios = () => setDetail({
    title: 'Funcionários Ativos',
    description: 'Colaboradores ativos considerados nos indicadores do SST.',
    columns: ['Matrícula', 'Nome', 'Gerência', 'Turno', 'Centro de Custo', 'Função'],
    rows: data.funcionariosAtivos.map(f => [f.matricula, f.nome, f.gerencia, f.turno, f.centroCusto, f.funcao]),
  });

  const openPedidos = (status?: string) => {
    const pedidos = status ? data.pedidosPendentes.filter(p => p.status === status) : data.pedidosPendentes;
    setDetail({
      title: status ? `Pedidos ${status}` : 'Pedidos Pendentes',
      columns: ['Pedido', 'Colaborador', 'Centro de Custo', 'Itens', 'Solicitado em', 'Status'],
      rows: pedidos.map(p => [
        p.numero,
        p.funcionarioNome,
        p.centroCusto,
        p.itens.map(item => `${item.descricao} (${item.tamanho}) x${item.quantidade}`).join(', '),
        date(p.dataSolicitacao),
        p.status,
      ]),
    });
  };

  const openEstoqueCritico = () => setDetail({
    title: 'Estoque Crítico',
    description: 'Itens ativos com saldo menor ou igual ao estoque mínimo.',
    columns: ['Código', 'Descrição', 'Categoria', 'Tamanho', 'Saldo', 'Mínimo', 'Status'],
    rows: data.estoqueCritico.map(item => [
      item.codigo,
      item.descricao,
      item.categoria,
      item.tamanho,
      item.quantidadeAtual,
      item.estoqueMinimo,
      item.quantidadeAtual === 0 ? 'Sem estoque' : 'Baixo',
    ]),
  });

  const openEntregas = () => setDetail({
    title: 'Entregas Realizadas',
    columns: ['Data', 'Pedido', 'Colaborador', 'Centro de Custo', 'Item', 'Tamanho', 'Qtd', 'Custo'],
    rows: data.entregasDetalhadas.map(({ entrega, item, custo }) => [
      date(entrega.dataEntrega),
      entrega.numeroPedido,
      entrega.funcionarioNome,
      entrega.centroCusto,
      item.descricao,
      item.tamanho,
      item.quantidade,
      money(custo),
    ]),
  });

  const openRequisicoes = () => setDetail({
    title: 'Requisições ao Depósito',
    columns: ['Pedido', 'Colaborador', 'Centro de Custo', 'Itens', 'Status', 'Solicitado em', 'Custo'],
    rows: data.requisicoesDetalhadas.map(({ pedido, custo }) => [
      pedido.numero,
      pedido.funcionarioNome,
      pedido.centroCusto,
      pedido.itens.map(item => `${item.descricao} x${item.quantidade}`).join(', '),
      pedido.status,
      date(pedido.dataSolicitacao),
      money(custo),
    ]),
  });

  const openMaiorCC = () => setDetail({
    title: `Maior Centro de Custo: ${data.maiorCC}`,
    columns: ['Data', 'Pedido', 'Colaborador', 'Item', 'Qtd', 'Custo'],
    rows: data.entregasDetalhadas
      .filter(({ entrega }) => entrega.centroCusto === data.maiorCC)
      .map(({ entrega, item, custo }) => [date(entrega.dataEntrega), entrega.numeroPedido, entrega.funcionarioNome, item.descricao, item.quantidade, money(custo)]),
  });

  const openASO = (status?: StatusSaudeSeguranca, onlyCritical = false) => {
    const records = data.asosComStatus.filter(aso => {
      if (status) return aso.sstStatus === status;
      if (onlyCritical) return aso.sstStatus !== 'Em dia';
      return true;
    });
    setDetail({
      title: status ? `ASO - ${status}` : onlyCritical ? 'ASO a Tratar' : 'Todos os ASOs',
      columns: ['Colaborador', 'Matrícula', 'Tipo', 'Validade', 'Aptidão', 'Status', 'Centro de Custo'],
      rows: records.map(aso => [aso.funcionarioNome, aso.funcionarioMatricula, aso.tipo, date(aso.validade), aso.aptidao, aso.sstStatus, aso.centroCusto]),
    });
  };

  const openTreinamentos = (status?: StatusSaudeSeguranca, onlyCritical = false) => {
    const records = data.treinamentosComStatus.filter(treinamento => {
      if (status) return treinamento.sstStatus === status;
      if (onlyCritical) return treinamento.sstStatus !== 'Em dia';
      return true;
    });
    setDetail({
      title: status ? `Treinamentos - ${status}` : onlyCritical ? 'Treinamentos a Tratar' : 'Todos os Treinamentos',
      columns: ['Colaborador', 'Matrícula', 'Treinamento', 'NR', 'Validade', 'Status', 'Centro de Custo'],
      rows: records.map(t => [t.funcionarioNome, t.funcionarioMatricula, t.curso, t.norma, date(t.validade), t.sstStatus, t.centroCusto]),
    });
  };

  const openCustoTotal = () => setDetail({
    title: 'Custo Total Geral',
    description: 'Composição do custo geral por entregas efetivadas e requisições aprovadas/entregues.',
    columns: ['Origem', 'Referência', 'Colaborador', 'Centro de Custo', 'Descrição', 'Custo'],
    rows: [
      ...data.entregasDetalhadas.map(({ entrega, item, custo }) => ['Entrega', entrega.numeroPedido, entrega.funcionarioNome, entrega.centroCusto, item.descricao, money(custo)]),
      ...data.requisicoesDetalhadas.map(({ pedido, custo }) => ['Requisição', pedido.numero, pedido.funcionarioNome, pedido.centroCusto, pedido.itens.map(item => item.descricao).join(', '), money(custo)]),
    ],
  });

  const openAniversariantes = () => setDetail({
    title: 'Aniversariantes do Mês',
    description: 'Colaboradores cadastrados na ficha de registro com aniversário no mês atual.',
    columns: ['Dia', 'Nome', 'Como prefere ser chamado', 'Cargo', 'Telefone', 'Idade', 'Contato de Emergência'],
    rows: data.aniversariantesMes.map(registro => [
      getDateDay(registro.dataNascimento)?.toString().padStart(2, '0') || '-',
      registro.nome,
      registro.nomeSocial,
      registro.cargo,
      registro.telefone,
      getAge(registro.dataNascimento)?.toString() || '-',
      registro.contatoEmergencia,
    ]),
  });

  return (
    <div className="space-y-6">
      <div className="bg-[#f8e9e6] border border-[#e4c5bf] rounded-xl p-4">
        <p className="text-sm font-medium text-[#7b1c16]">Dashboard interativo</p>
        <p className="text-sm text-[#8b1e18]">Clique nos cards, status de SST e linhas destacadas para abrir os detalhes operacionais de ASO, treinamentos, uniformes e custos.</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard title="Funcionários Ativos" value={data.funcionariosAtivos.length} icon={Users} color="blue" onClick={openFuncionarios} />
        <StatCard title="Pedidos Pendentes" value={data.pedidosPendentes.length} icon={ClipboardList} color="amber" onClick={() => openPedidos()} />
        <StatCard title="Estoque Crítico" value={data.estoqueCritico.length} icon={AlertTriangle} color="red" onClick={openEstoqueCritico} />
        <StatCard title="Custo Total Entregas" value={money(data.custoEntregas)} icon={DollarSign} color="green" onClick={openEntregas} />
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard title="Requisições ao Depósito" value={data.requisicoes.length} icon={Truck} color="purple" onClick={openRequisicoes} />
        <StatCard title="Custo Requisições" value={money(data.custoRequisicoes)} icon={TrendingUp} color="indigo" onClick={openRequisicoes} />
        <StatCard title="Custo Total Geral" value={money(data.custoTotal)} icon={Package} color="teal" onClick={openCustoTotal} />
        <StatCard title="Maior Centro de Custo" value={data.maiorCC} icon={Building2} color="orange" onClick={openMaiorCC} />
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard title="ASO a Tratar" value={data.asosCriticos.length} icon={Activity} color="red" subtitle="Vencidos, pendentes ou próximos de vencer" onClick={() => openASO(undefined, true)} />
        <StatCard title="Treinamentos a Tratar" value={data.treinamentosCriticos.length} icon={GraduationCap} color="amber" subtitle="Vencidos, pendentes ou próximos de vencer" onClick={() => openTreinamentos(undefined, true)} />
        <StatCard title="Aniversariantes do Mês" value={data.aniversariantesMes.length} icon={CalendarDays} color="orange" subtitle="Com base na ficha de registro" onClick={openAniversariantes} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl border border-gray-200 p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-base font-semibold text-gray-800">Status dos Pedidos</h3>
            <button onClick={() => openPedidos()} className="text-xs font-medium text-[#8b1e18] hover:text-[#5f1511]">Detalhar pendentes</button>
          </div>
          <ResponsiveContainer width="100%" height={280}>
            <PieChart>
              <Pie data={data.statusData} cx="50%" cy="50%" outerRadius={100} dataKey="value" label={({ name, value }) => `${name}: ${value}`}>
                {data.statusData.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
              </Pie>
              <Tooltip />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-white rounded-xl border border-gray-200 p-5">
          <h3 className="text-base font-semibold text-gray-800 mb-4">Custo por Centro de Custo</h3>
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={data.custoCCData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey="name" tick={{ fontSize: 12 }} />
              <YAxis tick={{ fontSize: 12 }} />
              <Tooltip formatter={(value) => money(Number(value))} />
              <Bar dataKey="value" fill="#8b1e18" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-white rounded-xl border border-gray-200 p-5">
          <h3 className="text-base font-semibold text-gray-800 mb-4">Custo por Turno</h3>
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={data.custoTurnoData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey="name" tick={{ fontSize: 12 }} />
              <YAxis tick={{ fontSize: 12 }} />
              <Tooltip formatter={(value) => money(Number(value))} />
              <Bar dataKey="value" fill="#d55242" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-white rounded-xl border border-gray-200 p-5">
          <h3 className="text-base font-semibold text-gray-800 mb-4">Últimas Entregas</h3>
          {data.ultimasEntregas.length === 0 ? (
            <p className="text-gray-400 text-sm">Nenhuma entrega registrada.</p>
          ) : (
            <div className="space-y-3">
              {data.ultimasEntregas.map(ent => (
                <button key={ent.id} onClick={openEntregas} className="w-full flex items-center justify-between p-3 bg-gray-50 hover:bg-[#f8e9e6] rounded-xl text-left transition-colors">
                  <div>
                    <p className="text-sm font-medium text-gray-800">{ent.funcionarioNome}</p>
                    <p className="text-xs text-gray-500">{ent.itens.map(i => `${i.descricao} (${i.tamanho})`).join(', ')}</p>
                  </div>
                  <div className="text-right">
                    <Badge variant="success">Entregue</Badge>
                    <p className="text-xs text-gray-400 mt-1">{date(ent.dataEntrega)}</p>
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <SSTStatusPanel title="ASO por Status" data={data.asoStatusData} onClick={status => openASO(status)} />
        <SSTStatusPanel title="Treinamentos por Status" data={data.treinamentoStatusData} onClick={status => openTreinamentos(status)} />
      </div>

      <div className="bg-white rounded-xl border border-gray-200 p-5">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-base font-semibold text-gray-800">Aniversariantes do Mês</h3>
          <button onClick={openAniversariantes} className="text-xs font-medium text-[#8b1e18] hover:text-[#5f1511]">Ver relatório</button>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3">
          {data.aniversariantesMes.map(registro => {
            const parsed = parseFlexibleDate(registro.dataNascimento);
            return (
              <button key={registro.id} onClick={openAniversariantes} className="flex items-center gap-3 rounded-xl bg-gray-50 hover:bg-[#f8e9e6] p-3 text-left transition-colors">
                <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-[#7b1c16] text-white font-bold">
                  {getDateDay(registro.dataNascimento)?.toString().padStart(2, '0') || '--'}
                </div>
                <div className="min-w-0">
                  <p className="truncate text-sm font-semibold text-gray-800">{registro.nome}</p>
                  <p className="text-xs text-gray-500">{registro.cargo || 'Cargo não informado'}</p>
                  <p className="text-xs text-gray-400">{parsed ? format(parsed, 'dd/MM', { locale: ptBR }) : '-'}</p>
                </div>
              </button>
            );
          })}
          {data.aniversariantesMes.length === 0 && (
            <div className="rounded-xl bg-gray-50 p-4 text-sm text-gray-400">Nenhum aniversariante cadastrado para este mês.</div>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl border border-gray-200 p-5">
          <h3 className="text-base font-semibold text-gray-800 mb-4">ASO - Próximas Ações</h3>
          <div className="space-y-2">
            {data.proximosASO.map(aso => (
              <button key={aso.id} onClick={() => openASO(aso.sstStatus)} className="w-full flex items-center justify-between p-3 bg-gray-50 hover:bg-[#f8e9e6] rounded-xl text-left transition-colors">
                <div>
                  <p className="text-sm font-medium text-gray-800">{aso.funcionarioNome}</p>
                  <p className="text-xs text-gray-500">{aso.tipo} | validade {date(aso.validade)}</p>
                </div>
                <Badge variant={getSSTStatusVariant(aso.sstStatus)}>{aso.sstStatus}</Badge>
              </button>
            ))}
            {data.proximosASO.length === 0 && <p className="text-sm text-gray-400">Nenhuma ação pendente.</p>}
          </div>
        </div>

        <div className="bg-white rounded-xl border border-gray-200 p-5">
          <h3 className="text-base font-semibold text-gray-800 mb-4">Treinamentos - Próximas Ações</h3>
          <div className="space-y-2">
            {data.proximosTreinamentos.map(treinamento => (
              <button key={treinamento.id} onClick={() => openTreinamentos(treinamento.sstStatus)} className="w-full flex items-center justify-between p-3 bg-gray-50 hover:bg-[#f8e9e6] rounded-xl text-left transition-colors">
                <div>
                  <p className="text-sm font-medium text-gray-800">{treinamento.funcionarioNome}</p>
                  <p className="text-xs text-gray-500">{treinamento.norma} - {treinamento.curso} | validade {date(treinamento.validade)}</p>
                </div>
                <Badge variant={getSSTStatusVariant(treinamento.sstStatus)}>{treinamento.sstStatus}</Badge>
              </button>
            ))}
            {data.proximosTreinamentos.length === 0 && <p className="text-sm text-gray-400">Nenhuma ação pendente.</p>}
          </div>
        </div>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 p-5">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-base font-semibold text-gray-800">Itens com Estoque Crítico</h3>
          <button onClick={openEstoqueCritico} className="text-xs font-medium text-[#8b1e18] hover:text-[#5f1511]">Ver detalhes</button>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-gray-200">
                <th className="text-left py-3 px-4 font-medium text-gray-500">Item</th>
                <th className="text-left py-3 px-4 font-medium text-gray-500">Tamanho</th>
                <th className="text-left py-3 px-4 font-medium text-gray-500">Atual</th>
                <th className="text-left py-3 px-4 font-medium text-gray-500">Mínimo</th>
                <th className="text-left py-3 px-4 font-medium text-gray-500">Status</th>
              </tr>
            </thead>
            <tbody>
              {data.estoqueCritico.map(item => (
                <tr key={item.id} onClick={openEstoqueCritico} className="border-b border-gray-100 hover:bg-[#f8e9e6] cursor-pointer">
                  <td className="py-3 px-4 font-medium text-gray-800">{item.descricao}</td>
                  <td className="py-3 px-4 text-gray-600">{item.tamanho}</td>
                  <td className="py-3 px-4"><span className={`font-bold ${item.quantidadeAtual === 0 ? 'text-red-600' : 'text-amber-600'}`}>{item.quantidadeAtual}</span></td>
                  <td className="py-3 px-4 text-gray-600">{item.estoqueMinimo}</td>
                  <td className="py-3 px-4"><Badge variant={item.quantidadeAtual === 0 ? 'danger' : 'warning'}>{item.quantidadeAtual === 0 ? 'Sem Estoque' : 'Baixo'}</Badge></td>
                </tr>
              ))}
              {data.estoqueCritico.length === 0 && <tr><td colSpan={5} className="py-8 text-center text-gray-400">Nenhum item crítico.</td></tr>}
            </tbody>
          </table>
        </div>
      </div>

      <Modal isOpen={!!detail} onClose={() => setDetail(null)} title={detail?.title || 'Detalhes'} size="xl">
        {detail && (
          <div className="space-y-4">
            {detail.description && <p className="text-sm text-gray-500">{detail.description}</p>}
            <div className="rounded-xl border border-gray-200 overflow-hidden">
              <div className="overflow-x-auto max-h-[60vh]">
                <table className="w-full text-sm">
                  <thead className="bg-gray-50 sticky top-0">
                    <tr>
                      {detail.columns.map(column => <th key={column} className="text-left py-3 px-4 font-medium text-gray-500 whitespace-nowrap">{column}</th>)}
                    </tr>
                  </thead>
                  <tbody>
                    {detail.rows.map((row, rowIndex) => (
                      <tr key={rowIndex} className="border-t border-gray-100 hover:bg-gray-50">
                        {row.map((cell, cellIndex) => <td key={cellIndex} className="py-3 px-4 text-gray-700 align-top">{cell}</td>)}
                      </tr>
                    ))}
                    {detail.rows.length === 0 && <tr><td colSpan={detail.columns.length} className="py-10 text-center text-gray-400">Nenhum registro encontrado.</td></tr>}
                  </tbody>
                </table>
              </div>
            </div>
            <p className="text-xs text-gray-400">Total de registros: {detail.rows.length}</p>
          </div>
        )}
      </Modal>
    </div>
  );
}

function SSTStatusPanel({ title, data, onClick }: { title: string; data: { name: string; value: number }[]; onClick: (status: StatusSaudeSeguranca) => void }) {
  return (
    <div className="bg-white rounded-xl border border-gray-200 p-5">
      <h3 className="text-base font-semibold text-gray-800 mb-4">{title}</h3>
      <div className="space-y-2">
        {data.map(item => {
          const status = item.name as StatusSaudeSeguranca;
          return (
            <button key={item.name} onClick={() => onClick(status)} className="w-full flex items-center justify-between p-3 bg-gray-50 hover:bg-[#f8e9e6] rounded-xl transition-colors text-left">
              <div className="flex items-center gap-3">
                <Badge variant={getSSTStatusVariant(status)}>{item.name}</Badge>
                <span className="text-sm text-gray-500">Clique para detalhar</span>
              </div>
              <span className="text-lg font-bold text-gray-800">{item.value}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}