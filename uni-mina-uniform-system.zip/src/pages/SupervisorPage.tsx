import { useState, useMemo } from 'react';
import { v4 as uuid } from 'uuid';
import { Plus, Trash2, Send, LogOut, History, AlertCircle, CheckCircle } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { getFuncionarios, getEstoque, getEntregas, getPedidos, savePedidos, getNextPedidoNumber, getListaEspera, saveListaEspera } from '@/data/store';
import type { PedidoItem } from '@/types';
import Badge from '@/components/ui/Badge';
import StratosLogo from '@/components/brand/StratosLogo';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

interface ItemForm {
  id: string;
  itemEstoqueId: string;
  tamanho: string;
  quantidade: number;
}

export default function SupervisorPage() {
  const { user, logout } = useAuth();
  const [supervisorMatricula, setSupervisorMatricula] = useState(user?.matricula || '');
  const [funcionarioMatricula, setFuncionarioMatricula] = useState('');
  const [itens, setItens] = useState<ItemForm[]>([{ id: uuid(), itemEstoqueId: '', tamanho: '', quantidade: 1 }]);
  const [observacoes, setObservacoes] = useState('');
  const [success, setSuccess] = useState('');
  const [error, setError] = useState('');

  const funcionarios = useMemo(() => getFuncionarios(), []);
  const estoque = useMemo(() => getEstoque().filter(e => e.status === 'Ativo'), []);
  const entregas = useMemo(() => getEntregas(), []);

  // Auto-fill supervisor
  const supervisorData = useMemo(() => {
    return funcionarios.find(f => f.matricula === supervisorMatricula);
  }, [supervisorMatricula, funcionarios]);

  // Auto-fill funcionario
  const funcionarioData = useMemo(() => {
    return funcionarios.find(f => f.matricula === funcionarioMatricula);
  }, [funcionarioMatricula, funcionarios]);

  // Delivery history for the selected employee
  const historico = useMemo(() => {
    if (!funcionarioMatricula) return [];
    return entregas
      .filter(e => e.funcionarioMatricula === funcionarioMatricula)
      .flatMap(e => e.itens.map(i => ({
        data: e.dataEntrega,
        item: i.descricao,
        tamanho: i.tamanho,
        quantidade: i.quantidade,
      })))
      .sort((a, b) => new Date(b.data).getTime() - new Date(a.data).getTime())
      .slice(0, 10);
  }, [funcionarioMatricula, entregas]);

  // Get unique items (by code+description)
  const uniqueItems = useMemo(() => {
    const map = new Map<string, { codigo: string; descricao: string }>();
    estoque.forEach(e => {
      if (!map.has(e.codigo)) {
        map.set(e.codigo, { codigo: e.codigo, descricao: e.descricao });
      }
    });
    return Array.from(map.values());
  }, [estoque]);

  const addItem = () => {
    setItens(prev => [...prev, { id: uuid(), itemEstoqueId: '', tamanho: '', quantidade: 1 }]);
  };

  const removeItem = (id: string) => {
    if (itens.length <= 1) return;
    setItens(prev => prev.filter(i => i.id !== id));
  };

  const updateItem = (id: string, field: keyof ItemForm, value: string | number) => {
    setItens(prev => prev.map(i => {
      if (i.id !== id) return i;
      if (field === 'itemEstoqueId') {
        // When changing item, reset size
        return { ...i, itemEstoqueId: value as string, tamanho: '' };
      }
      if (field === 'tamanho') {
        // Find the actual estoque entry for this code + size
        const currentItem = estoque.find(e => e.id === i.itemEstoqueId);
        if (currentItem) {
          const sizedItem = estoque.find(e => e.codigo === currentItem.codigo && e.tamanho === value);
          if (sizedItem) {
            return { ...i, itemEstoqueId: sizedItem.id, tamanho: value as string };
          }
        }
        return { ...i, tamanho: value as string };
      }
      return { ...i, [field]: value };
    }));
  };

  const handleSubmit = () => {
    setError('');
    setSuccess('');

    if (!supervisorMatricula || !supervisorData) {
      setError('Matrícula do supervisor inválida');
      return;
    }
    if (!funcionarioMatricula || !funcionarioData) {
      setError('Matrícula do colaborador inválida');
      return;
    }
    if (funcionarioData.situacao === 'Desligado') {
      setError('Colaborador desligado. Não é possível solicitar uniforme.');
      return;
    }
    if (funcionarioData.situacao === 'Suspenso para entrega') {
      setError('Colaborador suspenso para entrega. Não é possível solicitar uniforme.');
      return;
    }

    const validItems = itens.filter(i => i.itemEstoqueId && i.tamanho && i.quantidade > 0);
    if (validItems.length === 0) {
      setError('Adicione pelo menos um item ao pedido.');
      return;
    }

    // Check for duplicate pending orders
    const pedidos = getPedidos();
    const pending = pedidos.find(p =>
      p.funcionarioMatricula === funcionarioMatricula &&
      p.status === 'Pendente'
    );
    if (pending) {
      if (!confirm(`Já existe um pedido pendente (${pending.numero}) para este colaborador. Deseja continuar?`)) {
        return;
      }
    }

    const pedidoItens: PedidoItem[] = validItems.map(i => {
      const ei = estoque.find(e => e.id === i.itemEstoqueId)!;
      return {
        id: uuid(),
        itemEstoqueId: i.itemEstoqueId,
        descricao: ei.descricao,
        tamanho: i.tamanho,
        quantidade: i.quantidade,
        custoUnitario: ei.custoUnitario,
      };
    });

    const numero = getNextPedidoNumber();
    const now = new Date().toISOString();
    const itensSemSaldo = pedidoItens.filter(item => {
      const estoqueItem = estoque.find(e => e.id === item.itemEstoqueId);
      return !estoqueItem || estoqueItem.quantidadeAtual < item.quantidade;
    });

    const newPedido = {
      id: uuid(),
      numero,
      supervisorMatricula,
      supervisorNome: supervisorData.nome,
      funcionarioMatricula,
      funcionarioNome: funcionarioData.nome,
      centroCusto: funcionarioData.centroCusto,
      turno: funcionarioData.turno,
      funcao: funcionarioData.funcao,
      gerencia: funcionarioData.gerencia,
      dataSolicitacao: now,
      status: itensSemSaldo.length > 0 ? 'Espera' as const : 'Pendente' as const,
      itens: pedidoItens,
      observacoes,
      createdAt: now,
      updatedAt: now,
    };

    const allPedidos = getPedidos();
    allPedidos.push(newPedido);
    savePedidos(allPedidos);

    if (itensSemSaldo.length > 0) {
      const listaEspera = getListaEspera();
      itensSemSaldo.forEach(item => {
        const estoqueItem = estoque.find(e => e.id === item.itemEstoqueId);
        const saldoDisponivel = estoqueItem?.quantidadeAtual || 0;
        listaEspera.push({
          id: uuid(),
          pedidoId: newPedido.id,
          funcionarioMatricula: funcionarioData.matricula,
          funcionarioNome: funcionarioData.nome,
          turno: funcionarioData.turno,
          centroCusto: funcionarioData.centroCusto,
          itemEstoqueId: item.itemEstoqueId,
          descricaoItem: item.descricao,
          tamanho: item.tamanho,
          quantidade: item.quantidade,
          tipoEspera: saldoDisponivel === 0 ? 'Total' : 'Parcial',
          dataEntrada: now,
          status: 'Aguardando',
        });
      });
      saveListaEspera(listaEspera);
    }

    setSuccess(itensSemSaldo.length > 0
      ? `Pedido ${numero} registrado e enviado automaticamente para a lista de espera por falta de saldo.`
      : `Pedido ${numero} registrado com sucesso!`
    );
    setFuncionarioMatricula('');
    setItens([{ id: uuid(), itemEstoqueId: '', tamanho: '', quantidade: 1 }]);
    setObservacoes('');
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-[#151111] text-white px-4 py-3 sticky top-0 z-30">
        <div className="max-w-lg mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="rounded-lg bg-white px-2 py-1">
              <StratosLogo size={28} />
            </div>
            <div>
              <h1 className="text-base font-bold">SST</h1>
              <p className="text-[10px] text-gray-400">Solicitação de Uniformes</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="text-right">
              <p className="text-xs font-medium">{user?.nome}</p>
              <p className="text-[10px] text-gray-400">Supervisor</p>
            </div>
            <button onClick={logout} className="p-2 hover:bg-gray-800 rounded-lg">
              <LogOut size={16} />
            </button>
          </div>
        </div>
      </header>

      <div className="max-w-lg mx-auto p-4 space-y-4">
        {/* Messages */}
        {error && (
          <div className="flex items-center gap-2 p-3 bg-red-50 border border-red-200 rounded-xl text-red-600 text-sm">
            <AlertCircle size={16} className="shrink-0" />
            {error}
          </div>
        )}
        {success && (
          <div className="flex items-center gap-2 p-3 bg-green-50 border border-green-200 rounded-xl text-green-600 text-sm">
            <CheckCircle size={16} className="shrink-0" />
            {success}
          </div>
        )}

        {/* Supervisor */}
        <div className="bg-white rounded-xl border border-gray-200 p-4">
          <h2 className="text-sm font-semibold text-gray-700 mb-3">Dados do Supervisor</h2>
          <div>
            <label className="block text-xs font-medium text-gray-500 mb-1">Matrícula do Supervisor</label>
            <input
              type="text"
              value={supervisorMatricula}
              onChange={e => setSupervisorMatricula(e.target.value)}
              placeholder="Digite a matrícula"
              className="w-full px-3 py-2.5 border border-gray-300 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
            />
          </div>
          {supervisorData && (
            <div className="mt-3 p-3 bg-[#f8e9e6] rounded-xl space-y-1">
              <p className="text-sm font-medium text-[#7b1c16]">{supervisorData.nome}</p>
              <p className="text-xs text-[#8b1e18]">Gerência: {supervisorData.gerencia} | CC: {supervisorData.centroCusto}</p>
            </div>
          )}
        </div>

        {/* Colaborador */}
        <div className="bg-white rounded-xl border border-gray-200 p-4">
          <h2 className="text-sm font-semibold text-gray-700 mb-3">Dados do Colaborador</h2>
          <div>
            <label className="block text-xs font-medium text-gray-500 mb-1">Matrícula do Colaborador</label>
            <input
              type="text"
              value={funcionarioMatricula}
              onChange={e => setFuncionarioMatricula(e.target.value)}
              placeholder="Digite a matrícula"
              className="w-full px-3 py-2.5 border border-gray-300 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
            />
          </div>
          {funcionarioData && (
            <div className={`mt-3 p-3 rounded-xl space-y-1 ${
              funcionarioData.situacao === 'Ativo' ? 'bg-green-50' :
              funcionarioData.situacao === 'Desligado' ? 'bg-red-50' :
              funcionarioData.situacao === 'Suspenso para entrega' ? 'bg-purple-50' : 'bg-amber-50'
            }`}>
              <div className="flex items-center justify-between">
                <p className="text-sm font-medium text-gray-800">{funcionarioData.nome}</p>
                <Badge variant={
                  funcionarioData.situacao === 'Ativo' ? 'success' :
                  funcionarioData.situacao === 'Desligado' ? 'danger' :
                  funcionarioData.situacao === 'Suspenso para entrega' ? 'purple' : 'warning'
                }>{funcionarioData.situacao}</Badge>
              </div>
              <div className="grid grid-cols-2 gap-1 text-xs text-gray-600 mt-2">
                <p><span className="font-medium">Turno:</span> {funcionarioData.turno}</p>
                <p><span className="font-medium">Função:</span> {funcionarioData.funcao}</p>
                <p><span className="font-medium">Gerência:</span> {funcionarioData.gerencia}</p>
                <p><span className="font-medium">CC:</span> {funcionarioData.centroCusto}</p>
                <p className="col-span-2"><span className="font-medium">Responsável:</span> {funcionarioData.responsavel}</p>
              </div>
            </div>
          )}
        </div>

        {/* Histórico */}
        {historico.length > 0 && (
          <div className="bg-white rounded-xl border border-gray-200 p-4">
            <h2 className="text-sm font-semibold text-gray-700 mb-3 flex items-center gap-2">
              <History size={16} />
              Últimas Entregas
            </h2>
            <div className="space-y-2">
              {historico.map((h, i) => (
                <div key={i} className="flex items-center justify-between p-2 bg-gray-50 rounded-lg text-xs">
                  <div>
                    <p className="font-medium text-gray-700">{h.item}</p>
                    <p className="text-gray-400">Tam: {h.tamanho} | Qtd: {h.quantidade}</p>
                  </div>
                  <p className="text-gray-400">{format(new Date(h.data), 'dd/MM/yy', { locale: ptBR })}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Itens do Pedido */}
        <div className="bg-white rounded-xl border border-gray-200 p-4">
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-sm font-semibold text-gray-700">Itens do Pedido</h2>
            <button onClick={addItem} className="flex items-center gap-1 px-3 py-1.5 bg-[#f8e9e6] text-[#7b1c16] rounded-lg text-xs font-medium hover:bg-[#f1d7d2] transition-colors">
              <Plus size={14} />
              Adicionar Item
            </button>
          </div>

          <div className="space-y-3">
            {itens.map((item, idx) => {
              const selectedEstoqueItem = estoque.find(e => e.id === item.itemEstoqueId);
              const availableSizes = selectedEstoqueItem
                ? estoque.filter(e => e.codigo === selectedEstoqueItem.codigo)
                : [];

              return (
                <div key={item.id} className="p-3 bg-gray-50 rounded-xl space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-medium text-gray-500">Item {idx + 1}</span>
                    {itens.length > 1 && (
                      <button onClick={() => removeItem(item.id)} className="p-1 hover:bg-red-100 rounded text-red-400">
                        <Trash2 size={14} />
                      </button>
                    )}
                  </div>

                  <select
                    value={selectedEstoqueItem?.codigo || ''}
                    onChange={e => {
                      const code = e.target.value;
                      const first = estoque.find(ei => ei.codigo === code);
                      if (first) updateItem(item.id, 'itemEstoqueId', first.id);
                    }}
                    className="w-full px-3 py-2 border border-gray-300 rounded-xl text-sm bg-white focus:ring-2 focus:ring-blue-500 outline-none"
                  >
                    <option value="">Selecione o uniforme</option>
                    {uniqueItems.map(ui => (
                      <option key={ui.codigo} value={ui.codigo}>{ui.descricao} ({ui.codigo})</option>
                    ))}
                  </select>

                  <div className="grid grid-cols-2 gap-2">
                    <select
                      value={item.tamanho}
                      onChange={e => updateItem(item.id, 'tamanho', e.target.value)}
                      className="px-3 py-2 border border-gray-300 rounded-xl text-sm bg-white focus:ring-2 focus:ring-blue-500 outline-none"
                    >
                      <option value="">Tamanho</option>
                      {availableSizes.map(s => (
                        <option key={s.id} value={s.tamanho}>
                          {s.tamanho} (disp: {s.quantidadeAtual})
                        </option>
                      ))}
                    </select>

                    <input
                      type="number"
                      min="1"
                      value={item.quantidade}
                      onChange={e => updateItem(item.id, 'quantidade', Math.max(1, parseInt(e.target.value) || 1))}
                      className="px-3 py-2 border border-gray-300 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 outline-none"
                      placeholder="Qtd"
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Observações */}
        <div className="bg-white rounded-xl border border-gray-200 p-4">
          <h2 className="text-sm font-semibold text-gray-700 mb-3">Observações</h2>
          <textarea
            value={observacoes}
            onChange={e => setObservacoes(e.target.value)}
            placeholder="Observações sobre o pedido (opcional)"
            rows={3}
            className="w-full px-3 py-2.5 border border-gray-300 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none resize-none"
          />
        </div>

        {/* Submit */}
        <button
          onClick={handleSubmit}
          className="w-full py-3.5 bg-[#7b1c16] hover:bg-[#5f1511] text-white font-semibold rounded-xl transition-colors flex items-center justify-center gap-2 shadow-lg shadow-[#7b1c16]/30"
        >
          <Send size={18} />
          Enviar Solicitação
        </button>

        <div className="h-4" />
      </div>
    </div>
  );
}
