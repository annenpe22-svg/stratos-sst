import { useState, useMemo } from 'react';
import { Eye, Check, XCircle, Clock, Package, Search } from 'lucide-react';
import { v4 as uuid } from 'uuid';
import Modal from '@/components/ui/Modal';
import Badge from '@/components/ui/Badge';
import { getPedidos, savePedidos, getEstoque, saveEstoque, getEntregas, saveEntregas, getListaEspera, saveListaEspera, getMovimentacoes, saveMovimentacoes } from '@/data/store';
import { useAuth } from '@/contexts/AuthContext';
import type { Pedido, StatusPedido, Movimentacao } from '@/types';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

const statusFilters: (StatusPedido | 'Todos')[] = ['Todos', 'Pendente', 'Aprovado', 'Entregue', 'Espera', 'Rejeitado'];

const statusBadgeVariant = (s: StatusPedido): 'default' | 'success' | 'warning' | 'danger' | 'info' | 'purple' => {
  const map: Record<StatusPedido, 'default' | 'success' | 'warning' | 'danger' | 'info' | 'purple'> = {
    'Pendente': 'warning', 'Aprovado': 'info', 'Entregue': 'success',
    'Rejeitado': 'danger', 'Espera': 'purple', 'Parcial': 'default'
  };
  return map[s];
};

export default function PedidosPage() {
  const { user } = useAuth();
  const [pedidos, setPedidos] = useState<Pedido[]>(getPedidos());
  const [filter, setFilter] = useState<StatusPedido | 'Todos'>('Todos');
  const [search, setSearch] = useState('');
  const [viewPedido, setViewPedido] = useState<Pedido | null>(null);

  const reload = () => setPedidos(getPedidos());

  const filtered = useMemo(() => {
    return pedidos.filter(p => {
      const matchStatus = filter === 'Todos' || p.status === filter;
      const matchSearch = search === '' ||
        p.funcionarioNome.toLowerCase().includes(search.toLowerCase()) ||
        p.numero.toLowerCase().includes(search.toLowerCase()) ||
        p.funcionarioMatricula.includes(search);
      return matchStatus && matchSearch;
    }).sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }, [pedidos, filter, search]);

  const handleAprovar = (pedido: Pedido) => {
    const estoque = getEstoque();
    // Check stock
    let allAvailable = true;
    const unavailableItems: string[] = [];
    pedido.itens.forEach(item => {
      const estoqueItem = estoque.find(e => e.id === item.itemEstoqueId);
      if (!estoqueItem || estoqueItem.quantidadeAtual < item.quantidade) {
        allAvailable = false;
        unavailableItems.push(`${item.descricao} (${item.tamanho})`);
      }
    });

    if (!allAvailable) {
      handleEnviarEspera(pedido, true);
      alert(`Pedido enviado automaticamente para a Lista de Espera por falta de saldo:\n${unavailableItems.join('\n')}`);
      return;
    }

    const allPedidos = getPedidos();
    const idx = allPedidos.findIndex(p => p.id === pedido.id);
    if (idx >= 0) {
      allPedidos[idx].status = 'Aprovado';
      allPedidos[idx].updatedAt = new Date().toISOString();
      savePedidos(allPedidos);
      reload();
    }
  };

  const handleRejeitar = (pedido: Pedido) => {
    if (!confirm('Deseja realmente rejeitar este pedido?')) return;
    const allPedidos = getPedidos();
    const idx = allPedidos.findIndex(p => p.id === pedido.id);
    if (idx >= 0) {
      allPedidos[idx].status = 'Rejeitado';
      allPedidos[idx].updatedAt = new Date().toISOString();
      savePedidos(allPedidos);
      reload();
    }
  };

  const handleEnviarEspera = (pedido: Pedido, somenteSemSaldo = false) => {
    const allPedidos = getPedidos();
    const listaEspera = getListaEspera();
    const estoque = getEstoque();
    const itensParaEspera = pedido.itens.filter(item => {
      if (!somenteSemSaldo) return true;
      const estoqueItem = estoque.find(e => e.id === item.itemEstoqueId);
      return !estoqueItem || estoqueItem.quantidadeAtual < item.quantidade;
    });

    const idx = allPedidos.findIndex(p => p.id === pedido.id);
    if (idx >= 0) {
      allPedidos[idx].status = 'Espera';
      allPedidos[idx].updatedAt = new Date().toISOString();
    }

    itensParaEspera.forEach(item => {
      const alreadyWaiting = listaEspera.some(espera =>
        espera.pedidoId === pedido.id &&
        espera.itemEstoqueId === item.itemEstoqueId &&
        espera.status === 'Aguardando'
      );
      if (alreadyWaiting) return;

      const estoqueItem = estoque.find(e => e.id === item.itemEstoqueId);
      const available = estoqueItem ? estoqueItem.quantidadeAtual : 0;
      const tipoEspera = available === 0 ? 'Total' : 'Parcial';

      listaEspera.push({
        id: uuid(),
        pedidoId: pedido.id,
        funcionarioMatricula: pedido.funcionarioMatricula,
        funcionarioNome: pedido.funcionarioNome,
        turno: pedido.turno,
        centroCusto: pedido.centroCusto,
        itemEstoqueId: item.itemEstoqueId,
        descricaoItem: item.descricao,
        tamanho: item.tamanho,
        quantidade: item.quantidade,
        tipoEspera: tipoEspera as 'Total' | 'Parcial',
        dataEntrada: new Date().toISOString(),
        status: 'Aguardando',
      });
    });

    savePedidos(allPedidos);
    saveListaEspera(listaEspera);
    reload();
  };

  const handleEntrega = (pedido: Pedido) => {
    const estoque = getEstoque();
    // Verify stock again
    for (const item of pedido.itens) {
      const ei = estoque.find(e => e.id === item.itemEstoqueId);
      if (!ei || ei.quantidadeAtual < item.quantidade) {
        alert(`Estoque insuficiente para ${item.descricao} (${item.tamanho}). Disponível: ${ei?.quantidadeAtual || 0}, Necessário: ${item.quantidade}`);
        return;
      }
    }

    if (!confirm('Confirmar entrega e dar baixa no estoque?')) return;

    // Deduct stock
    pedido.itens.forEach(item => {
      const eidx = estoque.findIndex(e => e.id === item.itemEstoqueId);
      if (eidx >= 0) {
        estoque[eidx].quantidadeAtual -= item.quantidade;
      }
    });
    saveEstoque(estoque);

    // Record delivery
    const entregas = getEntregas();
    entregas.push({
      id: uuid(),
      pedidoId: pedido.id,
      numeroPedido: pedido.numero,
      funcionarioMatricula: pedido.funcionarioMatricula,
      funcionarioNome: pedido.funcionarioNome,
      centroCusto: pedido.centroCusto,
      itens: pedido.itens.map(i => ({
        itemEstoqueId: i.itemEstoqueId,
        descricao: i.descricao,
        tamanho: i.tamanho,
        quantidade: i.quantidade,
      })),
      dataEntrega: new Date().toISOString(),
      entregaPor: user?.nome || 'Sistema',
    });
    saveEntregas(entregas);

    // Record movements
    const movs = getMovimentacoes();
    pedido.itens.forEach(item => {
      movs.push({
        id: uuid(),
        itemEstoqueId: item.itemEstoqueId,
        descricaoItem: item.descricao,
        tipo: 'saida',
        quantidade: item.quantidade,
        motivo: `Entrega - Pedido ${pedido.numero}`,
        usuario: user?.nome || 'Sistema',
        dataHora: new Date().toISOString(),
      } as Movimentacao);
    });
    saveMovimentacoes(movs);

    // Update pedido status
    const allPedidos = getPedidos();
    const pidx = allPedidos.findIndex(p => p.id === pedido.id);
    if (pidx >= 0) {
      allPedidos[pidx].status = 'Entregue';
      allPedidos[pidx].updatedAt = new Date().toISOString();
    }
    savePedidos(allPedidos);
    reload();
    alert('Entrega registrada com sucesso!');
  };

  return (
    <div className="space-y-4">
      {/* Filters */}
      <div className="bg-white rounded-xl border border-gray-200 p-4">
        <div className="flex flex-col sm:flex-row gap-3 items-start sm:items-center justify-between">
          <div className="flex flex-wrap gap-2">
            {statusFilters.map(s => (
              <button
                key={s}
                onClick={() => setFilter(s)}
                className={`px-4 py-2 rounded-xl text-sm font-medium transition-colors ${
                  filter === s
                    ? 'bg-[#7b1c16] text-white shadow-md'
                    : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                }`}
              >
                {s}
                {s !== 'Todos' && (
                  <span className="ml-1.5 text-xs">
                    ({pedidos.filter(p => p.status === s).length})
                  </span>
                )}
              </button>
            ))}
          </div>
          <div className="relative w-full sm:w-auto">
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="Buscar pedido..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="w-full sm:w-64 pl-9 pr-4 py-2.5 border border-gray-300 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
            />
          </div>
        </div>
      </div>

      {/* Table */}
      <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-gray-50 border-b border-gray-200">
                <th className="text-left py-3 px-4 font-medium text-gray-500">Nº</th>
                <th className="text-left py-3 px-4 font-medium text-gray-500">Funcionário</th>
                <th className="text-left py-3 px-4 font-medium text-gray-500 hidden md:table-cell">Turno</th>
                <th className="text-left py-3 px-4 font-medium text-gray-500 hidden lg:table-cell">Centro Custo</th>
                <th className="text-left py-3 px-4 font-medium text-gray-500">Itens</th>
                <th className="text-left py-3 px-4 font-medium text-gray-500 hidden md:table-cell">Solicitado em</th>
                <th className="text-left py-3 px-4 font-medium text-gray-500">Status</th>
                <th className="text-left py-3 px-4 font-medium text-gray-500">Ações</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map(p => (
                <tr key={p.id} className="border-b border-gray-100 hover:bg-gray-50 transition-colors">
                  <td className="py-3 px-4 font-mono text-gray-700 text-xs">{p.numero}</td>
                  <td className="py-3 px-4">
                    <p className="font-medium text-gray-800">{p.funcionarioNome}</p>
                    <p className="text-xs text-gray-400">{p.funcionarioMatricula}</p>
                  </td>
                  <td className="py-3 px-4 text-gray-600 hidden md:table-cell">{p.turno}</td>
                  <td className="py-3 px-4 text-gray-600 hidden lg:table-cell">{p.centroCusto}</td>
                  <td className="py-3 px-4 text-gray-600">
                    {p.itens.map(i => `${i.descricao} (${i.tamanho}) x${i.quantidade}`).join(', ').substring(0, 50)}
                    {p.itens.map(i => `${i.descricao} (${i.tamanho}) x${i.quantidade}`).join(', ').length > 50 ? '...' : ''}
                  </td>
                  <td className="py-3 px-4 text-gray-600 hidden md:table-cell">
                    {format(new Date(p.dataSolicitacao), 'dd/MM/yyyy', { locale: ptBR })}
                  </td>
                  <td className="py-3 px-4">
                    <Badge variant={statusBadgeVariant(p.status)}>{p.status}</Badge>
                  </td>
                  <td className="py-3 px-4">
                    <div className="flex gap-1">
                      <button onClick={() => setViewPedido(p)} className="p-1.5 hover:bg-gray-100 rounded-lg text-gray-500" title="Visualizar">
                        <Eye size={15} />
                      </button>
                      {p.status === 'Pendente' && (
                        <>
                          <button onClick={() => handleAprovar(p)} className="p-1.5 hover:bg-green-50 rounded-lg text-green-600" title="Aprovar">
                            <Check size={15} />
                          </button>
                          <button onClick={() => handleRejeitar(p)} className="p-1.5 hover:bg-red-50 rounded-lg text-red-500" title="Rejeitar">
                            <XCircle size={15} />
                          </button>
                          <button onClick={() => handleEnviarEspera(p)} className="p-1.5 hover:bg-purple-50 rounded-lg text-purple-500" title="Enviar para Espera">
                            <Clock size={15} />
                          </button>
                        </>
                      )}
                      {p.status === 'Aprovado' && (
                        <button onClick={() => handleEntrega(p)} className="p-1.5 hover:bg-[#f8e9e6] rounded-lg text-[#8b1e18]" title="Registrar Entrega">
                          <Package size={15} />
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
              {filtered.length === 0 && (
                <tr><td colSpan={8} className="py-12 text-center text-gray-400">Nenhum pedido encontrado.</td></tr>
              )}
            </tbody>
          </table>
        </div>
        <div className="px-4 py-3 bg-gray-50 border-t border-gray-200 text-sm text-gray-500">
          {filtered.length} pedido(s)
        </div>
      </div>

      {/* View Modal */}
      <Modal isOpen={!!viewPedido} onClose={() => setViewPedido(null)} title={`Pedido ${viewPedido?.numero || ''}`} size="lg">
        {viewPedido && (
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-xs text-gray-500">Funcionário</p>
                <p className="font-medium text-gray-800">{viewPedido.funcionarioNome}</p>
                <p className="text-xs text-gray-400">Mat: {viewPedido.funcionarioMatricula}</p>
              </div>
              <div>
                <p className="text-xs text-gray-500">Supervisor</p>
                <p className="font-medium text-gray-800">{viewPedido.supervisorNome}</p>
              </div>
              <div>
                <p className="text-xs text-gray-500">Centro de Custo</p>
                <p className="text-gray-800">{viewPedido.centroCusto}</p>
              </div>
              <div>
                <p className="text-xs text-gray-500">Turno / Função</p>
                <p className="text-gray-800">{viewPedido.turno} / {viewPedido.funcao}</p>
              </div>
              <div>
                <p className="text-xs text-gray-500">Data Solicitação</p>
                <p className="text-gray-800">{format(new Date(viewPedido.dataSolicitacao), 'dd/MM/yyyy HH:mm', { locale: ptBR })}</p>
              </div>
              <div>
                <p className="text-xs text-gray-500">Status</p>
                <Badge variant={statusBadgeVariant(viewPedido.status)}>{viewPedido.status}</Badge>
              </div>
            </div>

            <div>
              <p className="text-sm font-medium text-gray-700 mb-2">Itens do Pedido</p>
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-gray-200">
                    <th className="text-left py-2 font-medium text-gray-500">Item</th>
                    <th className="text-left py-2 font-medium text-gray-500">Tamanho</th>
                    <th className="text-left py-2 font-medium text-gray-500">Qtd</th>
                    <th className="text-left py-2 font-medium text-gray-500">Custo Unit.</th>
                    <th className="text-left py-2 font-medium text-gray-500">Subtotal</th>
                  </tr>
                </thead>
                <tbody>
                  {viewPedido.itens.map(item => (
                    <tr key={item.id} className="border-b border-gray-100">
                      <td className="py-2 text-gray-800">{item.descricao}</td>
                      <td className="py-2 text-gray-600">{item.tamanho}</td>
                      <td className="py-2 text-gray-600">{item.quantidade}</td>
                      <td className="py-2 text-gray-600">R$ {item.custoUnitario.toFixed(2)}</td>
                      <td className="py-2 font-medium text-gray-800">R$ {(item.custoUnitario * item.quantidade).toFixed(2)}</td>
                    </tr>
                  ))}
                </tbody>
                <tfoot>
                  <tr className="border-t-2 border-gray-300">
                    <td colSpan={4} className="py-2 font-semibold text-gray-800 text-right">Total:</td>
                    <td className="py-2 font-bold text-[#8b1e18]">
                      R$ {viewPedido.itens.reduce((s, i) => s + i.custoUnitario * i.quantidade, 0).toFixed(2)}
                    </td>
                  </tr>
                </tfoot>
              </table>
            </div>

            {viewPedido.observacoes && (
              <div>
                <p className="text-xs text-gray-500">Observações</p>
                <p className="text-gray-700 bg-gray-50 p-3 rounded-xl mt-1">{viewPedido.observacoes}</p>
              </div>
            )}
          </div>
        )}
      </Modal>
    </div>
  );
}
