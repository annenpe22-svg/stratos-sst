import { useMemo, useState } from 'react';
import { Activity, Edit, Plus, Search, Trash2, Upload } from 'lucide-react';
import { v4 as uuid } from 'uuid';
import * as XLSX from 'xlsx';
import Badge from '@/components/ui/Badge';
import Modal from '@/components/ui/Modal';
import { getASOs, getFuncionarios, saveASOs } from '@/data/store';
import type { ASO, AptidaoASO, TipoASO } from '@/types';
import { getImportValue, type ImportRow } from '@/utils/importHelpers';
import { fromInputDate, getSSTStatus, getSSTStatusVariant, toInputDate } from '@/utils/sst';

const tiposASO: TipoASO[] = ['Admissional', 'Periódico', 'Retorno ao Trabalho', 'Mudança de Risco', 'Demissional'];
const aptidoes: AptidaoASO[] = ['Apto', 'Apto com restrição', 'Inapto'];

const asoAliases = {
  matricula: ['matricula', 'chapa', 'registro', 'codigo', 'codigofuncionario', 'colaborador'],
  nome: ['nome', 'nomecompleto', 'funcionario', 'colaborador', 'empregado'],
  tipo: ['tipo', 'tipoaso', 'exame', 'tipoexame'],
  dataExame: ['dataexame', 'data', 'realizacao', 'datarealizacao', 'emissao'],
  validade: ['validade', 'vencimento', 'datavencimento', 'validadeaso'],
  clinica: ['clinica', 'prestador', 'laboratorio'],
  medico: ['medico', 'medicoresponsavel', 'crm'],
  aptidao: ['aptidao', 'resultado', 'statusmedico'],
  observacoes: ['observacoes', 'obs', 'restricoes', 'comentario'],
};

const normalizeTipoASO = (value: string): TipoASO => {
  const text = value.toLowerCase();
  if (text.includes('admiss')) return 'Admissional';
  if (text.includes('retorno')) return 'Retorno ao Trabalho';
  if (text.includes('mudan')) return 'Mudança de Risco';
  if (text.includes('demiss')) return 'Demissional';
  return 'Periódico';
};

const normalizeAptidao = (value: string): AptidaoASO => {
  const text = value.toLowerCase();
  if (text.includes('inap')) return 'Inapto';
  if (text.includes('restr')) return 'Apto com restrição';
  return 'Apto';
};

function parseDate(value: string): string {
  if (!value) return '';
  if (/^\d{4}-\d{2}-\d{2}/.test(value)) return fromInputDate(value.slice(0, 10));
  const parts = value.split(/[/-]/).map(Number);
  if (parts.length === 3 && parts[2] > 1900) {
    return new Date(parts[2], parts[1] - 1, parts[0], 12).toISOString();
  }
  const parsed = new Date(value);
  return Number.isNaN(parsed.getTime()) ? '' : parsed.toISOString();
}

export default function ASOPage() {
  const [asos, setAsos] = useState<ASO[]>(getASOs());
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('Todos');
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<ASO | null>(null);
  const [form, setForm] = useState<Partial<ASO>>({ tipo: 'Periódico', aptidao: 'Apto' });

  const funcionarios = useMemo(() => getFuncionarios(), []);

  const filtered = useMemo(() => {
    return asos.filter(aso => {
      const status = getSSTStatus(aso.validade);
      const text = `${aso.funcionarioNome} ${aso.funcionarioMatricula} ${aso.tipo} ${aso.centroCusto}`.toLowerCase();
      const matchesSearch = !search || text.includes(search.toLowerCase());
      const matchesStatus = statusFilter === 'Todos' || status === statusFilter;
      return matchesSearch && matchesStatus;
    }).sort((a, b) => new Date(a.validade).getTime() - new Date(b.validade).getTime());
  }, [asos, search, statusFilter]);

  const reload = () => setAsos(getASOs());

  const openNew = () => {
    setEditing(null);
    setForm({ tipo: 'Periódico', aptidao: 'Apto', dataExame: new Date().toISOString(), validade: '' });
    setModalOpen(true);
  };

  const openEdit = (aso: ASO) => {
    setEditing(aso);
    setForm({ ...aso });
    setModalOpen(true);
  };

  const setFuncionario = (matricula: string) => {
    const funcionario = funcionarios.find(f => f.matricula === matricula);
    setForm(prev => ({
      ...prev,
      funcionarioMatricula: matricula,
      funcionarioNome: funcionario?.nome || prev.funcionarioNome || '',
      centroCusto: funcionario?.centroCusto || prev.centroCusto || '',
      funcao: funcionario?.funcao || prev.funcao || '',
    }));
  };

  const handleSave = () => {
    if (!form.funcionarioMatricula || !form.funcionarioNome || !form.validade) {
      alert('Informe colaborador, nome e validade do ASO.');
      return;
    }

    const all = getASOs();
    const now = new Date().toISOString();
    const payload: ASO = {
      id: editing?.id || uuid(),
      funcionarioMatricula: form.funcionarioMatricula || '',
      funcionarioNome: form.funcionarioNome || '',
      centroCusto: form.centroCusto || '',
      funcao: form.funcao || '',
      tipo: (form.tipo as TipoASO) || 'Periódico',
      dataExame: form.dataExame || now,
      validade: form.validade || '',
      clinica: form.clinica || '',
      medico: form.medico || '',
      aptidao: (form.aptidao as AptidaoASO) || 'Apto',
      observacoes: form.observacoes || '',
      createdAt: editing?.createdAt || now,
      updatedAt: now,
    };

    if (editing) {
      const idx = all.findIndex(item => item.id === editing.id);
      if (idx >= 0) all[idx] = payload;
    } else {
      all.push(payload);
    }

    saveASOs(all);
    reload();
    setModalOpen(false);
  };

  const handleDelete = (id: string) => {
    if (!confirm('Deseja excluir este ASO?')) return;
    saveASOs(getASOs().filter(aso => aso.id !== id));
    reload();
  };

  const handleClearAll = () => {
    if (!asos.length || !confirm('Excluir todos os ASOs cadastrados?')) return;
    saveASOs([]);
    reload();
  };

  const handleImport = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const wb = XLSX.read(await file.arrayBuffer());
    const ws = wb.Sheets[wb.SheetNames[0]];
    const rows = XLSX.utils.sheet_to_json<ImportRow>(ws, { defval: '', raw: false });
    const all = getASOs();
    let imported = 0;

    rows.forEach(row => {
      const matricula = getImportValue(row, asoAliases.matricula);
      if (!matricula) return;
      const funcionario = funcionarios.find(f => f.matricula === matricula);
      const dataExame = parseDate(getImportValue(row, asoAliases.dataExame));
      const validade = parseDate(getImportValue(row, asoAliases.validade));
      const existing = all.findIndex(aso => aso.funcionarioMatricula === matricula && aso.validade === validade && aso.tipo === normalizeTipoASO(getImportValue(row, asoAliases.tipo)));
      const payload: ASO = {
        id: existing >= 0 ? all[existing].id : uuid(),
        funcionarioMatricula: matricula,
        funcionarioNome: getImportValue(row, asoAliases.nome) || funcionario?.nome || '',
        centroCusto: funcionario?.centroCusto || '',
        funcao: funcionario?.funcao || '',
        tipo: normalizeTipoASO(getImportValue(row, asoAliases.tipo)),
        dataExame: dataExame || new Date().toISOString(),
        validade,
        clinica: getImportValue(row, asoAliases.clinica),
        medico: getImportValue(row, asoAliases.medico),
        aptidao: normalizeAptidao(getImportValue(row, asoAliases.aptidao)),
        observacoes: getImportValue(row, asoAliases.observacoes),
        createdAt: existing >= 0 ? all[existing].createdAt : new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      if (existing >= 0) all[existing] = payload;
      else all.push(payload);
      imported++;
    });

    saveASOs(all);
    reload();
    alert(`${imported} ASO(s) importado(s)/atualizado(s).`);
    e.target.value = '';
  };

  return (
    <div className="space-y-4">
      <div className="bg-white rounded-xl border border-gray-200 p-4">
        <div className="flex flex-col lg:flex-row gap-3 items-start lg:items-center justify-between">
          <div>
            <h3 className="font-semibold text-gray-900 flex items-center gap-2"><Activity size={18} /> Gestão de ASO</h3>
            <p className="text-sm text-gray-500">Controle de exames ocupacionais, validade e aptidão.</p>
          </div>
          <div className="flex flex-col sm:flex-row gap-2 w-full lg:w-auto">
            <div className="relative">
              <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
              <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Buscar colaborador" className="w-full sm:w-64 pl-9 pr-4 py-2.5 border border-gray-300 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 outline-none" />
            </div>
            <select value={statusFilter} onChange={e => setStatusFilter(e.target.value)} className="px-3 py-2.5 border border-gray-300 rounded-xl text-sm bg-white focus:ring-2 focus:ring-blue-500 outline-none">
              {['Todos', 'Em dia', 'A vencer', 'Vencido', 'Pendente'].map(s => <option key={s} value={s}>{s}</option>)}
            </select>
            <button onClick={handleClearAll} className="flex items-center justify-center gap-2 px-4 py-2.5 bg-red-50 hover:bg-red-100 text-red-600 rounded-xl text-sm font-medium"><Trash2 size={16} />Limpar</button>
            <label className="flex items-center justify-center gap-2 px-4 py-2.5 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-xl text-sm font-medium cursor-pointer">
              <Upload size={16} /> Importar
              <input type="file" accept=".xlsx,.xls,.csv" onChange={handleImport} className="hidden" />
            </label>
            <button onClick={openNew} className="flex items-center justify-center gap-2 px-4 py-2.5 bg-[#7b1c16] hover:bg-[#5f1511] text-white rounded-xl text-sm font-medium"><Plus size={16} />Novo</button>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="text-left py-3 px-4 font-medium text-gray-500">Colaborador</th>
                <th className="text-left py-3 px-4 font-medium text-gray-500 hidden md:table-cell">Tipo</th>
                <th className="text-left py-3 px-4 font-medium text-gray-500 hidden lg:table-cell">Exame</th>
                <th className="text-left py-3 px-4 font-medium text-gray-500">Validade</th>
                <th className="text-left py-3 px-4 font-medium text-gray-500 hidden lg:table-cell">Aptidão</th>
                <th className="text-left py-3 px-4 font-medium text-gray-500">Status</th>
                <th className="text-left py-3 px-4 font-medium text-gray-500">Ações</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map(aso => {
                const status = getSSTStatus(aso.validade);
                return (
                  <tr key={aso.id} className="border-b border-gray-100 hover:bg-gray-50">
                    <td className="py-3 px-4"><p className="font-medium text-gray-800">{aso.funcionarioNome}</p><p className="text-xs text-gray-400">{aso.funcionarioMatricula} | {aso.centroCusto}</p></td>
                    <td className="py-3 px-4 text-gray-600 hidden md:table-cell">{aso.tipo}</td>
                    <td className="py-3 px-4 text-gray-600 hidden lg:table-cell">{aso.dataExame ? new Date(aso.dataExame).toLocaleDateString('pt-BR') : '-'}</td>
                    <td className="py-3 px-4 text-gray-700">{aso.validade ? new Date(aso.validade).toLocaleDateString('pt-BR') : '-'}</td>
                    <td className="py-3 px-4 text-gray-600 hidden lg:table-cell">{aso.aptidao}</td>
                    <td className="py-3 px-4"><Badge variant={getSSTStatusVariant(status)}>{status}</Badge></td>
                    <td className="py-3 px-4"><div className="flex gap-1"><button onClick={() => openEdit(aso)} className="p-1.5 text-[#8b1e18] hover:bg-[#f8e9e6] rounded-lg"><Edit size={15} /></button><button onClick={() => handleDelete(aso.id)} className="p-1.5 text-red-500 hover:bg-red-50 rounded-lg"><Trash2 size={15} /></button></div></td>
                  </tr>
                );
              })}
              {filtered.length === 0 && <tr><td colSpan={7} className="py-12 text-center text-gray-400">Nenhum ASO encontrado.</td></tr>}
            </tbody>
          </table>
        </div>
        <div className="px-4 py-3 bg-gray-50 border-t border-gray-200 text-sm text-gray-500">{filtered.length} registro(s)</div>
      </div>

      <Modal isOpen={modalOpen} onClose={() => setModalOpen(false)} title={editing ? 'Editar ASO' : 'Novo ASO'} size="lg">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Matrícula</label>
            <input list="funcionarios-aso" value={form.funcionarioMatricula || ''} onChange={e => setFuncionario(e.target.value)} className="w-full px-3 py-2.5 border border-gray-300 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 outline-none" />
            <datalist id="funcionarios-aso">{funcionarios.map(f => <option key={f.id} value={f.matricula}>{f.nome}</option>)}</datalist>
          </div>
          <div><label className="block text-sm font-medium text-gray-700 mb-1">Nome</label><input value={form.funcionarioNome || ''} onChange={e => setForm(p => ({ ...p, funcionarioNome: e.target.value }))} className="w-full px-3 py-2.5 border border-gray-300 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 outline-none" /></div>
          <div><label className="block text-sm font-medium text-gray-700 mb-1">Tipo</label><select value={form.tipo || 'Periódico'} onChange={e => setForm(p => ({ ...p, tipo: e.target.value as TipoASO }))} className="w-full px-3 py-2.5 border border-gray-300 rounded-xl text-sm bg-white focus:ring-2 focus:ring-blue-500 outline-none">{tiposASO.map(t => <option key={t} value={t}>{t}</option>)}</select></div>
          <div><label className="block text-sm font-medium text-gray-700 mb-1">Aptidão</label><select value={form.aptidao || 'Apto'} onChange={e => setForm(p => ({ ...p, aptidao: e.target.value as AptidaoASO }))} className="w-full px-3 py-2.5 border border-gray-300 rounded-xl text-sm bg-white focus:ring-2 focus:ring-blue-500 outline-none">{aptidoes.map(a => <option key={a} value={a}>{a}</option>)}</select></div>
          <div><label className="block text-sm font-medium text-gray-700 mb-1">Data do Exame</label><input type="date" value={toInputDate(form.dataExame || '')} onChange={e => setForm(p => ({ ...p, dataExame: fromInputDate(e.target.value) }))} className="w-full px-3 py-2.5 border border-gray-300 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 outline-none" /></div>
          <div><label className="block text-sm font-medium text-gray-700 mb-1">Validade</label><input type="date" value={toInputDate(form.validade || '')} onChange={e => setForm(p => ({ ...p, validade: fromInputDate(e.target.value) }))} className="w-full px-3 py-2.5 border border-gray-300 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 outline-none" /></div>
          <div><label className="block text-sm font-medium text-gray-700 mb-1">Clínica</label><input value={form.clinica || ''} onChange={e => setForm(p => ({ ...p, clinica: e.target.value }))} className="w-full px-3 py-2.5 border border-gray-300 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 outline-none" /></div>
          <div><label className="block text-sm font-medium text-gray-700 mb-1">Médico</label><input value={form.medico || ''} onChange={e => setForm(p => ({ ...p, medico: e.target.value }))} className="w-full px-3 py-2.5 border border-gray-300 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 outline-none" /></div>
          <div className="sm:col-span-2"><label className="block text-sm font-medium text-gray-700 mb-1">Observações</label><textarea value={form.observacoes || ''} onChange={e => setForm(p => ({ ...p, observacoes: e.target.value }))} rows={3} className="w-full px-3 py-2.5 border border-gray-300 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 outline-none resize-none" /></div>
        </div>
        <div className="flex justify-end gap-3 mt-6 pt-4 border-t border-gray-200"><button onClick={() => setModalOpen(false)} className="px-5 py-2.5 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-xl text-sm font-medium">Cancelar</button><button onClick={handleSave} className="px-5 py-2.5 bg-[#7b1c16] hover:bg-[#5f1511] text-white rounded-xl text-sm font-medium">Salvar</button></div>
      </Modal>
    </div>
  );
}