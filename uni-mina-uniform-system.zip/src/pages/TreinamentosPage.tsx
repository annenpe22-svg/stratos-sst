import { useMemo, useState } from 'react';
import { Edit, GraduationCap, Plus, Search, Trash2, Upload } from 'lucide-react';
import { v4 as uuid } from 'uuid';
import * as XLSX from 'xlsx';
import Badge from '@/components/ui/Badge';
import Modal from '@/components/ui/Modal';
import { getFuncionarios, getTreinamentos, saveTreinamentos } from '@/data/store';
import type { Treinamento } from '@/types';
import { getImportNumber, getImportValue, type ImportRow } from '@/utils/importHelpers';
import { fromInputDate, getSSTStatus, getSSTStatusVariant, toInputDate } from '@/utils/sst';

const treinamentoAliases = {
  matricula: ['matricula', 'chapa', 'registro', 'codigo', 'codigofuncionario', 'colaborador'],
  nome: ['nome', 'nomecompleto', 'funcionario', 'colaborador', 'empregado'],
  curso: ['curso', 'treinamento', 'nomecurso', 'nomedotreinamento', 'descricao'],
  norma: ['norma', 'nr', 'requisito', 'legislacao'],
  cargaHoraria: ['cargahoraria', 'horas', 'ch', 'duracao'],
  dataRealizacao: ['datarealizacao', 'realizacao', 'data', 'conclusao', 'dataconclusao'],
  validade: ['validade', 'vencimento', 'datavencimento', 'validadecurso'],
  instrutor: ['instrutor', 'facilitador', 'responsavel', 'empresa'],
  observacoes: ['observacoes', 'obs', 'comentario'],
};

function parseDate(value: string): string {
  if (!value) return '';
  if (/^\d{4}-\d{2}-\d{2}/.test(value)) return fromInputDate(value.slice(0, 10));
  const parts = value.split(/[/-]/).map(Number);
  if (parts.length === 3 && parts[2] > 1900) return new Date(parts[2], parts[1] - 1, parts[0], 12).toISOString();
  const parsed = new Date(value);
  return Number.isNaN(parsed.getTime()) ? '' : parsed.toISOString();
}

export default function TreinamentosPage() {
  const [treinamentos, setTreinamentos] = useState<Treinamento[]>(getTreinamentos());
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('Todos');
  const [normaFilter, setNormaFilter] = useState('Todas');
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<Treinamento | null>(null);
  const [form, setForm] = useState<Partial<Treinamento>>({});

  const funcionarios = useMemo(() => getFuncionarios(), []);
  const normas = useMemo(() => Array.from(new Set(treinamentos.map(t => t.norma).filter(Boolean))).sort(), [treinamentos]);

  const filtered = useMemo(() => {
    return treinamentos.filter(t => {
      const status = getSSTStatus(t.validade);
      const text = `${t.funcionarioNome} ${t.funcionarioMatricula} ${t.curso} ${t.norma} ${t.centroCusto}`.toLowerCase();
      const matchesSearch = !search || text.includes(search.toLowerCase());
      const matchesStatus = statusFilter === 'Todos' || status === statusFilter;
      const matchesNorma = normaFilter === 'Todas' || t.norma === normaFilter;
      return matchesSearch && matchesStatus && matchesNorma;
    }).sort((a, b) => new Date(a.validade).getTime() - new Date(b.validade).getTime());
  }, [treinamentos, search, statusFilter, normaFilter]);

  const reload = () => setTreinamentos(getTreinamentos());

  const setFuncionario = (matricula: string) => {
    const funcionario = funcionarios.find(f => f.matricula === matricula);
    setForm(prev => ({
      ...prev,
      funcionarioMatricula: matricula,
      funcionarioNome: funcionario?.nome || prev.funcionarioNome || '',
      centroCusto: funcionario?.centroCusto || prev.centroCusto || '',
      funcao: funcionario?.funcao || prev.funcao || '',
    }));
  };

  const openNew = () => {
    setEditing(null);
    setForm({ dataRealizacao: new Date().toISOString(), cargaHoraria: 0, norma: 'SST' });
    setModalOpen(true);
  };

  const openEdit = (treinamento: Treinamento) => {
    setEditing(treinamento);
    setForm({ ...treinamento });
    setModalOpen(true);
  };

  const handleSave = () => {
    if (!form.funcionarioMatricula || !form.funcionarioNome || !form.curso) {
      alert('Informe colaborador, nome e treinamento.');
      return;
    }

    const all = getTreinamentos();
    const now = new Date().toISOString();
    const payload: Treinamento = {
      id: editing?.id || uuid(),
      funcionarioMatricula: form.funcionarioMatricula || '',
      funcionarioNome: form.funcionarioNome || '',
      centroCusto: form.centroCusto || '',
      funcao: form.funcao || '',
      curso: form.curso || '',
      norma: form.norma || 'SST',
      cargaHoraria: Number(form.cargaHoraria) || 0,
      dataRealizacao: form.dataRealizacao || now,
      validade: form.validade || '',
      instrutor: form.instrutor || '',
      observacoes: form.observacoes || '',
      createdAt: editing?.createdAt || now,
      updatedAt: now,
    };

    if (editing) {
      const idx = all.findIndex(t => t.id === editing.id);
      if (idx >= 0) all[idx] = payload;
    } else {
      all.push(payload);
    }

    saveTreinamentos(all);
    reload();
    setModalOpen(false);
  };

  const handleDelete = (id: string) => {
    if (!confirm('Deseja excluir este treinamento?')) return;
    saveTreinamentos(getTreinamentos().filter(t => t.id !== id));
    reload();
  };

  const handleClearAll = () => {
    if (!treinamentos.length || !confirm('Excluir todos os treinamentos cadastrados?')) return;
    saveTreinamentos([]);
    reload();
  };

  const handleImport = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const wb = XLSX.read(await file.arrayBuffer());
    const ws = wb.Sheets[wb.SheetNames[0]];
    const rows = XLSX.utils.sheet_to_json<ImportRow>(ws, { defval: '', raw: false });
    const all = getTreinamentos();
    let imported = 0;

    rows.forEach(row => {
      const matricula = getImportValue(row, treinamentoAliases.matricula);
      const curso = getImportValue(row, treinamentoAliases.curso);
      if (!matricula || !curso) return;
      const funcionario = funcionarios.find(f => f.matricula === matricula);
      const validade = parseDate(getImportValue(row, treinamentoAliases.validade));
      const norma = getImportValue(row, treinamentoAliases.norma) || 'SST';
      const existing = all.findIndex(t => t.funcionarioMatricula === matricula && t.curso === curso && t.validade === validade);
      const payload: Treinamento = {
        id: existing >= 0 ? all[existing].id : uuid(),
        funcionarioMatricula: matricula,
        funcionarioNome: getImportValue(row, treinamentoAliases.nome) || funcionario?.nome || '',
        centroCusto: funcionario?.centroCusto || '',
        funcao: funcionario?.funcao || '',
        curso,
        norma,
        cargaHoraria: getImportNumber(row, treinamentoAliases.cargaHoraria, 0),
        dataRealizacao: parseDate(getImportValue(row, treinamentoAliases.dataRealizacao)) || new Date().toISOString(),
        validade,
        instrutor: getImportValue(row, treinamentoAliases.instrutor),
        observacoes: getImportValue(row, treinamentoAliases.observacoes),
        createdAt: existing >= 0 ? all[existing].createdAt : new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      if (existing >= 0) all[existing] = payload;
      else all.push(payload);
      imported++;
    });

    saveTreinamentos(all);
    reload();
    alert(`${imported} treinamento(s) importado(s)/atualizado(s).`);
    e.target.value = '';
  };

  return (
    <div className="space-y-4">
      <div className="bg-white rounded-xl border border-gray-200 p-4">
        <div className="flex flex-col lg:flex-row gap-3 items-start lg:items-center justify-between">
          <div>
            <h3 className="font-semibold text-gray-900 flex items-center gap-2"><GraduationCap size={18} /> Gestão de Treinamentos</h3>
            <p className="text-sm text-gray-500">Matriz de capacitações, NRs, vencimentos e evidências.</p>
          </div>
          <div className="flex flex-col sm:flex-row gap-2 w-full lg:w-auto">
            <div className="relative"><Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" /><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Buscar" className="w-full sm:w-56 pl-9 pr-4 py-2.5 border border-gray-300 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 outline-none" /></div>
            <select value={normaFilter} onChange={e => setNormaFilter(e.target.value)} className="px-3 py-2.5 border border-gray-300 rounded-xl text-sm bg-white focus:ring-2 focus:ring-blue-500 outline-none"><option value="Todas">Todas NRs</option>{normas.map(n => <option key={n} value={n}>{n}</option>)}</select>
            <select value={statusFilter} onChange={e => setStatusFilter(e.target.value)} className="px-3 py-2.5 border border-gray-300 rounded-xl text-sm bg-white focus:ring-2 focus:ring-blue-500 outline-none">{['Todos', 'Em dia', 'A vencer', 'Vencido', 'Pendente'].map(s => <option key={s} value={s}>{s}</option>)}</select>
            <button onClick={handleClearAll} className="flex items-center justify-center gap-2 px-4 py-2.5 bg-red-50 hover:bg-red-100 text-red-600 rounded-xl text-sm font-medium"><Trash2 size={16} />Limpar</button>
            <label className="flex items-center justify-center gap-2 px-4 py-2.5 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-xl text-sm font-medium cursor-pointer"><Upload size={16} /> Importar<input type="file" accept=".xlsx,.xls,.csv" onChange={handleImport} className="hidden" /></label>
            <button onClick={openNew} className="flex items-center justify-center gap-2 px-4 py-2.5 bg-[#7b1c16] hover:bg-[#5f1511] text-white rounded-xl text-sm font-medium"><Plus size={16} />Novo</button>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-gray-50 border-b border-gray-200"><tr><th className="text-left py-3 px-4 font-medium text-gray-500">Colaborador</th><th className="text-left py-3 px-4 font-medium text-gray-500">Treinamento</th><th className="text-left py-3 px-4 font-medium text-gray-500 hidden md:table-cell">NR</th><th className="text-left py-3 px-4 font-medium text-gray-500 hidden lg:table-cell">Realização</th><th className="text-left py-3 px-4 font-medium text-gray-500">Validade</th><th className="text-left py-3 px-4 font-medium text-gray-500">Status</th><th className="text-left py-3 px-4 font-medium text-gray-500">Ações</th></tr></thead>
            <tbody>
              {filtered.map(t => {
                const status = getSSTStatus(t.validade);
                return (
                  <tr key={t.id} className="border-b border-gray-100 hover:bg-gray-50">
                    <td className="py-3 px-4"><p className="font-medium text-gray-800">{t.funcionarioNome}</p><p className="text-xs text-gray-400">{t.funcionarioMatricula} | {t.centroCusto}</p></td>
                    <td className="py-3 px-4 text-gray-800"><p className="font-medium">{t.curso}</p><p className="text-xs text-gray-400">{t.cargaHoraria}h | {t.instrutor || 'Sem instrutor'}</p></td>
                    <td className="py-3 px-4 text-gray-600 hidden md:table-cell">{t.norma}</td>
                    <td className="py-3 px-4 text-gray-600 hidden lg:table-cell">{t.dataRealizacao ? new Date(t.dataRealizacao).toLocaleDateString('pt-BR') : '-'}</td>
                    <td className="py-3 px-4 text-gray-700">{t.validade ? new Date(t.validade).toLocaleDateString('pt-BR') : '-'}</td>
                    <td className="py-3 px-4"><Badge variant={getSSTStatusVariant(status)}>{status}</Badge></td>
                    <td className="py-3 px-4"><div className="flex gap-1"><button onClick={() => openEdit(t)} className="p-1.5 text-[#8b1e18] hover:bg-[#f8e9e6] rounded-lg"><Edit size={15} /></button><button onClick={() => handleDelete(t.id)} className="p-1.5 text-red-500 hover:bg-red-50 rounded-lg"><Trash2 size={15} /></button></div></td>
                  </tr>
                );
              })}
              {filtered.length === 0 && <tr><td colSpan={7} className="py-12 text-center text-gray-400">Nenhum treinamento encontrado.</td></tr>}
            </tbody>
          </table>
        </div>
        <div className="px-4 py-3 bg-gray-50 border-t border-gray-200 text-sm text-gray-500">{filtered.length} registro(s)</div>
      </div>

      <Modal isOpen={modalOpen} onClose={() => setModalOpen(false)} title={editing ? 'Editar Treinamento' : 'Novo Treinamento'} size="lg">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div><label className="block text-sm font-medium text-gray-700 mb-1">Matrícula</label><input list="funcionarios-treinamento" value={form.funcionarioMatricula || ''} onChange={e => setFuncionario(e.target.value)} className="w-full px-3 py-2.5 border border-gray-300 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 outline-none" /><datalist id="funcionarios-treinamento">{funcionarios.map(f => <option key={f.id} value={f.matricula}>{f.nome}</option>)}</datalist></div>
          <div><label className="block text-sm font-medium text-gray-700 mb-1">Nome</label><input value={form.funcionarioNome || ''} onChange={e => setForm(p => ({ ...p, funcionarioNome: e.target.value }))} className="w-full px-3 py-2.5 border border-gray-300 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 outline-none" /></div>
          <div className="sm:col-span-2"><label className="block text-sm font-medium text-gray-700 mb-1">Treinamento</label><input value={form.curso || ''} onChange={e => setForm(p => ({ ...p, curso: e.target.value }))} className="w-full px-3 py-2.5 border border-gray-300 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 outline-none" /></div>
          <div><label className="block text-sm font-medium text-gray-700 mb-1">Norma</label><input value={form.norma || ''} onChange={e => setForm(p => ({ ...p, norma: e.target.value }))} placeholder="NR-06, NR-10..." className="w-full px-3 py-2.5 border border-gray-300 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 outline-none" /></div>
          <div><label className="block text-sm font-medium text-gray-700 mb-1">Carga Horária</label><input type="number" min="0" value={form.cargaHoraria ?? 0} onChange={e => setForm(p => ({ ...p, cargaHoraria: Number(e.target.value) }))} className="w-full px-3 py-2.5 border border-gray-300 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 outline-none" /></div>
          <div><label className="block text-sm font-medium text-gray-700 mb-1">Data de Realização</label><input type="date" value={toInputDate(form.dataRealizacao || '')} onChange={e => setForm(p => ({ ...p, dataRealizacao: fromInputDate(e.target.value) }))} className="w-full px-3 py-2.5 border border-gray-300 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 outline-none" /></div>
          <div><label className="block text-sm font-medium text-gray-700 mb-1">Validade</label><input type="date" value={toInputDate(form.validade || '')} onChange={e => setForm(p => ({ ...p, validade: fromInputDate(e.target.value) }))} className="w-full px-3 py-2.5 border border-gray-300 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 outline-none" /></div>
          <div className="sm:col-span-2"><label className="block text-sm font-medium text-gray-700 mb-1">Instrutor / Empresa</label><input value={form.instrutor || ''} onChange={e => setForm(p => ({ ...p, instrutor: e.target.value }))} className="w-full px-3 py-2.5 border border-gray-300 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 outline-none" /></div>
          <div className="sm:col-span-2"><label className="block text-sm font-medium text-gray-700 mb-1">Observações</label><textarea value={form.observacoes || ''} onChange={e => setForm(p => ({ ...p, observacoes: e.target.value }))} rows={3} className="w-full px-3 py-2.5 border border-gray-300 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 outline-none resize-none" /></div>
        </div>
        <div className="flex justify-end gap-3 mt-6 pt-4 border-t border-gray-200"><button onClick={() => setModalOpen(false)} className="px-5 py-2.5 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-xl text-sm font-medium">Cancelar</button><button onClick={handleSave} className="px-5 py-2.5 bg-[#7b1c16] hover:bg-[#5f1511] text-white rounded-xl text-sm font-medium">Salvar</button></div>
      </Modal>
    </div>
  );
}