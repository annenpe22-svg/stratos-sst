import { useMemo, useState, type ChangeEvent, type ReactNode } from 'react';
import { Camera, Edit, IdCard, Plus, Printer, Save, Search, Trash2, Upload, X } from 'lucide-react';
import { v4 as uuid } from 'uuid';
import * as XLSX from 'xlsx';
import { getRegistrosCadastrais, saveRegistrosCadastrais } from '@/data/store';
import type { RegistroCadastral, TipoSanguineo } from '@/types';
import { getImportValue, normalizeImportKey, type ImportRow } from '@/utils/importHelpers';
import StratosLogo from '@/components/brand/StratosLogo';

const tiposSanguineos: TipoSanguineo[] = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];
const turmasSupervisores = [
  'Turno A - Supervisor Carlos',
  'Turno B - Supervisora Maria',
  'Turno C - Supervisor Operacional',
  'Administrativo',
  'Manutenção',
  'Logística',
];

const emptyForm: Omit<RegistroCadastral, 'id' | 'createdAt' | 'updatedAt'> = {
  nome: '',
  nomeSocial: '',
  endereco: '',
  bairro: '',
  cidade: '',
  telefone: '',
  cargo: '',
  turmaSupervisor: [],
  dataNascimento: '',
  contatoEmergencia: '',
  tipoSanguineo: '',
  foto: '',
};

const fichaAliases = {
  nome: ['nome', 'nomecompleto', 'colaborador', 'funcionario', 'empregado'],
  nomeSocial: ['comogostariadeserchamado', 'nomepreferido', 'nomesocial', 'apelido', 'chamado', 'comoquereserchamado'],
  endereco: ['enderecoresidencialcompleto', 'enderecoresidencial', 'endereco', 'logradouro', 'rua', 'enderecocompleto'],
  bairro: ['bairro', 'distrito'],
  cidade: ['cidade', 'municipio'],
  telefone: ['numerodetelefone', 'telefone', 'celular', 'fone', 'contato', 'whatsapp'],
  cargo: ['cargo', 'funcao', 'posto', 'ocupacao', 'atividade'],
  turmaSupervisor: ['turmasupervisor', 'turma', 'supervisor', 'lider', 'turno', 'equipe', 'setor'],
  dataNascimento: ['datadenascimento', 'nascimento', 'datanascimento', 'dtNascimento', 'dtnasc'],
  contatoEmergencia: ['pessoaparacontatoemcasodeurgenciaetelefone', 'contatoemergencia', 'emergencia', 'telefoneemergencia', 'contatourgencia'],
  tipoSanguineo: ['tipossanguineosfatorrh', 'tiposanguineo', 'sangue', 'fatorrh', 'rh', 'tiposanguineofatorrh'],
  foto: ['foto', 'imagem', 'fotocolaborador', 'urlfoto', 'linkfoto', 'base64'],
};

const normalizeBloodType = (value: string): TipoSanguineo | '' => {
  const clean = value.trim().toUpperCase().replace(/\s+/g, '');
  if (tiposSanguineos.includes(clean as TipoSanguineo)) return clean as TipoSanguineo;

  const normalized = normalizeImportKey(value);
  const abo = normalized.includes('ab') ? 'AB' : normalized.includes('a') ? 'A' : normalized.includes('b') ? 'B' : normalized.includes('o') ? 'O' : '';
  const rh = normalized.includes('neg') || normalized.includes('menos') || normalized.includes('negative') ? '-' : normalized.includes('pos') || normalized.includes('mais') || normalized.includes('positive') ? '+' : '';
  const result = `${abo}${rh}` as TipoSanguineo;
  return tiposSanguineos.includes(result) ? result : '';
};

const parseImportedDate = (value: string) => {
  if (!value) return '';
  if (/^\d{1,2}[/-]\d{1,2}[/-]\d{2,4}$/.test(value)) return value.replace(/-/g, '/');
  if (/^\d{4}-\d{2}-\d{2}/.test(value)) {
    const [year, month, day] = value.slice(0, 10).split('-');
    return `${day}/${month}/${year}`;
  }
  const parsed = new Date(value);
  if (Number.isNaN(parsed.getTime())) return value;
  return parsed.toLocaleDateString('pt-BR');
};

const parseTurmas = (value: string) => value
  .split(/[,;|]/)
  .map(item => item.trim())
  .filter(Boolean);

export default function FichaCadastralPage() {
  const [registros, setRegistros] = useState<RegistroCadastral[]>(getRegistrosCadastrais());
  const [form, setForm] = useState({ ...emptyForm });
  const [editingId, setEditingId] = useState<string | null>(null);
  const [search, setSearch] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const filtered = useMemo(() => {
    const term = search.toLowerCase().trim();
    if (!term) return registros;
    return registros.filter(registro =>
      `${registro.nome} ${registro.nomeSocial} ${registro.cargo} ${registro.cidade} ${registro.telefone}`.toLowerCase().includes(term)
    );
  }, [registros, search]);

  const reload = () => setRegistros(getRegistrosCadastrais());

  const updateField = (field: keyof typeof emptyForm, value: string | string[]) => {
    setForm(prev => ({ ...prev, [field]: value }));
  };

  const toggleTurma = (value: string) => {
    setForm(prev => ({
      ...prev,
      turmaSupervisor: prev.turmaSupervisor.includes(value)
        ? prev.turmaSupervisor.filter(item => item !== value)
        : [...prev.turmaSupervisor, value],
    }));
  };

  const handlePhoto = async (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith('image/')) {
      setError('Selecione um arquivo de imagem válido.');
      return;
    }

    const reader = new FileReader();
    reader.onload = () => updateField('foto', String(reader.result || ''));
    reader.readAsDataURL(file);
    event.target.value = '';
  };

  const handleImport = async (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const workbook = XLSX.read(await file.arrayBuffer());
    const worksheet = workbook.Sheets[workbook.SheetNames[0]];
    const rows = XLSX.utils.sheet_to_json<ImportRow>(worksheet, { defval: '', raw: false });
    const all = getRegistrosCadastrais();
    const now = new Date().toISOString();
    let imported = 0;
    let incomplete = 0;

    rows.forEach(row => {
      const nome = getImportValue(row, fichaAliases.nome);
      if (!nome) return;

      const telefone = getImportValue(row, fichaAliases.telefone);
      const existingIndex = all.findIndex(registro =>
        normalizeImportKey(registro.nome) === normalizeImportKey(nome) &&
        (!telefone || normalizeImportKey(registro.telefone) === normalizeImportKey(telefone))
      );
      const foto = getImportValue(row, fichaAliases.foto);
      const payload: RegistroCadastral = {
        id: existingIndex >= 0 ? all[existingIndex].id : uuid(),
        nome,
        nomeSocial: getImportValue(row, fichaAliases.nomeSocial),
        endereco: getImportValue(row, fichaAliases.endereco),
        bairro: getImportValue(row, fichaAliases.bairro),
        cidade: getImportValue(row, fichaAliases.cidade),
        telefone,
        cargo: getImportValue(row, fichaAliases.cargo),
        turmaSupervisor: parseTurmas(getImportValue(row, fichaAliases.turmaSupervisor)),
        dataNascimento: parseImportedDate(getImportValue(row, fichaAliases.dataNascimento)),
        contatoEmergencia: getImportValue(row, fichaAliases.contatoEmergencia),
        tipoSanguineo: normalizeBloodType(getImportValue(row, fichaAliases.tipoSanguineo)),
        foto,
        createdAt: existingIndex >= 0 ? all[existingIndex].createdAt : now,
        updatedAt: now,
      };

      if (!payload.nomeSocial || !payload.endereco || !payload.bairro || !payload.cidade || !payload.telefone || !payload.cargo || !payload.dataNascimento || !payload.contatoEmergencia || !payload.tipoSanguineo) {
        incomplete++;
      }

      if (existingIndex >= 0) all[existingIndex] = payload;
      else all.push(payload);
      imported++;
    });

    saveRegistrosCadastrais(all);
    reload();
    setSuccess(`${imported} ficha(s) importada(s)/atualizada(s).${incomplete ? ` ${incomplete} registro(s) ficaram com algum campo obrigatório vazio.` : ''}`);
    setError('');
    event.target.value = '';
  };

  const validate = () => {
    const required: Array<[keyof typeof emptyForm, string]> = [
      ['nome', 'Nome'],
      ['nomeSocial', 'Como gostaria de ser chamado'],
      ['endereco', 'Endereço residencial'],
      ['bairro', 'Bairro'],
      ['cidade', 'Cidade'],
      ['telefone', 'Número de telefone'],
      ['cargo', 'Cargo'],
      ['dataNascimento', 'Data de nascimento'],
      ['contatoEmergencia', 'Contato de emergência'],
      ['tipoSanguineo', 'Tipo sanguíneo'],
    ];

    const missing = required.find(([field]) => !form[field]);
    if (missing) {
      setError(`Preencha o campo obrigatório: ${missing[1]}.`);
      return false;
    }

    setError('');
    return true;
  };

  const handleSave = () => {
    setSuccess('');
    if (!validate()) return;

    const all = getRegistrosCadastrais();
    const now = new Date().toISOString();

    if (editingId) {
      const index = all.findIndex(registro => registro.id === editingId);
      if (index >= 0) {
        all[index] = {
          ...all[index],
          ...form,
          updatedAt: now,
        };
      }
      setSuccess('Ficha cadastral atualizada com sucesso.');
    } else {
      all.push({
        id: uuid(),
        ...form,
        createdAt: now,
        updatedAt: now,
      });
      setSuccess('Ficha cadastral salva com sucesso.');
    }

    saveRegistrosCadastrais(all);
    reload();
    setEditingId(null);
    setForm({ ...emptyForm });
  };

  const handleEdit = (registro: RegistroCadastral) => {
    setEditingId(registro.id);
    setForm({
      nome: registro.nome,
      nomeSocial: registro.nomeSocial,
      endereco: registro.endereco,
      bairro: registro.bairro,
      cidade: registro.cidade,
      telefone: registro.telefone,
      cargo: registro.cargo,
      turmaSupervisor: registro.turmaSupervisor,
      dataNascimento: registro.dataNascimento,
      contatoEmergencia: registro.contatoEmergencia,
      tipoSanguineo: registro.tipoSanguineo,
      foto: registro.foto,
    });
    setError('');
    setSuccess('');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleDelete = (id: string) => {
    if (!confirm('Deseja excluir esta ficha cadastral?')) return;
    saveRegistrosCadastrais(getRegistrosCadastrais().filter(registro => registro.id !== id));
    reload();
  };

  const handleClearAll = () => {
    if (!registros.length) return;
    if (!confirm('Atenção: esta ação excluirá todas as fichas cadastrais. Deseja continuar?')) return;
    saveRegistrosCadastrais([]);
    reload();
    clearForm();
    setSuccess('Todas as fichas cadastrais foram excluídas.');
  };

  const clearForm = () => {
    setEditingId(null);
    setForm({ ...emptyForm });
    setError('');
    setSuccess('');
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-xl border border-gray-200 p-4 flex flex-col lg:flex-row gap-4 items-start lg:items-center justify-between print:hidden">
        <div>
          <h2 className="text-lg font-semibold text-gray-900 flex items-center gap-2">
            <IdCard size={20} />
            Ficha de Registro
          </h2>
          <p className="text-sm text-gray-500">Dados cadastrais, contato de emergência, tipo sanguíneo e foto do colaborador.</p>
        </div>
        <div className="flex flex-col sm:flex-row gap-2 w-full lg:w-auto">
          <div className="relative flex-1 lg:flex-none">
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
            <input
              value={search}
              onChange={event => setSearch(event.target.value)}
              placeholder="Buscar ficha salva"
              className="w-full lg:w-64 pl-9 pr-4 py-2.5 border border-gray-300 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 outline-none"
            />
          </div>
          <button onClick={clearForm} className="flex items-center justify-center gap-2 px-4 py-2.5 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-xl text-sm font-medium">
            <Plus size={16} />
            Nova ficha
          </button>
          <label className="flex items-center justify-center gap-2 px-4 py-2.5 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-xl text-sm font-medium cursor-pointer">
            <Upload size={16} />
            Importar
            <input type="file" accept=".xlsx,.xls,.csv" onChange={handleImport} className="hidden" />
          </label>
          <button
            onClick={handleClearAll}
            disabled={registros.length === 0}
            className="flex items-center justify-center gap-2 px-4 py-2.5 bg-red-50 hover:bg-red-100 disabled:bg-gray-100 disabled:text-gray-400 text-red-600 rounded-xl text-sm font-medium"
          >
            <Trash2 size={16} />
            Excluir todos
          </button>
          <button onClick={() => window.print()} className="flex items-center justify-center gap-2 px-4 py-2.5 bg-[#f8e9e6] hover:bg-[#f1d7d2] text-[#7b1c16] rounded-xl text-sm font-medium">
            <Printer size={16} />
            Imprimir
          </button>
        </div>
      </div>

      <div className="relative overflow-hidden rounded-xl border border-gray-200 bg-[#faf7f6] p-5 sm:p-8 shadow-sm">
        <div className="pointer-events-none absolute inset-0 flex items-center justify-center opacity-[0.035]">
          <div className="text-[120px] sm:text-[180px] font-bold text-gray-900">Stratos</div>
        </div>

        <div className="relative">
          <div className="flex flex-col lg:flex-row gap-6 justify-between">
            <div>
              <StratosLogo size={46} className="mb-6" />
              <h1 className="text-2xl sm:text-3xl font-semibold tracking-tight text-gray-900">DADOS CADASTRAIS</h1>
              <p className="mt-8 text-sm text-gray-700 max-w-4xl">
                Quando você enviar este formulário, ele não coletará automaticamente seus detalhes, como nome e endereço de email, a menos que você mesmo o forneça.
              </p>
              <p className="mt-6 text-sm text-gray-700"><span className="text-red-600">*</span> Obrigatória</p>
            </div>

            <div className="w-full lg:w-52 print:w-40">
              <label className="block text-sm font-medium text-gray-900 mb-2">Foto do colaborador</label>
              <div className="aspect-[3/4] rounded-xl border border-dashed border-gray-300 bg-white overflow-hidden flex items-center justify-center">
                {form.foto ? (
                  <img src={form.foto} alt="Foto do colaborador" className="h-full w-full object-cover" />
                ) : (
                  <div className="text-center text-gray-400 px-4">
                    <Camera size={32} className="mx-auto mb-2" />
                    <p className="text-xs">Adicionar foto</p>
                  </div>
                )}
              </div>
              <div className="mt-3 flex gap-2 print:hidden">
                <label className="flex-1 flex items-center justify-center gap-2 px-3 py-2 bg-gray-900 hover:bg-gray-800 text-white rounded-xl text-xs font-medium cursor-pointer">
                  <Upload size={14} />
                  Enviar
                  <input type="file" accept="image/*" onChange={handlePhoto} className="hidden" />
                </label>
                {form.foto && (
                  <button onClick={() => updateField('foto', '')} className="px-3 py-2 bg-red-50 hover:bg-red-100 text-red-600 rounded-xl">
                    <X size={14} />
                  </button>
                )}
              </div>
            </div>
          </div>

          {error && <div className="mt-6 p-3 bg-red-50 border border-red-200 text-red-700 rounded-xl text-sm print:hidden">{error}</div>}
          {success && <div className="mt-6 p-3 bg-green-50 border border-green-200 text-green-700 rounded-xl text-sm print:hidden">{success}</div>}

          <div className="mt-8 space-y-10">
            <Question number={1} label="Nome" required>
              <input value={form.nome} onChange={event => updateField('nome', event.target.value)} placeholder="Insira sua resposta" className="form-input" />
            </Question>

            <Question number={2} label="Como gostaria de ser chamado?" required>
              <input value={form.nomeSocial} onChange={event => updateField('nomeSocial', event.target.value)} placeholder="Insira sua resposta" className="form-input" />
            </Question>

            <Question number={3} label="Endereço Residencial (completo)" required>
              <textarea value={form.endereco} onChange={event => updateField('endereco', event.target.value)} placeholder="Insira sua resposta" rows={3} className="form-input resize-none" />
            </Question>

            <Question number={4} label="Bairro" required>
              <input value={form.bairro} onChange={event => updateField('bairro', event.target.value)} placeholder="Insira sua resposta" className="form-input" />
            </Question>

            <Question number={5} label="Cidade" required>
              <input value={form.cidade} onChange={event => updateField('cidade', event.target.value)} placeholder="Insira sua resposta" className="form-input" />
            </Question>

            <Question number={6} label="Número de telefone" required>
              <input value={form.telefone} onChange={event => updateField('telefone', event.target.value)} placeholder="Insira sua resposta" className="form-input" />
            </Question>

            <Question number={7} label="Cargo" required>
              <input value={form.cargo} onChange={event => updateField('cargo', event.target.value)} placeholder="Insira sua resposta" className="form-input" />
            </Question>

            <Question number={8} label="Turma / Supervisor" hint="Marque tudo o que se aplica">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {turmasSupervisores.map(item => (
                  <label key={item} className="flex items-center gap-3 text-sm text-gray-800">
                    <input type="checkbox" checked={form.turmaSupervisor.includes(item)} onChange={() => toggleTurma(item)} className="w-4 h-4 rounded border-gray-300 text-[#8b1e18] focus:ring-[#8b1e18]" />
                    {item}
                  </label>
                ))}
              </div>
            </Question>

            <Question number={9} label="Data de Nascimento" required>
              <input value={form.dataNascimento} onChange={event => updateField('dataNascimento', event.target.value)} placeholder="Insira a data (dd/MM/yyyy)" className="form-input" />
            </Question>

            <Question number={10} label="Pessoa para contato em caso de urgência e telefone" required>
              <textarea value={form.contatoEmergencia} onChange={event => updateField('contatoEmergencia', event.target.value)} placeholder="Insira sua resposta" rows={3} className="form-input resize-none" />
            </Question>

            <Question number={11} label="Tipos Sanguíneos / Fator RH" required>
              <div className="space-y-4">
                {tiposSanguineos.map(tipo => (
                  <label key={tipo} className="flex items-center gap-3 text-sm text-gray-800">
                    <input type="radio" name="tipoSanguineo" value={tipo} checked={form.tipoSanguineo === tipo} onChange={() => updateField('tipoSanguineo', tipo)} className="w-5 h-5 border-gray-300 text-[#8b1e18] focus:ring-[#8b1e18]" />
                    {tipo}
                  </label>
                ))}
              </div>
            </Question>
          </div>

          <div className="mt-10 flex flex-col sm:flex-row justify-end gap-3 print:hidden">
            <button onClick={clearForm} className="px-5 py-3 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-xl text-sm font-medium">Limpar formulário</button>
            <button onClick={handleSave} className="flex items-center justify-center gap-2 px-5 py-3 bg-[#7b1c16] hover:bg-[#5f1511] text-white rounded-xl text-sm font-medium shadow-lg shadow-[#7b1c16]/20">
              <Save size={16} />
              {editingId ? 'Atualizar ficha' : 'Salvar ficha'}
            </button>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 overflow-hidden print:hidden">
        <div className="p-4 border-b border-gray-200">
          <h3 className="font-semibold text-gray-900">Fichas salvas</h3>
          <p className="text-sm text-gray-500">Edite, revise ou exclua fichas cadastradas.</p>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="text-left py-3 px-4 font-medium text-gray-500">Foto</th>
                <th className="text-left py-3 px-4 font-medium text-gray-500">Nome</th>
                <th className="text-left py-3 px-4 font-medium text-gray-500 hidden md:table-cell">Telefone</th>
                <th className="text-left py-3 px-4 font-medium text-gray-500 hidden lg:table-cell">Cargo</th>
                <th className="text-left py-3 px-4 font-medium text-gray-500 hidden lg:table-cell">Tipo Sanguíneo</th>
                <th className="text-left py-3 px-4 font-medium text-gray-500">Ações</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map(registro => (
                <tr key={registro.id} className="border-b border-gray-100 hover:bg-gray-50">
                  <td className="py-3 px-4">
                    <div className="w-10 h-10 rounded-lg bg-gray-100 overflow-hidden flex items-center justify-center">
                      {registro.foto ? <img src={registro.foto} alt={registro.nome} className="w-full h-full object-cover" /> : <Camera size={16} className="text-gray-400" />}
                    </div>
                  </td>
                  <td className="py-3 px-4"><p className="font-medium text-gray-800">{registro.nome}</p><p className="text-xs text-gray-400">{registro.nomeSocial}</p></td>
                  <td className="py-3 px-4 text-gray-600 hidden md:table-cell">{registro.telefone}</td>
                  <td className="py-3 px-4 text-gray-600 hidden lg:table-cell">{registro.cargo}</td>
                  <td className="py-3 px-4 text-gray-600 hidden lg:table-cell">{registro.tipoSanguineo}</td>
                  <td className="py-3 px-4">
                    <div className="flex gap-1">
                      <button onClick={() => handleEdit(registro)} className="p-1.5 text-[#8b1e18] hover:bg-[#f8e9e6] rounded-lg" title="Editar"><Edit size={15} /></button>
                      <button onClick={() => handleDelete(registro.id)} className="p-1.5 text-red-500 hover:bg-red-50 rounded-lg" title="Excluir"><Trash2 size={15} /></button>
                    </div>
                  </td>
                </tr>
              ))}
              {filtered.length === 0 && <tr><td colSpan={6} className="py-10 text-center text-gray-400">Nenhuma ficha cadastrada.</td></tr>}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

function Question({ number, label, required, hint, children }: { number: number; label: string; required?: boolean; hint?: string; children: ReactNode }) {
  return (
    <div>
      <label className="block text-base text-gray-950 mb-4">
        {number}. {label} {required && <span className="text-red-600">*</span>}
      </label>
      {hint && <p className="text-sm text-gray-500 -mt-2 mb-4">{hint}</p>}
      {children}
    </div>
  );
}