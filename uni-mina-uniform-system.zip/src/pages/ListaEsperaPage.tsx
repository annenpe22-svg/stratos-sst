import { useState, useMemo } from 'react';
import { Check, X, Clock } from 'lucide-react';
import { v4 as uuid } from 'uuid';
import Badge from '@/components/ui/Badge';
import { getListaEspera, saveListaEspera, getEstoque, saveEstoque, getPedidos, savePedidos, getEntregas, saveEntregas, getMovimentacoes, saveMovimentacoes } from '@/data/store';
import { useAuth } from '@/contexts/AuthContext';
import type { ListaEspera, Movimentacao } from '@/types';
import { formatDistanceToNow } from 'date-fns';
import { ptBR } from 'date-fns/locale';

export default function ListaEsperaPage() {
  const { user } = useAuth();
  const [lista, setLista] = useState<ListaEspera[]>(getListaEspera());

  const reload = () => setLista(getListaEspera());

  const aguardando = useMemo(() =>
    lista.filter(l => l.status === 'Aguardando').sort((a, b) =>
      new Date(a.dataEntrada).getTime() - new Date(b.dataEntrada).getTime()
    ),
  [lista]);

  const handleLiberar = (item: ListaEspera) => {
    const estoque = getEstoque();
    const estoqueItem = estoque.find(e => e.id === item.itemEstoqueId);

    if (!estoqueItem || estoqueItem.quantidadeAtual < item.quantidade) {
      alert(`Estoque insuficiente para ${item.descricaoItem} (${item.tamanho}). Disponível: ${estoqueItem?.quantidadeAtual || 0}`);
      return;
    }

    if (!confirm(`Liberar ${item.quantidade}x ${item.descricaoItem} (${item.tamanho}) para ${item.funcionarioNome}?`)) return;

    // Deduct stock
    const eidx = estoque.findIndex(e => e.id === item.itemEstoqueId);
    if (eidx >= 0) {
      estoque[eidx].quantidadeAtual -= item.quantidade;
    }
    saveEstoque(estoque);

    // Update wait list item
    const allLista = getListaEspera();
    const lidx = allLista.findIndex(l => l.id === item.id);
    if (lidx >= 0) {
      allLista[lidx].status = 'Atendido';
    }
    saveListaEspera(allLista);

    // Record delivery
    const entregas = getEntregas();
    entregas.push({
      id: uuid(),
      pedidoId: item.pedidoId,
      numeroPedido: 'ESP-' + item.id.substring(0, 6),
      funcionarioMatricula: item.funcionarioMatricula,
      funcionarioNome: item.funcionarioNome,
      centroCusto: item.centroCusto,
      itens: [{
        itemEstoqueId: item.itemEstoqueId,
        descricao: item.descricaoItem,
        tamanho: item.tamanho,
        quantidade: item.quantidade,
      }],
      dataEntrega: new Date().toISOString(),
      entregaPor: user?.nome || 'Sistema',
    });
    saveEntregas(entregas);

    // Record movement
    const movs = getMovimentacoes();
    movs.push({
      id: uuid(),
      itemEstoqueId: item.itemEstoqueId,
      descricaoItem: item.descricaoItem,
      tipo: 'saida',
      quantidade: item.quantidade,
      motivo: `Liberação de Espera para ${item.funcionarioNome}`,
      usuario: user?.nome || 'Sistema',
      dataHora: new Date().toISOString(),
    } as Movimentacao);
    saveMovimentacoes(movs);

    // Check if all items from this pedido are fulfilled
    const pedidoItems = allLista.filter(l => l.pedidoId === item.pedidoId);
    const allFulfilled = pedidoItems.every(l => l.status === 'Atendido' || l.id === item.id);
    if (allFulfilled) {
      const pedidos = getPedidos();
      const pidx = pedidos.findIndex(p => p.id === item.pedidoId);
      if (pidx >= 0) {
        pedidos[pidx].status = 'Entregue';
        pedidos[pidx].updatedAt = new Date().toISOString();
        savePedidos(pedidos);
      }
    }

    reload();
    alert('Item liberado com sucesso!');
  };

  const handleCancelar = (item: ListaEspera) => {
    if (!confirm('Deseja cancelar este item da lista de espera?')) return;
    const allLista = getListaEspera();
    const idx = allLista.findIndex(l => l.id === item.id);
    if (idx >= 0) {
      allLista[idx].status = 'Cancelado';
    }
    saveListaEspera(allLista);
    reload();
  };

  // Check for items that can be fulfilled now
  const checkAvailability = (item: ListaEspera): boolean => {
    const estoque = getEstoque();
    const ei = estoque.find(e => e.id === item.itemEstoqueId);
    return !!ei && ei.quantidadeAtual >= item.quantidade;
  };

  return (
    <div className="space-y-4">
      {/* Info */}
      <div className="bg-blue-50 border border-blue-200 rounded-xl p-4">
        <div className="flex items-center gap-2 text-blue-700">
          <Clock size={18} />
          <p className="text-sm font-medium">
            A lista de espera é processada por ordem de entrada (FIFO). Itens com estoque disponível são destacados.
          </p>
        </div>
      </div>

      {/* Table */}
      <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-gray-50 border-b border-gray-200">
                <th className="text-left py-3 px-4 font-medium text-gray-500">Funcionário</th>
                <th className="text-left py-3 px-4 font-medium text-gray-500 hidden md:table-cell">Turno</th>
                <th className="text-left py-3 px-4 font-medium text-gray-500 hidden md:table-cell">Centro Custo</th>
                <th className="text-left py-3 px-4 font-medium text-gray-500">Item</th>
                <th className="text-left py-3 px-4 font-medium text-gray-500">Tamanho</th>
                <th className="text-left py-3 px-4 font-medium text-gray-500">Qtd</th>
                <th className="text-left py-3 px-4 font-medium text-gray-500 hidden lg:table-cell">Aguardando</th>
                <th className="text-left py-3 px-4 font-medium text-gray-500">Tipo</th>
                <th className="text-left py-3 px-4 font-medium text-gray-500">Ação</th>
              </tr>
            </thead>
            <tbody>
              {aguardando.map(item => {
                const available = checkAvailability(item);
                return (
                  <tr key={item.id} className={`border-b border-gray-100 hover:bg-gray-50 transition-colors ${available ? 'bg-green-50/50' : ''}`}>
                    <td className="py-3 px-4">
                      <p className="font-medium text-gray-800">{item.funcionarioNome}</p>
                      <p className="text-xs text-gray-400">{item.funcionarioMatricula}</p>
                    </td>
                    <td className="py-3 px-4 text-gray-600 hidden md:table-cell">{item.turno}</td>
                    <td className="py-3 px-4 text-gray-600 hidden md:table-cell">{item.centroCusto}</td>
                    <td className="py-3 px-4 text-gray-800">{item.descricaoItem}</td>
                    <td className="py-3 px-4 text-gray-600">{item.tamanho}</td>
                    <td className="py-3 px-4 text-gray-600">{item.quantidade}</td>
                    <td className="py-3 px-4 text-gray-500 text-xs hidden lg:table-cell">
                      {formatDistanceToNow(new Date(item.dataEntrada), { locale: ptBR, addSuffix: false })}
                    </td>
                    <td className="py-3 px-4">
                      <Badge variant={item.tipoEspera === 'Total' ? 'danger' : 'warning'}>{item.tipoEspera}</Badge>
                    </td>
                    <td className="py-3 px-4">
                      <div className="flex gap-1">
                        <button
                          onClick={() => handleLiberar(item)}
                          className={`p-1.5 rounded-lg transition-colors ${available ? 'bg-green-100 text-green-700 hover:bg-green-200' : 'text-gray-400 hover:bg-gray-100'}`}
                          title={available ? 'Liberar (estoque disponível)' : 'Liberar'}
                        >
                          <Check size={15} />
                        </button>
                        <button onClick={() => handleCancelar(item)} className="p-1.5 hover:bg-red-50 rounded-lg text-red-500 transition-colors" title="Cancelar">
                          <X size={15} />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
              {aguardando.length === 0 && (
                <tr><td colSpan={9} className="py-12 text-center text-gray-400">
                  <Clock size={40} className="mx-auto mb-2 text-gray-300" />
                  Nenhum item na lista de espera.
                </td></tr>
              )}
            </tbody>
          </table>
        </div>
        <div className="px-4 py-3 bg-gray-50 border-t border-gray-200 text-sm text-gray-500">
          {aguardando.length} item(ns) aguardando
        </div>
      </div>
    </div>
  );
}
