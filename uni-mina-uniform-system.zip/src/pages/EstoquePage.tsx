import { useState, useMemo } from 'react';
import { Search, Plus, Upload, Edit, Trash2, AlertTriangle, Filter } from 'lucide-react';
import { v4 as uuid } from 'uuid';
import * as XLSX from 'xlsx';
import Modal from '@/components/ui/Modal';
import Badge from '@/components/ui/Badge';
import { getEstoque, saveEstoque } from '@/data/store';
import type { ItemEstoque } from '@/types';
import { getFallbackTextValue, getImportNumber, getImportValue, normalizeImportKey, type ImportRow } from '@/utils/importHelpers';

const estoqueAliases = {
  codigo: ['codigo', 'cod', 'coditem', 'codigoitem', 'codigodoitem', 'item', 'material', 'nmaterial', 'numeromaterial', 'codmaterial', 'codigomaterial', 'codproduto', 'codigoproduto', 'sku', 'referencia', 'ref'],
  descricao: ['descricao', 'desc', 'descr', 'descricaodoitem', 'descricaomaterial', 'descricaoproduto', 'descricaodoproduto', 'descmaterial', 'descitem', 'itemdescricao', 'uniforme', 'produto', 'nome', 'nomeitem', 'nomematerial', 'nomeproduto', 'denominacao', 'denominacaoitem', 'texto', 'textobreve', 'textobrevematerial', 'materialdescricao', 'descricaobreve'],
  categoria: ['categoria', 'grupo', 'grupomercadorias', 'grupodemercadorias', 'grupomaterial', 'grupoitem', 'familia', 'familiaitem', 'tipo', 'tipomaterial', 'tipodoitem', 'classe', 'classeavaliacao', 'linha', 'subgrupo', 'segmento'],
  tamanho: ['tamanho', 'tam', 'numero', 'num', 'grade', 'medida'],
  quantidadeAtual: ['quantidade', 'qtd', 'saldo', 'saldoatual', 'quantidadeatual', 'estoque', 'estoqueatual', 'qtdestoque', 'disponivel'],
  estoqueMinimo: ['estoqueminimo', 'minimo', 'qtdminima', 'quantidademinima', 'pontoressuprimento'],
  custoUnitario: ['custo', 'custounitario', 'valor', 'valorunitario', 'preco', 'precounitario'],
  status: ['status', 'situacao', 'ativo'],
};

const normalizeItemStatus = (value: string): 'Ativo' | 'Inativo' => {
  const normalized = normalizeImportKey(value);
  if (normalized.includes('inativo') || normalized.includes('bloque') || normalized === 'nao') return 'Inativo';
  return 'Ativo';
};

const inferCategoria = (descricao: string, categoria: string): string => {
  if (categoria) return categoria;

  const text = normalizeImportKey(descricao);
  if (text.includes('camisa') || text.includes('camiseta') || text.includes('polo')) return 'Camisa';
  if (text.includes('calca') || text.includes('bermuda')) return 'Calça';
  if (text.includes('botina') || text.includes('bota') || text.includes('sapato') || text.includes('calcado')) return 'Calçado';
  if (text.includes('luva') || text.includes('capacete') || text.includes('oculos') || text.includes('protetor') || text.includes('epi')) return 'EPI';
  if (text.includes('jaqueta') || text.includes('blusa')) return 'Jaqueta';
  if (text.includes('colete')) return 'Colete';

  return 'Uniforme';
};

export default function EstoquePage() {
  const [estoque, setEstoque] = useState<ItemEstoque[]>(getEstoque());
  const [search, setSearch] = useState('');
  const [filterCategoria, setFilterCategoria] = useState('Todos');
  const [filterStatus, setFilterStatus] = useState('Todos');
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<ItemEstoque | null>(null);
  const [form, setForm] = useState<Partial<ItemEstoque>>({});

  const categorias = useMemo(() => {
    const cats = new Set(estoque.map(e => e.categoria));
    return Array.from(cats);
  }, [estoque]);

  const filtered = useMemo(() => {
    return estoque.filter(e => {
      const matchSearch = search === '' ||
        e.descricao.toLowerCase().includes(search.toLowerCase()) ||
        e.codigo.toLowerCase().includes(search.toLowerCase());
      const matchCat = filterCategoria === 'Todos' || e.categoria === filterCategoria;
      const matchStatus = filterStatus === 'Todos' ||
        (filterStatus === 'Crítico' && e.quantidadeAtual <= e.estoqueMinimo) ||
        (filterStatus === 'Normal' && e.quantidadeAtual > e.estoqueMinimo);
      return matchSearch && matchCat && matchStatus;
    });
  }, [estoque, search, filterCategoria, filterStatus]);

  const reload = () => setEstoque(getEstoque());

  const openNew = () => {
    setEditing(null);
    setForm({ status: 'Ativo', quantidadeAtual: 0, estoqueMinimo: 5, custoUnitario: 0 });
    setModalOpen(true);
  };

  const openEdit = (item: ItemEstoque) => {
    setEditing(item);
    setForm({ ...item });
    setModalOpen(true);
  };

  const handleSave = () => {
    const all = getEstoque();
    if (editing) {
      const idx = all.findIndex(e => e.id === editing.id);
      if (idx >= 0) all[idx] = { ...all[idx], ...form } as ItemEstoque;
    } else {
      all.push({
        id: uuid(),
        codigo: form.codigo || '',
        descricao: form.descricao || '',
        categoria: form.categoria || '',
        tamanho: form.tamanho || '',
        quantidadeAtual: Number(form.quantidadeAtual) || 0,
        estoqueMinimo: Number(form.estoqueMinimo) || 5,
        custoUnitario: Number(form.custoUnitario) || 0,
        status: (form.status as 'Ativo' | 'Inativo') || 'Ativo',
        createdAt: new Date().toISOString(),
      });
    }
    saveEstoque(all);
    reload();
    setModalOpen(false);
  };

  const handleDelete = (id: string) => {
    if (!confirm('Deseja realmente excluir este item?')) return;
    const all = getEstoque().filter(e => e.id !== id);
    saveEstoque(all);
    reload();
  };

  const handleClearAll = () => {
    if (!estoque.length) return;
    const confirmed = confirm('Atenção: esta ação excluirá todos os itens do estoque. Deseja continuar?');
    if (!confirmed) return;
    saveEstoque([]);
    reload();
  };

  const handleImport = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const data = await file.arrayBuffer();
    const wb = XLSX.read(data);
    const ws = wb.Sheets[wb.SheetNames[0]];
    const rows = XLSX.utils.sheet_to_json<ImportRow>(ws, { defval: '', raw: false });

    const all = getEstoque();
    let imported = 0;
    let incomplete = 0;
    rows.forEach(row => {
      const codigo = getImportValue(row, estoqueAliases.codigo);
      const tamanho = getImportValue(row, estoqueAliases.tamanho) || 'Único';
      if (!codigo) return;
      const existing = all.findIndex(e => e.codigo === codigo && e.tamanho === tamanho);
      const quantidadeAtual = getImportNumber(row, estoqueAliases.quantidadeAtual, 0);
      const estoqueMinimo = getImportNumber(row, estoqueAliases.estoqueMinimo, 0);
      const custoUnitario = getImportNumber(row, estoqueAliases.custoUnitario, 0);
      const descricao = getImportValue(row, estoqueAliases.descricao) ||
        getFallbackTextValue(row, [codigo, tamanho, String(quantidadeAtual), String(estoqueMinimo), String(custoUnitario)], ['desc', 'nome', 'texto', 'produto', 'uniforme', 'material']) ||
        `Item ${codigo}`;
      const categoria = inferCategoria(descricao, getImportValue(row, estoqueAliases.categoria));
      const item: ItemEstoque = {
        id: existing >= 0 ? all[existing].id : uuid(),
        codigo,
        descricao,
        categoria,
        tamanho,
        quantidadeAtual,
        estoqueMinimo,
        custoUnitario,
        status: normalizeItemStatus(getImportValue(row, estoqueAliases.status)),
        createdAt: existing >= 0 ? all[existing].createdAt : new Date().toISOString(),
      };
      if (!item.descricao || !item.categoria) incomplete++;
      if (existing >= 0) {
        all[existing] = item;
      } else {
        all.push(item);
      }
      imported++;
    });
    saveEstoque(all);
    reload();
    alert(`${imported} itens importados/atualizados com sucesso!${incomplete ? `\n${incomplete} item(ns) ainda ficaram com algum campo vazio. Verifique os nomes das colunas da planilha.` : ''}`);
    e.target.value = '';
  };

  const updateField = (field: string, value: string | number) => {
    setForm(prev => ({ ...prev, [field]: value }));
  };

  return (
    <div className="space-y-4">
      {/* Toolbar */}
      <div className="bg-white rounded-xl border border-gray-200 p-4">
        <div className="flex flex-col sm:flex-row gap-3 items-start sm:items-center justify-between">
          <div className="flex flex-col sm:flex-row gap-3 flex-1 w-full sm:w-auto">
            <div className="relative flex-1 sm:max-w-xs">
              <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
              <input
                type="text"
                placeholder="Buscar por descrição ou código..."
                value={search}
                onChange={e => setSearch(e.target.value)}
                className="w-full pl-9 pr-4 py-2.5 border border-gray-300 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
              />
            </div>
            <div className="relative">
              <Filter size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
              <select
                value={filterCategoria}
                onChange={e => setFilterCategoria(e.target.value)}
                className="pl-9 pr-8 py-2.5 border border-gray-300 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none appearance-none bg-white"
              >
                <option value="Todos">Todas Categorias</option>
                {categorias.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
            <select
              value={filterStatus}
              onChange={e => setFilterStatus(e.target.value)}
              className="px-4 py-2.5 border border-gray-300 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none appearance-none bg-white"
            >
              <option value="Todos">Todos Níveis</option>
              <option value="Crítico">Estoque Crítico</option>
              <option value="Normal">Estoque Normal</option>
            </select>
          </div>
          <div className="flex gap-2 w-full sm:w-auto">
            <button
              onClick={handleClearAll}
              disabled={estoque.length === 0}
              className="flex items-center gap-2 px-4 py-2.5 bg-red-50 hover:bg-red-100 disabled:bg-gray-100 disabled:text-gray-400 text-red-600 rounded-xl text-sm font-medium transition-colors"
            >
              <Trash2 size={16} />
              <span>Limpar</span>
            </button>
            <label className="flex items-center gap-2 px-4 py-2.5 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-xl text-sm font-medium cursor-pointer transition-colors">
              <Upload size={16} />
              <span>Importar</span>
              <input type="file" accept=".xlsx,.xls,.csv" onChange={handleImport} className="hidden" />
            </label>
            <button onClick={openNew} className="flex items-center gap-2 px-4 py-2.5 bg-[#7b1c16] hover:bg-[#5f1511] text-white rounded-xl text-sm font-medium transition-colors">
              <Plus size={16} />
              <span>Novo</span>
            </button>
          </div>
        </div>
      </div>

      {/* Table */}
      <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-gray-50 border-b border-gray-200">
                <th className="text-left py-3 px-4 font-medium text-gray-500">Código</th>
                <th className="text-left py-3 px-4 font-medium text-gray-500">Descrição</th>
                <th className="text-left py-3 px-4 font-medium text-gray-500 hidden md:table-cell">Categoria</th>
                <th className="text-left py-3 px-4 font-medium text-gray-500">Tamanho</th>
                <th className="text-left py-3 px-4 font-medium text-gray-500">Qtd</th>
                <th className="text-left py-3 px-4 font-medium text-gray-500 hidden lg:table-cell">Mín</th>
                <th className="text-left py-3 px-4 font-medium text-gray-500 hidden lg:table-cell">Custo Unit.</th>
                <th className="text-left py-3 px-4 font-medium text-gray-500">Status</th>
                <th className="text-left py-3 px-4 font-medium text-gray-500">Ações</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map(item => {
                const critico = item.quantidadeAtual <= item.estoqueMinimo;
                return (
                  <tr key={item.id} className={`border-b border-gray-100 hover:bg-gray-50 transition-colors ${critico ? 'bg-red-50/50' : ''}`}>
                    <td className="py-3 px-4 font-mono text-gray-700">{item.codigo}</td>
                    <td className="py-3 px-4 font-medium text-gray-800">
                      <div className="flex items-center gap-2">
                        {item.descricao}
                        {critico && <AlertTriangle size={14} className="text-amber-500" />}
                      </div>
                    </td>
                    <td className="py-3 px-4 text-gray-600 hidden md:table-cell">{item.categoria}</td>
                    <td className="py-3 px-4 text-gray-600">{item.tamanho}</td>
                    <td className="py-3 px-4">
                      <span className={`font-bold ${item.quantidadeAtual === 0 ? 'text-red-600' : critico ? 'text-amber-600' : 'text-gray-700'}`}>
                        {item.quantidadeAtual}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-gray-600 hidden lg:table-cell">{item.estoqueMinimo}</td>
                    <td className="py-3 px-4 text-gray-600 hidden lg:table-cell">R$ {item.custoUnitario.toFixed(2)}</td>
                    <td className="py-3 px-4">
                      {item.quantidadeAtual === 0 ? (
                        <Badge variant="danger">Sem Estoque</Badge>
                      ) : critico ? (
                        <Badge variant="warning">Crítico</Badge>
                      ) : (
                        <Badge variant="success">Normal</Badge>
                      )}
                    </td>
                    <td className="py-3 px-4">
                      <div className="flex gap-1">
                        <button onClick={() => openEdit(item)} className="p-1.5 hover:bg-[#f8e9e6] rounded-lg transition-colors text-[#8b1e18]" title="Editar">
                          <Edit size={15} />
                        </button>
                        <button onClick={() => handleDelete(item.id)} className="p-1.5 hover:bg-red-50 rounded-lg transition-colors text-red-500" title="Excluir">
                          <Trash2 size={15} />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
              {filtered.length === 0 && (
                <tr><td colSpan={9} className="py-12 text-center text-gray-400">Nenhum item encontrado.</td></tr>
              )}
            </tbody>
          </table>
        </div>
        <div className="px-4 py-3 bg-gray-50 border-t border-gray-200 text-sm text-gray-500">
          {filtered.length} item(ns) encontrado(s)
        </div>
      </div>

      {/* Modal */}
      <Modal isOpen={modalOpen} onClose={() => setModalOpen(false)} title={editing ? 'Editar Item' : 'Novo Item'} size="lg">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Código</label>
            <input type="text" value={form.codigo || ''} onChange={e => updateField('codigo', e.target.value)}
              className="w-full px-3 py-2.5 border border-gray-300 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Descrição</label>
            <input type="text" value={form.descricao || ''} onChange={e => updateField('descricao', e.target.value)}
              className="w-full px-3 py-2.5 border border-gray-300 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Categoria</label>
            <input type="text" value={form.categoria || ''} onChange={e => updateField('categoria', e.target.value)}
              className="w-full px-3 py-2.5 border border-gray-300 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Tamanho</label>
            <input type="text" value={form.tamanho || ''} onChange={e => updateField('tamanho', e.target.value)}
              className="w-full px-3 py-2.5 border border-gray-300 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Quantidade Atual</label>
            <input type="number" min="0" value={form.quantidadeAtual ?? 0} onChange={e => updateField('quantidadeAtual', Number(e.target.value))}
              className="w-full px-3 py-2.5 border border-gray-300 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Estoque Mínimo</label>
            <input type="number" min="0" value={form.estoqueMinimo ?? 5} onChange={e => updateField('estoqueMinimo', Number(e.target.value))}
              className="w-full px-3 py-2.5 border border-gray-300 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Custo Unitário (R$)</label>
            <input type="number" min="0" step="0.01" value={form.custoUnitario ?? 0} onChange={e => updateField('custoUnitario', Number(e.target.value))}
              className="w-full px-3 py-2.5 border border-gray-300 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Status</label>
            <select value={form.status || 'Ativo'} onChange={e => updateField('status', e.target.value)}
              className="w-full px-3 py-2.5 border border-gray-300 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none bg-white">
              <option value="Ativo">Ativo</option>
              <option value="Inativo">Inativo</option>
            </select>
          </div>
        </div>
        <div className="flex justify-end gap-3 mt-6 pt-4 border-t border-gray-200">
          <button onClick={() => setModalOpen(false)} className="px-5 py-2.5 text-sm font-medium text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-xl transition-colors">
            Cancelar
          </button>
          <button onClick={handleSave} className="px-5 py-2.5 text-sm font-medium text-white bg-[#7b1c16] hover:bg-[#5f1511] rounded-xl transition-colors">
            {editing ? 'Salvar Alterações' : 'Cadastrar'}
          </button>
        </div>
      </Modal>
    </div>
  );
}
