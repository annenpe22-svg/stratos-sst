import { useState, useMemo } from 'react';
import { Search, Plus, Upload, Edit, Trash2, Filter } from 'lucide-react';
import { v4 as uuid } from 'uuid';
import * as XLSX from 'xlsx';
import Modal from '@/components/ui/Modal';
import Badge from '@/components/ui/Badge';
import { getFuncionarios, saveFuncionarios } from '@/data/store';
import type { Funcionario, SituacaoFuncionario } from '@/types';
import { getImportValue, normalizeImportKey, type ImportRow } from '@/utils/importHelpers';

const situacoes: SituacaoFuncionario[] = ['Ativo', 'Desligado', 'Afastado', 'Suspenso para entrega'];

const situacaoBadge = (s: SituacaoFuncionario) => {
  const map: Record<SituacaoFuncionario, 'success' | 'danger' | 'warning' | 'purple'> = {
    'Ativo': 'success', 'Desligado': 'danger', 'Afastado': 'warning', 'Suspenso para entrega': 'purple'
  };
  return map[s];
};

const funcionarioAliases = {
  matricula: ['matricula', 'matriculafuncionario', 'matriculafuncionario', 'registro', 'chapa', 'codigo', 'codigofuncionario', 'idfuncionario', 'cadastro'],
  nome: ['nome', 'nomecompleto', 'funcionario', 'colaborador', 'nomefuncionario', 'nomedofuncionario', 'nomecolaborador', 'empregado'],
  gerencia: ['gerencia', 'area', 'setor', 'departamento', 'secao', 'seccao', 'lotacao', 'unidade', 'nomedasecao', 'descricaosecao', 'descsecao'],
  turno: ['turno', 'turma', 'escala', 'horario', 'periodo'],
  centroCusto: ['centrocusto', 'centrodecusto', 'cc', 'ccusto', 'codccusto', 'codigocentrocusto', 'centroresultado', 'cr'],
  funcao: ['funcao', 'cargo', 'atividade', 'posto', 'ocupacao', 'nomefuncao', 'descricaofuncao', 'descricaocargo'],
  responsavel: ['responsavel', 'lider', 'supervisor', 'gestor', 'encarregado', 'coordenador', 'chefe', 'responsavellider'],
  situacao: ['situacao', 'status', 'situacaofuncionario', 'statusfuncionario', 'situacaocolaborador', 'condicao'],
};

const normalizeSituacao = (value: string): SituacaoFuncionario => {
  const normalized = normalizeImportKey(value);
  if (normalized.includes('deslig') || normalized.includes('demit')) return 'Desligado';
  if (normalized.includes('afast') || normalized.includes('licenc')) return 'Afastado';
  if (normalized.includes('suspens') || normalized.includes('bloque')) return 'Suspenso para entrega';
  return 'Ativo';
};

export default function FuncionariosPage() {
  const [funcionarios, setFuncionarios] = useState<Funcionario[]>(getFuncionarios());
  const [search, setSearch] = useState('');
  const [filterSituacao, setFilterSituacao] = useState<string>('Todos');
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<Funcionario | null>(null);
  const [form, setForm] = useState<Partial<Funcionario>>({});

  const filtered = useMemo(() => {
    return funcionarios.filter(f => {
      const matchSearch = search === '' ||
        f.nome.toLowerCase().includes(search.toLowerCase()) ||
        f.matricula.includes(search);
      const matchSituacao = filterSituacao === 'Todos' || f.situacao === filterSituacao;
      return matchSearch && matchSituacao;
    });
  }, [funcionarios, search, filterSituacao]);

  const reload = () => setFuncionarios(getFuncionarios());

  const openNew = () => {
    setEditing(null);
    setForm({ situacao: 'Ativo' });
    setModalOpen(true);
  };

  const openEdit = (f: Funcionario) => {
    setEditing(f);
    setForm({ ...f });
    setModalOpen(true);
  };

  const handleSave = () => {
    const all = getFuncionarios();
    if (editing) {
      const idx = all.findIndex(f => f.id === editing.id);
      if (idx >= 0) all[idx] = { ...all[idx], ...form } as Funcionario;
    } else {
      all.push({
        id: uuid(),
        matricula: form.matricula || '',
        nome: form.nome || '',
        gerencia: form.gerencia || '',
        turno: form.turno || '',
        centroCusto: form.centroCusto || '',
        funcao: form.funcao || '',
        responsavel: form.responsavel || '',
        situacao: (form.situacao as SituacaoFuncionario) || 'Ativo',
        createdAt: new Date().toISOString(),
      });
    }
    saveFuncionarios(all);
    reload();
    setModalOpen(false);
  };

  const handleDelete = (id: string) => {
    if (!confirm('Deseja realmente excluir este funcionário?')) return;
    const all = getFuncionarios().filter(f => f.id !== id);
    saveFuncionarios(all);
    reload();
  };

  const handleClearAll = () => {
    if (!funcionarios.length) return;
    const confirmed = confirm('Atenção: esta ação excluirá todos os funcionários cadastrados. Deseja continuar?');
    if (!confirmed) return;
    saveFuncionarios([]);
    reload();
  };

  const handleImport = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const data = await file.arrayBuffer();
    const wb = XLSX.read(data);
    const ws = wb.Sheets[wb.SheetNames[0]];
    const rows = XLSX.utils.sheet_to_json<ImportRow>(ws, { defval: '', raw: false });

    const all = getFuncionarios();
    let imported = 0;
    let incomplete = 0;
    rows.forEach(row => {
      const matricula = getImportValue(row, funcionarioAliases.matricula);
      if (!matricula) return;
      const existing = all.findIndex(f => f.matricula === matricula);
      const func: Funcionario = {
        id: existing >= 0 ? all[existing].id : uuid(),
        matricula,
        nome: getImportValue(row, funcionarioAliases.nome),
        gerencia: getImportValue(row, funcionarioAliases.gerencia),
        turno: getImportValue(row, funcionarioAliases.turno),
        centroCusto: getImportValue(row, funcionarioAliases.centroCusto),
        funcao: getImportValue(row, funcionarioAliases.funcao),
        responsavel: getImportValue(row, funcionarioAliases.responsavel),
        situacao: normalizeSituacao(getImportValue(row, funcionarioAliases.situacao)),
        createdAt: existing >= 0 ? all[existing].createdAt : new Date().toISOString(),
      };
      if (!func.nome || !func.gerencia || !func.turno || !func.centroCusto || !func.funcao) incomplete++;
      if (existing >= 0) {
        all[existing] = func;
      } else {
        all.push(func);
      }
      imported++;
    });
    saveFuncionarios(all);
    reload();
    alert(`${imported} funcionários importados/atualizados com sucesso!${incomplete ? `\n${incomplete} registro(s) ainda ficaram com algum campo vazio. Verifique os nomes das colunas da planilha.` : ''}`);
    e.target.value = '';
  };

  const updateField = (field: string, value: string) => {
    setForm(prev => ({ ...prev, [field]: value }));
  };

  return (
    <div className="space-y-4">
      {/* Toolbar */}
      <div className="bg-white rounded-xl border border-gray-200 p-4">
        <div className="flex flex-col sm:flex-row gap-3 items-start sm:items-center justify-between">
          <div className="flex flex-col sm:flex-row gap-3 flex-1 w-full sm:w-auto">
            <div className="relative flex-1 sm:max-w-xs">
              <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
              <input
                type="text"
                placeholder="Buscar por nome ou matrícula..."
                value={search}
                onChange={e => setSearch(e.target.value)}
                className="w-full pl-9 pr-4 py-2.5 border border-gray-300 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
              />
            </div>
            <div className="relative">
              <Filter size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
              <select
                value={filterSituacao}
                onChange={e => setFilterSituacao(e.target.value)}
                className="pl-9 pr-8 py-2.5 border border-gray-300 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none appearance-none bg-white"
              >
                <option value="Todos">Todas Situações</option>
                {situacoes.map(s => <option key={s} value={s}>{s}</option>)}
              </select>
            </div>
          </div>
          <div className="flex gap-2 w-full sm:w-auto">
            <button
              onClick={handleClearAll}
              disabled={funcionarios.length === 0}
              className="flex items-center gap-2 px-4 py-2.5 bg-red-50 hover:bg-red-100 disabled:bg-gray-100 disabled:text-gray-400 text-red-600 rounded-xl text-sm font-medium transition-colors"
            >
              <Trash2 size={16} />
              <span>Limpar</span>
            </button>
            <label className="flex items-center gap-2 px-4 py-2.5 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-xl text-sm font-medium cursor-pointer transition-colors">
              <Upload size={16} />
              <span>Importar</span>
              <input type="file" accept=".xlsx,.xls,.csv" onChange={handleImport} className="hidden" />
            </label>
            <button onClick={openNew} className="flex items-center gap-2 px-4 py-2.5 bg-[#7b1c16] hover:bg-[#5f1511] text-white rounded-xl text-sm font-medium transition-colors">
              <Plus size={16} />
              <span>Novo</span>
            </button>
          </div>
        </div>
      </div>

      {/* Table */}
      <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-gray-50 border-b border-gray-200">
                <th className="text-left py-3 px-4 font-medium text-gray-500">Matrícula</th>
                <th className="text-left py-3 px-4 font-medium text-gray-500">Nome</th>
                <th className="text-left py-3 px-4 font-medium text-gray-500 hidden md:table-cell">Gerência</th>
                <th className="text-left py-3 px-4 font-medium text-gray-500 hidden lg:table-cell">Turno</th>
                <th className="text-left py-3 px-4 font-medium text-gray-500 hidden lg:table-cell">Centro Custo</th>
                <th className="text-left py-3 px-4 font-medium text-gray-500 hidden xl:table-cell">Função</th>
                <th className="text-left py-3 px-4 font-medium text-gray-500">Situação</th>
                <th className="text-left py-3 px-4 font-medium text-gray-500">Ações</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map(f => (
                <tr key={f.id} className="border-b border-gray-100 hover:bg-gray-50 transition-colors">
                  <td className="py-3 px-4 font-mono text-gray-700">{f.matricula}</td>
                  <td className="py-3 px-4 font-medium text-gray-800">{f.nome}</td>
                  <td className="py-3 px-4 text-gray-600 hidden md:table-cell">{f.gerencia}</td>
                  <td className="py-3 px-4 text-gray-600 hidden lg:table-cell">{f.turno}</td>
                  <td className="py-3 px-4 text-gray-600 hidden lg:table-cell">{f.centroCusto}</td>
                  <td className="py-3 px-4 text-gray-600 hidden xl:table-cell">{f.funcao}</td>
                  <td className="py-3 px-4"><Badge variant={situacaoBadge(f.situacao)}>{f.situacao}</Badge></td>
                  <td className="py-3 px-4">
                    <div className="flex gap-1">
                      <button onClick={() => openEdit(f)} className="p-1.5 hover:bg-[#f8e9e6] rounded-lg transition-colors text-[#8b1e18]" title="Editar">
                        <Edit size={15} />
                      </button>
                      <button onClick={() => handleDelete(f.id)} className="p-1.5 hover:bg-red-50 rounded-lg transition-colors text-red-500" title="Excluir">
                        <Trash2 size={15} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
              {filtered.length === 0 && (
                <tr><td colSpan={8} className="py-12 text-center text-gray-400">Nenhum funcionário encontrado.</td></tr>
              )}
            </tbody>
          </table>
        </div>
        <div className="px-4 py-3 bg-gray-50 border-t border-gray-200 text-sm text-gray-500">
          {filtered.length} funcionário(s) encontrado(s)
        </div>
      </div>

      {/* Modal */}
      <Modal isOpen={modalOpen} onClose={() => setModalOpen(false)} title={editing ? 'Editar Funcionário' : 'Novo Funcionário'} size="lg">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {[
            { label: 'Matrícula', field: 'matricula' },
            { label: 'Nome Completo', field: 'nome' },
            { label: 'Gerência', field: 'gerencia' },
            { label: 'Turno', field: 'turno' },
            { label: 'Centro de Custo', field: 'centroCusto' },
            { label: 'Função', field: 'funcao' },
            { label: 'Responsável/Líder', field: 'responsavel' },
          ].map(({ label, field }) => (
            <div key={field}>
              <label className="block text-sm font-medium text-gray-700 mb-1">{label}</label>
              <input
                type="text"
                value={(form as Record<string, string>)[field] || ''}
                onChange={e => updateField(field, e.target.value)}
                className="w-full px-3 py-2.5 border border-gray-300 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
              />
            </div>
          ))}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Situação</label>
            <select
              value={form.situacao || 'Ativo'}
              onChange={e => updateField('situacao', e.target.value)}
              className="w-full px-3 py-2.5 border border-gray-300 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none bg-white"
            >
              {situacoes.map(s => <option key={s} value={s}>{s}</option>)}
            </select>
          </div>
        </div>
        <div className="flex justify-end gap-3 mt-6 pt-4 border-t border-gray-200">
          <button onClick={() => setModalOpen(false)} className="px-5 py-2.5 text-sm font-medium text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-xl transition-colors">
            Cancelar
          </button>
          <button onClick={handleSave} className="px-5 py-2.5 text-sm font-medium text-white bg-[#7b1c16] hover:bg-[#5f1511] rounded-xl transition-colors">
            {editing ? 'Salvar Alterações' : 'Cadastrar'}
          </button>
        </div>
      </Modal>
    </div>
  );
}
