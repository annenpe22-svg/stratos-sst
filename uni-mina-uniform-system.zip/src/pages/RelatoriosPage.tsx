import { useState, useMemo } from 'react';
import { FileText, Download, FileSpreadsheet } from 'lucide-react';
import { getASOs, getEmpresaConfig, getEntregas, getEstoque, getPedidos, getRegistrosCadastrais, getTreinamentos } from '@/data/store';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import * as XLSX from 'xlsx';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { getSSTStatus } from '@/utils/sst';
import { formatDateBR, getAge, getDateDay, getDateMonth, matchesMonthYear, parseFlexibleDate } from '@/utils/dates';

type ReportType = 'ficha-entrega' | 'posicao-estoque' | 'custo-cc' | 'custo-turma' | 'requisicoes' | 'asos' | 'treinamentos' | 'aniversariantes';

const reports: { id: ReportType; label: string; desc: string }[] = [
  { id: 'ficha-entrega', label: 'Ficha de Entrega', desc: 'Entregas de uniforme por colaborador' },
  { id: 'posicao-estoque', label: 'Posição de Estoque', desc: 'Saldo atual de todos os itens' },
  { id: 'custo-cc', label: 'Custo por Centro de Custo', desc: 'Custos agrupados por centro de custo' },
  { id: 'custo-turma', label: 'Custo por Turno', desc: 'Custos agrupados por turno' },
  { id: 'requisicoes', label: 'Requisições ao Depósito', desc: 'Pedidos aprovados e entregues' },
  { id: 'asos', label: 'ASO', desc: 'Validades e aptidão ocupacional' },
  { id: 'treinamentos', label: 'Treinamentos', desc: 'Capacitações e vencimentos' },
  { id: 'aniversariantes', label: 'Aniversariantes', desc: 'Colaboradores por mês de nascimento' },
];

export default function RelatoriosPage() {
  const [selectedReport, setSelectedReport] = useState<ReportType>('ficha-entrega');
  const [matriculaFilter, setMatriculaFilter] = useState('');
  const [mesFilter, setMesFilter] = useState('');
  const [anoFilter, setAnoFilter] = useState('');
  const empresa = getEmpresaConfig();

  const reportData = useMemo(() => {
    const entregas = getEntregas();
    const estoque = getEstoque();
    const pedidos = getPedidos();
    const asos = getASOs();
    const treinamentos = getTreinamentos();
    const registros = getRegistrosCadastrais();

    const filterByPeriod = (dateStr: string) => {
      return matchesMonthYear(dateStr, mesFilter, anoFilter);
    };

    switch (selectedReport) {
      case 'ficha-entrega': {
        let filtered = entregas.filter(e => filterByPeriod(e.dataEntrega));
        if (matriculaFilter) {
          filtered = filtered.filter(e => e.funcionarioMatricula === matriculaFilter);
        }
        return {
          columns: ['Data', 'Funcionário', 'Matrícula', 'Item', 'Tamanho', 'Qtd'],
          rows: filtered.flatMap(e =>
            e.itens.map(i => [
              formatDateBR(e.dataEntrega),
              e.funcionarioNome,
              e.funcionarioMatricula,
              i.descricao,
              i.tamanho,
              String(i.quantidade),
            ])
          ),
        };
      }
      case 'posicao-estoque': {
        return {
          columns: ['Código', 'Descrição', 'Categoria', 'Tamanho', 'Qtd Atual', 'Mínimo', 'Custo Unit.', 'Status'],
          rows: estoque.map(e => [
            e.codigo, e.descricao, e.categoria, e.tamanho,
            String(e.quantidadeAtual), String(e.estoqueMinimo),
            `R$ ${e.custoUnitario.toFixed(2)}`,
            e.quantidadeAtual <= e.estoqueMinimo ? 'CRÍTICO' : 'Normal',
          ]),
        };
      }
      case 'custo-cc': {
        const custoMap: Record<string, number> = {};
        entregas.filter(e => filterByPeriod(e.dataEntrega)).forEach(ent => {
          const cc = ent.centroCusto || 'N/A';
          ent.itens.forEach(item => {
            const ei = estoque.find(e => e.id === item.itemEstoqueId);
            custoMap[cc] = (custoMap[cc] || 0) + (ei?.custoUnitario || 0) * item.quantidade;
          });
        });
        return {
          columns: ['Centro de Custo', 'Custo Total'],
          rows: Object.entries(custoMap).map(([cc, custo]) => [cc, `R$ ${custo.toFixed(2)}`]),
        };
      }
      case 'custo-turma': {
        const custoMap: Record<string, number> = {};
        pedidos.filter(p => filterByPeriod(p.dataSolicitacao)).forEach(p => {
          const turno = `Turno ${p.turno}`;
          p.itens.forEach(i => {
            custoMap[turno] = (custoMap[turno] || 0) + i.custoUnitario * i.quantidade;
          });
        });
        return {
          columns: ['Turno', 'Custo Total'],
          rows: Object.entries(custoMap).map(([t, c]) => [t, `R$ ${c.toFixed(2)}`]),
        };
      }
      case 'requisicoes': {
        const filtered = pedidos.filter(p =>
          (p.status === 'Aprovado' || p.status === 'Entregue') &&
          filterByPeriod(p.dataSolicitacao)
        );
        return {
          columns: ['Nº Pedido', 'Funcionário', 'Centro Custo', 'Itens', 'Status', 'Data'],
          rows: filtered.map(p => [
            p.numero,
            p.funcionarioNome,
            p.centroCusto,
            p.itens.map(i => `${i.descricao} x${i.quantidade}`).join(', '),
            p.status,
            formatDateBR(p.dataSolicitacao),
          ]),
        };
      }
      case 'asos': {
        let filtered = asos.filter(aso => filterByPeriod(aso.validade || aso.dataExame));
        if (matriculaFilter) filtered = filtered.filter(aso => aso.funcionarioMatricula === matriculaFilter);
        return {
          columns: ['Funcionário', 'Matrícula', 'Tipo', 'Exame', 'Validade', 'Aptidão', 'Status'],
          rows: filtered.map(aso => [
            aso.funcionarioNome,
            aso.funcionarioMatricula,
            aso.tipo,
            formatDateBR(aso.dataExame),
            formatDateBR(aso.validade),
            aso.aptidao,
            getSSTStatus(aso.validade),
          ]),
        };
      }
      case 'treinamentos': {
        let filtered = treinamentos.filter(t => filterByPeriod(t.validade || t.dataRealizacao));
        if (matriculaFilter) filtered = filtered.filter(t => t.funcionarioMatricula === matriculaFilter);
        return {
          columns: ['Funcionário', 'Matrícula', 'Treinamento', 'NR', 'Carga', 'Validade', 'Status'],
          rows: filtered.map(t => [
            t.funcionarioNome,
            t.funcionarioMatricula,
            t.curso,
            t.norma,
            `${t.cargaHoraria}h`,
            formatDateBR(t.validade),
            getSSTStatus(t.validade),
          ]),
        };
      }
      case 'aniversariantes': {
        const filtered = registros
          .filter(registro => registro.dataNascimento)
          .filter(registro => !mesFilter || getDateMonth(registro.dataNascimento) === Number(mesFilter))
          .sort((a, b) => (getDateMonth(a.dataNascimento) || 99) - (getDateMonth(b.dataNascimento) || 99) || (getDateDay(a.dataNascimento) || 99) - (getDateDay(b.dataNascimento) || 99));

        return {
          columns: ['Dia', 'Mês', 'Nome', 'Como prefere ser chamado', 'Cargo', 'Telefone', 'Idade', 'Contato de Emergência'],
          rows: filtered.map(registro => {
            const parsed = parseFlexibleDate(registro.dataNascimento);
            return [
              getDateDay(registro.dataNascimento)?.toString().padStart(2, '0') || '-',
              parsed ? format(parsed, 'MMMM', { locale: ptBR }) : '-',
              registro.nome,
              registro.nomeSocial,
              registro.cargo,
              registro.telefone,
              getAge(registro.dataNascimento)?.toString() || '-',
              registro.contatoEmergencia,
            ];
          }),
        };
      }
      default:
        return { columns: [], rows: [] };
    }
  }, [selectedReport, matriculaFilter, mesFilter, anoFilter]);

  const exportExcel = () => {
    try {
      if (!reportData.rows.length) {
        alert('Não há dados para exportar com os filtros atuais.');
        return;
      }

      const empresaHeader = empresa.nomeFantasia || empresa.razaoSocial || 'Stratos';
      const reportLabel = reports.find(r => r.id === selectedReport)?.label || 'Relatório';
      const generatedAt = `Gerado em: ${format(new Date(), 'dd/MM/yyyy HH:mm', { locale: ptBR })}`;
      const stringRows = reportData.rows.map(row =>
        row.map(cell => (cell === null || cell === undefined ? '' : String(cell)))
      );

      const wsData: string[][] = [
        [empresaHeader],
        [reportLabel],
        [generatedAt],
        [],
        reportData.columns,
        ...stringRows,
      ];

      const ws = XLSX.utils.aoa_to_sheet(wsData);
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, 'Relatorio');

      const wbout = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
      const blob = new Blob([wbout], { type: 'application/octet-stream' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `relatorio_${selectedReport}_${Date.now()}.xlsx`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Falha ao exportar Excel', error);
      alert('Não foi possível gerar o arquivo Excel. Verifique o console para detalhes.');
    }
  };

  const exportPDF = () => {
    try {
      if (!reportData.rows.length) {
        alert('Não há dados para exportar com os filtros atuais.');
        return;
      }

      const doc = new jsPDF({ orientation: 'landscape', unit: 'mm', format: 'a4' });
      let logoOffset = 0;

      if (empresa.logo && /^data:image\/(png|jpe?g);base64/i.test(empresa.logo)) {
        try {
          const formatLogo = empresa.logo.toLowerCase().includes('image/png') ? 'PNG' : 'JPEG';
          doc.addImage(empresa.logo, formatLogo, 14, 10, 30, 15);
          logoOffset = 32;
        } catch (logoError) {
          console.warn('Logo não pôde ser inserida no PDF, prosseguindo sem ela.', logoError);
        }
      }

      const headerX = 14 + logoOffset;
      doc.setFontSize(14);
      doc.text(
        empresa.nomeFantasia || empresa.razaoSocial || 'Sistema Integrado SST - Stratos',
        headerX,
        17
      );
      doc.setFontSize(11);
      doc.text(reports.find(r => r.id === selectedReport)?.label || 'Relatório', headerX, 23);

      doc.setFontSize(8);
      const companyLine = [
        empresa.cnpj ? `CNPJ: ${empresa.cnpj}` : '',
        empresa.telefone,
        empresa.email,
      ].filter(Boolean).join(' | ');
      if (companyLine) doc.text(companyLine, headerX, 28);
      doc.text(
        `Gerado em: ${format(new Date(), 'dd/MM/yyyy HH:mm', { locale: ptBR })}`,
        headerX,
        companyLine ? 33 : 28
      );

      const stringRows = reportData.rows.map(row =>
        row.map(cell => (cell === null || cell === undefined ? '' : String(cell)))
      );

      autoTable(doc, {
        head: [reportData.columns],
        body: stringRows,
        startY: 38,
        margin: { left: 14, right: 14 },
        styles: { fontSize: 8, cellPadding: 2, overflow: 'linebreak' },
        headStyles: { fillColor: [123, 28, 22], textColor: 255, halign: 'left' },
        alternateRowStyles: { fillColor: [248, 233, 230] },
      });

      doc.save(`relatorio_${selectedReport}_${Date.now()}.pdf`);
    } catch (error) {
      console.error('Falha ao exportar PDF', error);
      alert('Não foi possível gerar o PDF. Verifique o console para detalhes.');
    }
  };

  return (
    <div className="space-y-4">
      <div className="bg-white rounded-xl border border-gray-200 p-4 flex flex-col md:flex-row gap-4 md:items-center justify-between">
        <div>
          <p className="text-xs uppercase tracking-[0.2em] text-[#7b1c16] font-semibold">Empresa configurada</p>
          <h2 className="text-lg font-semibold text-gray-900">{empresa.nomeFantasia || empresa.razaoSocial || 'Stratos'}</h2>
          <p className="text-sm text-gray-500">{[empresa.cnpj ? `CNPJ: ${empresa.cnpj}` : '', empresa.cidade, empresa.estado].filter(Boolean).join(' | ') || 'Configure os dados da empresa em Configurações.'}</p>
        </div>
        {empresa.logo && <img src={empresa.logo} alt="Logo da empresa" className="max-h-14 max-w-48 object-contain" />}
      </div>

      {/* Report selector */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 xl:grid-cols-8 gap-3">
        {reports.map(r => (
          <button
            key={r.id}
            onClick={() => setSelectedReport(r.id)}
            className={`p-4 rounded-xl border text-left transition-all ${
              selectedReport === r.id
                ? 'bg-[#7b1c16] text-white border-[#7b1c16] shadow-lg shadow-[#7b1c16]/20'
                : 'bg-white text-gray-700 border-gray-200 hover:border-[#d9b7b1]'
            }`}
          >
            <FileText size={18} className={selectedReport === r.id ? 'text-[#f1d7d2]' : 'text-gray-400'} />
            <p className="font-medium text-sm mt-2">{r.label}</p>
            <p className={`text-xs mt-0.5 ${selectedReport === r.id ? 'text-[#f1d7d2]' : 'text-gray-400'}`}>{r.desc}</p>
          </button>
        ))}
      </div>

      {/* Filters */}
      <div className="bg-white rounded-xl border border-gray-200 p-4">
        <div className="flex flex-wrap gap-3 items-end">
          {(selectedReport === 'ficha-entrega' || selectedReport === 'asos' || selectedReport === 'treinamentos') && (
            <div>
              <label className="block text-xs font-medium text-gray-500 mb-1">Matrícula</label>
              <input
                type="text"
                placeholder="Filtrar por matrícula"
                value={matriculaFilter}
                onChange={e => setMatriculaFilter(e.target.value)}
                className="px-3 py-2 border border-gray-300 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
              />
            </div>
          )}
          <div>
            <label className="block text-xs font-medium text-gray-500 mb-1">Mês</label>
            <select
              value={mesFilter}
              onChange={e => setMesFilter(e.target.value)}
              className="px-3 py-2 border border-gray-300 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none bg-white"
            >
              <option value="">Todos</option>
              {Array.from({ length: 12 }, (_, i) => (
                <option key={i + 1} value={String(i + 1)}>
                  {format(new Date(2024, i, 1), 'MMMM', { locale: ptBR })}
                </option>
              ))}
            </select>
          </div>
          {selectedReport !== 'aniversariantes' && (
          <div>
            <label className="block text-xs font-medium text-gray-500 mb-1">Ano</label>
            <select
              value={anoFilter}
              onChange={e => setAnoFilter(e.target.value)}
              className="px-3 py-2 border border-gray-300 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none bg-white"
            >
              <option value="">Todos</option>
              {Array.from({ length: 7 }, (_, i) => new Date().getFullYear() - 3 + i).map(y => <option key={y} value={String(y)}>{y}</option>)}
            </select>
          </div>
          )}
          <div className="flex gap-2 ml-auto">
            <button onClick={exportExcel} className="flex items-center gap-2 px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-xl text-sm font-medium transition-colors">
              <FileSpreadsheet size={16} />
              Excel
            </button>
            <button onClick={exportPDF} className="flex items-center gap-2 px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-xl text-sm font-medium transition-colors">
              <Download size={16} />
              PDF
            </button>
          </div>
        </div>
      </div>

      {/* Report Table */}
      <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-gray-50 border-b border-gray-200">
                {reportData.columns.map((col, i) => (
                  <th key={i} className="text-left py-3 px-4 font-medium text-gray-500">{col}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {reportData.rows.map((row, i) => (
                <tr key={i} className="border-b border-gray-100 hover:bg-gray-50">
                  {row.map((cell, j) => (
                    <td key={j} className="py-3 px-4 text-gray-700">{cell}</td>
                  ))}
                </tr>
              ))}
              {reportData.rows.length === 0 && (
                <tr>
                  <td colSpan={reportData.columns.length || 1} className="py-12 text-center text-gray-400">
                    Nenhum dado encontrado para os filtros selecionados.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
        <div className="px-4 py-3 bg-gray-50 border-t border-gray-200 text-sm text-gray-500">
          {reportData.rows.length} registro(s)
        </div>
      </div>
    </div>
  );
}
