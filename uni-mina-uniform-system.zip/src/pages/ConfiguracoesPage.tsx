import { useState, type ChangeEvent } from 'react';
import { Building2, Image, RotateCcw, Save, Trash2, Upload } from 'lucide-react';
import StratosLogo from '@/components/brand/StratosLogo';
import { defaultEmpresaConfig, getEmpresaConfig, saveEmpresaConfig } from '@/data/store';
import type { EmpresaConfig } from '@/types';

const fields: Array<{ label: string; field: keyof EmpresaConfig; placeholder?: string; full?: boolean }> = [
  { label: 'Razão Social', field: 'razaoSocial', placeholder: 'Razão social da empresa' },
  { label: 'Nome Fantasia', field: 'nomeFantasia', placeholder: 'Nome de apresentação' },
  { label: 'CNPJ', field: 'cnpj', placeholder: '00.000.000/0000-00' },
  { label: 'Inscrição Estadual', field: 'inscricaoEstadual', placeholder: 'Inscrição estadual' },
  { label: 'Telefone', field: 'telefone', placeholder: '(00) 00000-0000' },
  { label: 'E-mail', field: 'email', placeholder: 'contato@empresa.com.br' },
  { label: 'Site', field: 'site', placeholder: 'https://www.empresa.com.br' },
  { label: 'CEP', field: 'cep', placeholder: '00000-000' },
  { label: 'Endereço', field: 'endereco', placeholder: 'Rua, número e complemento', full: true },
  { label: 'Bairro', field: 'bairro', placeholder: 'Bairro' },
  { label: 'Cidade', field: 'cidade', placeholder: 'Cidade' },
  { label: 'Estado', field: 'estado', placeholder: 'UF' },
  { label: 'Responsável SST', field: 'responsavelSST', placeholder: 'Nome do responsável' },
  { label: 'Cargo do Responsável', field: 'cargoResponsavel', placeholder: 'Cargo/Função' },
];

export default function ConfiguracoesPage() {
  const [form, setForm] = useState<EmpresaConfig>(getEmpresaConfig());
  const [message, setMessage] = useState('');

  const updateField = (field: keyof EmpresaConfig, value: string) => {
    setForm(prev => ({ ...prev, [field]: value }));
  };

  const handleLogo = (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setMessage('Selecione um arquivo de imagem válido para a logo.');
      event.target.value = '';
      return;
    }

    if (file.size > 1.5 * 1024 * 1024) {
      setMessage('A logo deve ter até 1,5 MB para ser salva no navegador.');
      event.target.value = '';
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      setForm(prev => ({ ...prev, logo: String(reader.result || '') }));
      setMessage('Logo carregada. Clique em Salvar configurações para gravar.');
    };
    reader.readAsDataURL(file);
    event.target.value = '';
  };

  const handleSave = () => {
    const payload = { ...form, updatedAt: new Date().toISOString() };
    saveEmpresaConfig(payload);
    setForm(payload);
    setMessage('Configurações da empresa salvas com sucesso.');
  };

  const handleRestoreDefault = () => {
    if (!confirm('Restaurar os dados padrão da Stratos?')) return;
    const payload = { ...defaultEmpresaConfig, updatedAt: new Date().toISOString() };
    saveEmpresaConfig(payload);
    setForm(payload);
    setMessage('Configurações restauradas para o padrão.');
  };

  const addressLine = [form.endereco, form.bairro, form.cidade, form.estado, form.cep].filter(Boolean).join(' - ');

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-xl border border-gray-200 p-5 flex flex-col lg:flex-row gap-4 items-start lg:items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold text-gray-900 flex items-center gap-2">
            <Building2 size={20} />
            Configurações da Empresa
          </h2>
          <p className="text-sm text-gray-500">Cadastre os dados institucionais usados em relatórios, PDFs e identificação do sistema.</p>
        </div>
        <div className="flex flex-col sm:flex-row gap-2 w-full lg:w-auto">
          <button onClick={handleRestoreDefault} className="flex items-center justify-center gap-2 px-4 py-2.5 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-xl text-sm font-medium">
            <RotateCcw size={16} />
            Restaurar padrão
          </button>
          <button onClick={handleSave} className="flex items-center justify-center gap-2 px-4 py-2.5 bg-[#7b1c16] hover:bg-[#5f1511] text-white rounded-xl text-sm font-medium shadow-lg shadow-[#7b1c16]/20">
            <Save size={16} />
            Salvar configurações
          </button>
        </div>
      </div>

      {message && (
        <div className="rounded-xl border border-[#e4c5bf] bg-[#f8e9e6] px-4 py-3 text-sm text-[#7b1c16]">
          {message}
        </div>
      )}

      <div className="grid grid-cols-1 xl:grid-cols-[1fr_360px] gap-6">
        <div className="bg-white rounded-xl border border-gray-200 p-5">
          <h3 className="font-semibold text-gray-900 mb-4">Dados cadastrais</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {fields.map(item => (
              <div key={item.field} className={item.full ? 'md:col-span-2' : ''}>
                <label className="block text-sm font-medium text-gray-700 mb-1">{item.label}</label>
                <input
                  value={String(form[item.field] || '')}
                  onChange={event => updateField(item.field, event.target.value)}
                  placeholder={item.placeholder}
                  className="w-full px-3 py-2.5 border border-gray-300 rounded-xl text-sm focus:ring-2 focus:ring-[#8b1e18] focus:border-[#8b1e18] outline-none"
                />
              </div>
            ))}
            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-1">Observações institucionais</label>
              <textarea
                value={form.observacoes}
                onChange={event => updateField('observacoes', event.target.value)}
                rows={4}
                placeholder="Informações adicionais para documentos e relatórios"
                className="w-full px-3 py-2.5 border border-gray-300 rounded-xl text-sm focus:ring-2 focus:ring-[#8b1e18] focus:border-[#8b1e18] outline-none resize-none"
              />
            </div>
          </div>
        </div>

        <div className="space-y-6">
          <div className="bg-white rounded-xl border border-gray-200 p-5">
            <h3 className="font-semibold text-gray-900 mb-4 flex items-center gap-2">
              <Image size={18} />
              Logo da empresa
            </h3>
            <div className="rounded-xl border border-dashed border-gray-300 bg-[#faf7f4] p-4 flex items-center justify-center min-h-32">
              {form.logo ? (
                <img src={form.logo} alt="Logo da empresa" className="max-h-28 max-w-full object-contain" />
              ) : (
                <StratosLogo size={54} />
              )}
            </div>
            <div className="mt-4 flex gap-2">
              <label className="flex-1 flex items-center justify-center gap-2 px-4 py-2.5 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-xl text-sm font-medium cursor-pointer">
                <Upload size={16} />
                Enviar logo
                <input type="file" accept="image/*" onChange={handleLogo} className="hidden" />
              </label>
              {form.logo && (
                <button onClick={() => updateField('logo', '')} className="px-4 py-2.5 bg-red-50 hover:bg-red-100 text-red-600 rounded-xl" title="Remover logo">
                  <Trash2 size={16} />
                </button>
              )}
            </div>
            <p className="text-xs text-gray-400 mt-3">Formatos aceitos: PNG, JPG, SVG ou WEBP. Tamanho máximo: 1,5 MB.</p>
          </div>

          <div className="bg-white rounded-xl border border-gray-200 p-5">
            <h3 className="font-semibold text-gray-900 mb-4">Pré-visualização</h3>
            <div className="rounded-xl border border-gray-200 bg-[#faf7f4] p-4">
              <div className="flex items-center gap-3">
                {form.logo ? <img src={form.logo} alt="Logo" className="h-12 max-w-36 object-contain" /> : <StratosLogo size={38} />}
              </div>
              <div className="mt-4 space-y-1 text-sm">
                <p className="font-semibold text-gray-900">{form.nomeFantasia || form.razaoSocial || 'Empresa'}</p>
                <p className="text-gray-600">{form.razaoSocial}</p>
                <p className="text-gray-500">{form.cnpj && `CNPJ: ${form.cnpj}`}</p>
                <p className="text-gray-500">{addressLine}</p>
                <p className="text-gray-500">{[form.telefone, form.email].filter(Boolean).join(' | ')}</p>
              </div>
            </div>
            <p className="text-xs text-gray-400 mt-3">Esses dados serão usados no cabeçalho dos relatórios exportados.</p>
          </div>
        </div>
      </div>
    </div>
  );
}