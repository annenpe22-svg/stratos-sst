import { useId } from 'react';

interface StratosLogoProps {
  variant?: 'full' | 'mark';
  className?: string;
  textClassName?: string;
  size?: number;
}

export default function StratosLogo({ variant = 'full', className = '', size = 58 }: StratosLogoProps) {
  const id = useId().replace(/:/g, '');
  const gradientId = `stratosGradient${id}`;
  const maskId = `stratosMask${id}`;

  if (variant === 'mark') {
    return (
      <svg width={size} height={size} viewBox="0 0 140 140" role="img" aria-label="Stratos" className={`shrink-0 ${className}`}>
        <defs>
          <linearGradient id={gradientId} x1="18" y1="16" x2="116" y2="122" gradientUnits="userSpaceOnUse">
            <stop stopColor="#8b3a34" />
            <stop offset="0.55" stopColor="#7b1c16" />
            <stop offset="1" stopColor="#4f1512" />
          </linearGradient>
          <mask id={maskId} maskUnits="userSpaceOnUse">
            <rect width="140" height="140" fill="black" />
            <circle cx="70" cy="70" r="62" fill="white" />
            <path d="M5 52c28-5 58-12 104-38 11 8 20 19 24 32C86 44 49 53 5 69Z" fill="black" />
            <path d="M4 78c43-17 83-24 132-20 0 11-3 22-8 32-43-12-80-7-121 9a62 62 0 0 1-3-21Z" fill="black" />
            <path d="M19 111c30-10 62-13 94-8a62 62 0 0 1-94 8Z" fill="black" />
          </mask>
        </defs>
        <circle cx="70" cy="70" r="62" fill={`url(#${gradientId})`} mask={`url(#${maskId})`} />
      </svg>
    );
  }

  return (
    <svg width={size * 3.74} height={size} viewBox="0 0 704 188" role="img" aria-label="Stratos" className={`shrink-0 ${className}`}>
      <defs>
        <linearGradient id={gradientId} x1="24" y1="18" x2="155" y2="165" gradientUnits="userSpaceOnUse">
          <stop stopColor="#8b3a34" />
          <stop offset="0.55" stopColor="#7b1c16" />
          <stop offset="1" stopColor="#4f1512" />
        </linearGradient>
        <mask id={maskId} maskUnits="userSpaceOnUse">
          <rect width="704" height="188" fill="black" />
          <circle cx="88" cy="94" r="82" fill="white" />
          <path d="M5 70c40-8 78-18 139-52 15 11 26 25 33 42C115 56 65 68 5 91Z" fill="black" />
          <path d="M4 104c58-22 112-32 178-27 0 15-4 30-11 42-58-15-108-9-163 13a82 82 0 0 1-4-28Z" fill="black" />
          <path d="M21 148c42-13 83-17 127-10a82 82 0 0 1-127 10Z" fill="black" />
        </mask>
        <filter id={`textShadow${id}`} x="0" y="0" width="120%" height="120%">
          <feDropShadow dx="0" dy="2" stdDeviation="1" floodColor="#000" floodOpacity="0.18" />
        </filter>
      </defs>
      <circle cx="88" cy="94" r="82" fill={`url(#${gradientId})`} mask={`url(#${maskId})`} />
      <text
        x="210"
        y="128"
        fill="#1f272c"
        fontFamily="Arial Black, Impact, Helvetica, sans-serif"
        fontSize="98"
        fontWeight="900"
        letterSpacing="-5"
        filter={`url(#textShadow${id})`}
      >
        Stratos
      </text>
    </svg>
  );
}