import type { LucideIcon } from 'lucide-react';

interface StatCardProps {
  title: string;
  value: string | number;
  icon: LucideIcon;
  color: 'blue' | 'green' | 'amber' | 'red' | 'purple' | 'indigo' | 'teal' | 'orange';
  subtitle?: string;
  onClick?: () => void;
}

const colorMap = {
  blue: { bg: 'bg-[#f8e9e6]', icon: 'bg-[#7b1c16]', text: 'text-[#7b1c16]' },
  green: { bg: 'bg-emerald-50', icon: 'bg-emerald-500', text: 'text-emerald-600' },
  amber: { bg: 'bg-amber-50', icon: 'bg-amber-500', text: 'text-amber-600' },
  red: { bg: 'bg-[#f8e9e6]', icon: 'bg-[#a12a21]', text: 'text-[#8b1e18]' },
  purple: { bg: 'bg-[#f8e9e6]', icon: 'bg-[#8b1e18]', text: 'text-[#7b1c16]' },
  indigo: { bg: 'bg-[#f8e9e6]', icon: 'bg-[#5f1511]', text: 'text-[#5f1511]' },
  teal: { bg: 'bg-teal-50', icon: 'bg-teal-500', text: 'text-teal-600' },
  orange: { bg: 'bg-[#fff1ed]', icon: 'bg-[#d55242]', text: 'text-[#a12a21]' },
};

export default function StatCard({ title, value, icon: Icon, color, subtitle, onClick }: StatCardProps) {
  const c = colorMap[color];
  return (
    <div
      role={onClick ? 'button' : undefined}
      tabIndex={onClick ? 0 : undefined}
      onClick={onClick}
      onKeyDown={event => {
        if (!onClick) return;
        if (event.key === 'Enter' || event.key === ' ') onClick();
      }}
      className={`bg-white rounded-xl border border-[#e4d8d5] p-5 hover:shadow-md transition-shadow ${onClick ? 'cursor-pointer focus:outline-none focus:ring-2 focus:ring-[#8b1e18]' : ''}`}
    >
      <div className="flex items-center justify-between">
        <div className="flex-1">
          <p className="text-sm font-medium text-gray-500">{title}</p>
          <p className={`text-2xl font-bold mt-1 ${c.text}`}>{value}</p>
          {subtitle && <p className="text-xs text-gray-400 mt-1">{subtitle}</p>}
        </div>
        <div className={`${c.icon} p-3 rounded-xl`}>
          <Icon size={22} className="text-white" />
        </div>
      </div>
    </div>
  );
}
