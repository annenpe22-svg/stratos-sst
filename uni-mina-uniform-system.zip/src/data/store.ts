import type { User, Funcionario, ItemEstoque, Pedido, Entrega, ListaEspera, Movimentacao, Importacao, ASO, Treinamento, RegistroCadastral, EmpresaConfig } from '@/types';
import { generateSeedUsers, generateSeedFuncionarios, generateSeedEstoque, generateSeedPedidos, generateSeedEntregas, generateSeedASOs, generateSeedTreinamentos } from './seed';

const KEYS = {
  users: 'unimina_users',
  funcionarios: 'unimina_funcionarios',
  estoque: 'unimina_estoque',
  pedidos: 'unimina_pedidos',
  entregas: 'unimina_entregas',
  listaEspera: 'unimina_lista_espera',
  asos: 'unimina_asos',
  treinamentos: 'unimina_treinamentos',
  registrosCadastrais: 'unimina_registros_cadastrais',
  empresaConfig: 'unimina_empresa_config',
  movimentacoes: 'unimina_movimentacoes',
  importacoes: 'unimina_importacoes',
  initialized: 'unimina_initialized',
  pedidoCounter: 'unimina_pedido_counter',
};

function load<T>(key: string): T[] {
  const data = localStorage.getItem(key);
  return data ? JSON.parse(data) : [];
}

function save<T>(key: string, data: T[]): void {
  localStorage.setItem(key, JSON.stringify(data));
}

function loadObject<T>(key: string, fallback: T): T {
  const data = localStorage.getItem(key);
  return data ? { ...fallback, ...JSON.parse(data) } : fallback;
}

function saveObject<T>(key: string, data: T): void {
  localStorage.setItem(key, JSON.stringify(data));
}

export const defaultEmpresaConfig: EmpresaConfig = {
  razaoSocial: 'Stratos SST Ltda.',
  nomeFantasia: 'Stratos',
  cnpj: '',
  inscricaoEstadual: '',
  telefone: '',
  email: '',
  site: '',
  endereco: '',
  bairro: '',
  cidade: '',
  estado: '',
  cep: '',
  responsavelSST: '',
  cargoResponsavel: '',
  observacoes: '',
  logo: '',
  updatedAt: new Date().toISOString(),
};

export function initializeStore(): void {
  if (localStorage.getItem(KEYS.initialized)) {
    const funcionarios = getFuncionarios();
    const users = getUsers().map(user => user.username === 'admin' ? { ...user, nome: 'Administrador Stratos' } : user);
    saveUsers(users);
    if (!localStorage.getItem(KEYS.asos)) save(KEYS.asos, generateSeedASOs(funcionarios));
    if (!localStorage.getItem(KEYS.treinamentos)) save(KEYS.treinamentos, generateSeedTreinamentos(funcionarios));
    if (!localStorage.getItem(KEYS.registrosCadastrais)) save(KEYS.registrosCadastrais, []);
    if (!localStorage.getItem(KEYS.empresaConfig)) saveObject(KEYS.empresaConfig, defaultEmpresaConfig);
    return;
  }

  const users = generateSeedUsers();
  const funcionarios = generateSeedFuncionarios();
  const estoque = generateSeedEstoque();
  const pedidos = generateSeedPedidos(funcionarios, estoque);
  const entregas = generateSeedEntregas(funcionarios, estoque);
  const asos = generateSeedASOs(funcionarios);
  const treinamentos = generateSeedTreinamentos(funcionarios);

  save(KEYS.users, users);
  save(KEYS.funcionarios, funcionarios);
  save(KEYS.estoque, estoque);
  save(KEYS.pedidos, pedidos);
  save(KEYS.entregas, entregas);
  save(KEYS.listaEspera, []);
  save(KEYS.asos, asos);
  save(KEYS.treinamentos, treinamentos);
  save(KEYS.registrosCadastrais, []);
  saveObject(KEYS.empresaConfig, defaultEmpresaConfig);
  save(KEYS.movimentacoes, []);
  save(KEYS.importacoes, []);
  localStorage.setItem(KEYS.pedidoCounter, '3');
  localStorage.setItem(KEYS.initialized, 'true');
}

export function resetStore(): void {
  Object.values(KEYS).forEach(k => localStorage.removeItem(k));
  initializeStore();
}

// Users
export const getUsers = (): User[] => load<User>(KEYS.users);
export const saveUsers = (data: User[]) => save(KEYS.users, data);

// Funcionarios
export const getFuncionarios = (): Funcionario[] => load<Funcionario>(KEYS.funcionarios);
export const saveFuncionarios = (data: Funcionario[]) => save(KEYS.funcionarios, data);

// Estoque
export const getEstoque = (): ItemEstoque[] => load<ItemEstoque>(KEYS.estoque);
export const saveEstoque = (data: ItemEstoque[]) => save(KEYS.estoque, data);

// Pedidos
export const getPedidos = (): Pedido[] => load<Pedido>(KEYS.pedidos);
export const savePedidos = (data: Pedido[]) => save(KEYS.pedidos, data);

export function getNextPedidoNumber(): string {
  const counter = parseInt(localStorage.getItem(KEYS.pedidoCounter) || '0') + 1;
  localStorage.setItem(KEYS.pedidoCounter, counter.toString());
  return `PED-${counter.toString().padStart(4, '0')}`;
}

// Entregas
export const getEntregas = (): Entrega[] => load<Entrega>(KEYS.entregas);
export const saveEntregas = (data: Entrega[]) => save(KEYS.entregas, data);

// Lista de Espera
export const getListaEspera = (): ListaEspera[] => load<ListaEspera>(KEYS.listaEspera);
export const saveListaEspera = (data: ListaEspera[]) => save(KEYS.listaEspera, data);

// ASO
export const getASOs = (): ASO[] => load<ASO>(KEYS.asos);
export const saveASOs = (data: ASO[]) => save(KEYS.asos, data);

// Treinamentos
export const getTreinamentos = (): Treinamento[] => load<Treinamento>(KEYS.treinamentos);
export const saveTreinamentos = (data: Treinamento[]) => save(KEYS.treinamentos, data);

// Registros Cadastrais
export const getRegistrosCadastrais = (): RegistroCadastral[] => load<RegistroCadastral>(KEYS.registrosCadastrais);
export const saveRegistrosCadastrais = (data: RegistroCadastral[]) => save(KEYS.registrosCadastrais, data);

// Configuração da empresa
export const getEmpresaConfig = (): EmpresaConfig => loadObject<EmpresaConfig>(KEYS.empresaConfig, defaultEmpresaConfig);
export const saveEmpresaConfig = (data: EmpresaConfig) => saveObject(KEYS.empresaConfig, data);

// Movimentacoes
export const getMovimentacoes = (): Movimentacao[] => load<Movimentacao>(KEYS.movimentacoes);
export const saveMovimentacoes = (data: Movimentacao[]) => save(KEYS.movimentacoes, data);

// Importacoes
export const getImportacoes = (): Importacao[] => load<Importacao>(KEYS.importacoes);
export const saveImportacoes = (data: Importacao[]) => save(KEYS.importacoes, data);
