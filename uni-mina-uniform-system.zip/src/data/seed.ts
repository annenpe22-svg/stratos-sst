import { v4 as uuid } from 'uuid';
import type { User, Funcionario, ItemEstoque, Pedido, Entrega, ASO, Treinamento } from '@/types';

export function generateSeedUsers(): User[] {
  return [
    { id: uuid(), username: 'admin', password: 'admin123', nome: 'Administrador Stratos', role: 'admin' },
    { id: uuid(), username: 'supervisor', password: 'sup123', nome: 'Carlos Eduardo Silva', role: 'supervisor', matricula: '1001' },
    { id: uuid(), username: 'supervisor2', password: 'sup123', nome: 'Maria Fernanda Costa', role: 'supervisor', matricula: '1002' },
  ];
}

export function generateSeedFuncionarios(): Funcionario[] {
  const now = new Date().toISOString();
  return [
    { id: uuid(), matricula: '2001', nome: 'João Pedro Almeida', gerencia: 'Operações', turno: 'A', centroCusto: 'CC-001', funcao: 'Operador de Máquina', responsavel: 'Carlos Eduardo Silva', situacao: 'Ativo', createdAt: now },
    { id: uuid(), matricula: '2002', nome: 'Ana Carolina Santos', gerencia: 'Operações', turno: 'B', centroCusto: 'CC-001', funcao: 'Operadora de Produção', responsavel: 'Carlos Eduardo Silva', situacao: 'Ativo', createdAt: now },
    { id: uuid(), matricula: '2003', nome: 'Rafael Souza Lima', gerencia: 'Manutenção', turno: 'A', centroCusto: 'CC-002', funcao: 'Mecânico Industrial', responsavel: 'Maria Fernanda Costa', situacao: 'Ativo', createdAt: now },
    { id: uuid(), matricula: '2004', nome: 'Fernanda Oliveira', gerencia: 'Logística', turno: 'C', centroCusto: 'CC-003', funcao: 'Auxiliar de Logística', responsavel: 'Maria Fernanda Costa', situacao: 'Ativo', createdAt: now },
    { id: uuid(), matricula: '2005', nome: 'Lucas Martins Pereira', gerencia: 'Operações', turno: 'B', centroCusto: 'CC-001', funcao: 'Operador de Máquina', responsavel: 'Carlos Eduardo Silva', situacao: 'Ativo', createdAt: now },
    { id: uuid(), matricula: '2006', nome: 'Mariana Costa Rocha', gerencia: 'Qualidade', turno: 'A', centroCusto: 'CC-004', funcao: 'Inspetora de Qualidade', responsavel: 'Carlos Eduardo Silva', situacao: 'Ativo', createdAt: now },
    { id: uuid(), matricula: '2007', nome: 'Pedro Henrique Dias', gerencia: 'Manutenção', turno: 'C', centroCusto: 'CC-002', funcao: 'Eletricista', responsavel: 'Maria Fernanda Costa', situacao: 'Afastado', createdAt: now },
    { id: uuid(), matricula: '2008', nome: 'Camila Ribeiro', gerencia: 'Operações', turno: 'A', centroCusto: 'CC-001', funcao: 'Operadora de Produção', responsavel: 'Carlos Eduardo Silva', situacao: 'Desligado', createdAt: now },
    { id: uuid(), matricula: '2009', nome: 'Thiago Ferreira', gerencia: 'Logística', turno: 'B', centroCusto: 'CC-003', funcao: 'Motorista', responsavel: 'Maria Fernanda Costa', situacao: 'Suspenso para entrega', createdAt: now },
    { id: uuid(), matricula: '2010', nome: 'Juliana Mendes', gerencia: 'Operações', turno: 'A', centroCusto: 'CC-001', funcao: 'Supervisora de Turno', responsavel: 'Carlos Eduardo Silva', situacao: 'Ativo', createdAt: now },
    { id: uuid(), matricula: '1001', nome: 'Carlos Eduardo Silva', gerencia: 'Operações', turno: 'A', centroCusto: 'CC-001', funcao: 'Supervisor', responsavel: 'Diretor de Operações', situacao: 'Ativo', createdAt: now },
    { id: uuid(), matricula: '1002', nome: 'Maria Fernanda Costa', gerencia: 'Manutenção', turno: 'B', centroCusto: 'CC-002', funcao: 'Supervisora', responsavel: 'Diretor de Manutenção', situacao: 'Ativo', createdAt: now },
  ];
}

export function generateSeedEstoque(): ItemEstoque[] {
  const now = new Date().toISOString();
  const items: Omit<ItemEstoque, 'id' | 'createdAt'>[] = [
    { codigo: 'UNI-001', descricao: 'Camisa Polo Manga Curta', categoria: 'Camisa', tamanho: 'P', quantidadeAtual: 50, estoqueMinimo: 10, custoUnitario: 45.00, status: 'Ativo' },
    { codigo: 'UNI-001', descricao: 'Camisa Polo Manga Curta', categoria: 'Camisa', tamanho: 'M', quantidadeAtual: 80, estoqueMinimo: 15, custoUnitario: 45.00, status: 'Ativo' },
    { codigo: 'UNI-001', descricao: 'Camisa Polo Manga Curta', categoria: 'Camisa', tamanho: 'G', quantidadeAtual: 60, estoqueMinimo: 15, custoUnitario: 45.00, status: 'Ativo' },
    { codigo: 'UNI-001', descricao: 'Camisa Polo Manga Curta', categoria: 'Camisa', tamanho: 'GG', quantidadeAtual: 30, estoqueMinimo: 10, custoUnitario: 48.00, status: 'Ativo' },
    { codigo: 'UNI-002', descricao: 'Calça Operacional', categoria: 'Calça', tamanho: '38', quantidadeAtual: 25, estoqueMinimo: 5, custoUnitario: 65.00, status: 'Ativo' },
    { codigo: 'UNI-002', descricao: 'Calça Operacional', categoria: 'Calça', tamanho: '40', quantidadeAtual: 40, estoqueMinimo: 8, custoUnitario: 65.00, status: 'Ativo' },
    { codigo: 'UNI-002', descricao: 'Calça Operacional', categoria: 'Calça', tamanho: '42', quantidadeAtual: 35, estoqueMinimo: 8, custoUnitario: 65.00, status: 'Ativo' },
    { codigo: 'UNI-002', descricao: 'Calça Operacional', categoria: 'Calça', tamanho: '44', quantidadeAtual: 20, estoqueMinimo: 5, custoUnitario: 68.00, status: 'Ativo' },
    { codigo: 'UNI-003', descricao: 'Botina de Segurança', categoria: 'Calçado', tamanho: '39', quantidadeAtual: 15, estoqueMinimo: 5, custoUnitario: 120.00, status: 'Ativo' },
    { codigo: 'UNI-003', descricao: 'Botina de Segurança', categoria: 'Calçado', tamanho: '40', quantidadeAtual: 20, estoqueMinimo: 5, custoUnitario: 120.00, status: 'Ativo' },
    { codigo: 'UNI-003', descricao: 'Botina de Segurança', categoria: 'Calçado', tamanho: '41', quantidadeAtual: 18, estoqueMinimo: 5, custoUnitario: 120.00, status: 'Ativo' },
    { codigo: 'UNI-003', descricao: 'Botina de Segurança', categoria: 'Calçado', tamanho: '42', quantidadeAtual: 3, estoqueMinimo: 5, custoUnitario: 120.00, status: 'Ativo' },
    { codigo: 'UNI-003', descricao: 'Botina de Segurança', categoria: 'Calçado', tamanho: '43', quantidadeAtual: 8, estoqueMinimo: 5, custoUnitario: 125.00, status: 'Ativo' },
    { codigo: 'UNI-004', descricao: 'Jaqueta Térmica', categoria: 'Jaqueta', tamanho: 'M', quantidadeAtual: 12, estoqueMinimo: 5, custoUnitario: 150.00, status: 'Ativo' },
    { codigo: 'UNI-004', descricao: 'Jaqueta Térmica', categoria: 'Jaqueta', tamanho: 'G', quantidadeAtual: 10, estoqueMinimo: 5, custoUnitario: 150.00, status: 'Ativo' },
    { codigo: 'UNI-004', descricao: 'Jaqueta Térmica', categoria: 'Jaqueta', tamanho: 'GG', quantidadeAtual: 2, estoqueMinimo: 3, custoUnitario: 155.00, status: 'Ativo' },
    { codigo: 'UNI-005', descricao: 'Luva de Proteção', categoria: 'EPI', tamanho: 'M', quantidadeAtual: 100, estoqueMinimo: 20, custoUnitario: 18.00, status: 'Ativo' },
    { codigo: 'UNI-005', descricao: 'Luva de Proteção', categoria: 'EPI', tamanho: 'G', quantidadeAtual: 85, estoqueMinimo: 20, custoUnitario: 18.00, status: 'Ativo' },
    { codigo: 'UNI-006', descricao: 'Capacete de Segurança', categoria: 'EPI', tamanho: 'Único', quantidadeAtual: 45, estoqueMinimo: 10, custoUnitario: 35.00, status: 'Ativo' },
    { codigo: 'UNI-007', descricao: 'Óculos de Proteção', categoria: 'EPI', tamanho: 'Único', quantidadeAtual: 60, estoqueMinimo: 15, custoUnitario: 22.00, status: 'Ativo' },
    { codigo: 'UNI-008', descricao: 'Colete Refletivo', categoria: 'Colete', tamanho: 'M', quantidadeAtual: 0, estoqueMinimo: 10, custoUnitario: 30.00, status: 'Ativo' },
    { codigo: 'UNI-008', descricao: 'Colete Refletivo', categoria: 'Colete', tamanho: 'G', quantidadeAtual: 5, estoqueMinimo: 10, custoUnitario: 30.00, status: 'Ativo' },
  ];
  return items.map(item => ({ ...item, id: uuid(), createdAt: now }));
}

export function generateSeedPedidos(funcionarios: Funcionario[], estoque: ItemEstoque[]): Pedido[] {
  const now = new Date();
  const pedidos: Pedido[] = [];

  const func1 = funcionarios.find(f => f.matricula === '2001');
  const func2 = funcionarios.find(f => f.matricula === '2003');
  const func3 = funcionarios.find(f => f.matricula === '2005');

  const camisa_m = estoque.find(e => e.codigo === 'UNI-001' && e.tamanho === 'M');
  const calca_42 = estoque.find(e => e.codigo === 'UNI-002' && e.tamanho === '42');
  const botina_41 = estoque.find(e => e.codigo === 'UNI-003' && e.tamanho === '41');
  const jaqueta_g = estoque.find(e => e.codigo === 'UNI-004' && e.tamanho === 'G');

  if (func1 && camisa_m && calca_42) {
    pedidos.push({
      id: uuid(), numero: 'PED-0001',
      supervisorMatricula: '1001', supervisorNome: 'Carlos Eduardo Silva',
      funcionarioMatricula: func1.matricula, funcionarioNome: func1.nome,
      centroCusto: func1.centroCusto, turno: func1.turno, funcao: func1.funcao, gerencia: func1.gerencia,
      dataSolicitacao: new Date(now.getTime() - 3 * 86400000).toISOString(),
      status: 'Pendente',
      itens: [
        { id: uuid(), itemEstoqueId: camisa_m.id, descricao: camisa_m.descricao, tamanho: camisa_m.tamanho, quantidade: 2, custoUnitario: camisa_m.custoUnitario },
        { id: uuid(), itemEstoqueId: calca_42.id, descricao: calca_42.descricao, tamanho: calca_42.tamanho, quantidade: 2, custoUnitario: calca_42.custoUnitario },
      ],
      observacoes: 'Troca periódica de uniforme',
      createdAt: new Date(now.getTime() - 3 * 86400000).toISOString(),
      updatedAt: new Date(now.getTime() - 3 * 86400000).toISOString(),
    });
  }

  if (func2 && botina_41 && jaqueta_g) {
    pedidos.push({
      id: uuid(), numero: 'PED-0002',
      supervisorMatricula: '1002', supervisorNome: 'Maria Fernanda Costa',
      funcionarioMatricula: func2.matricula, funcionarioNome: func2.nome,
      centroCusto: func2.centroCusto, turno: func2.turno, funcao: func2.funcao, gerencia: func2.gerencia,
      dataSolicitacao: new Date(now.getTime() - 5 * 86400000).toISOString(),
      status: 'Aprovado',
      itens: [
        { id: uuid(), itemEstoqueId: botina_41.id, descricao: botina_41.descricao, tamanho: botina_41.tamanho, quantidade: 1, custoUnitario: botina_41.custoUnitario },
        { id: uuid(), itemEstoqueId: jaqueta_g.id, descricao: jaqueta_g.descricao, tamanho: jaqueta_g.tamanho, quantidade: 1, custoUnitario: jaqueta_g.custoUnitario },
      ],
      observacoes: 'Novo colaborador na equipe',
      createdAt: new Date(now.getTime() - 5 * 86400000).toISOString(),
      updatedAt: new Date(now.getTime() - 2 * 86400000).toISOString(),
    });
  }

  if (func3 && camisa_m) {
    pedidos.push({
      id: uuid(), numero: 'PED-0003',
      supervisorMatricula: '1001', supervisorNome: 'Carlos Eduardo Silva',
      funcionarioMatricula: func3.matricula, funcionarioNome: func3.nome,
      centroCusto: func3.centroCusto, turno: func3.turno, funcao: func3.funcao, gerencia: func3.gerencia,
      dataSolicitacao: new Date(now.getTime() - 1 * 86400000).toISOString(),
      status: 'Pendente',
      itens: [
        { id: uuid(), itemEstoqueId: camisa_m.id, descricao: camisa_m.descricao, tamanho: camisa_m.tamanho, quantidade: 3, custoUnitario: camisa_m.custoUnitario },
      ],
      observacoes: '',
      createdAt: new Date(now.getTime() - 1 * 86400000).toISOString(),
      updatedAt: new Date(now.getTime() - 1 * 86400000).toISOString(),
    });
  }

  return pedidos;
}

export function generateSeedEntregas(funcionarios: Funcionario[], estoque: ItemEstoque[]): Entrega[] {
  const entregas: Entrega[] = [];
  const func1 = funcionarios.find(f => f.matricula === '2001');
  const func4 = funcionarios.find(f => f.matricula === '2004');
  const camisa_m = estoque.find(e => e.codigo === 'UNI-001' && e.tamanho === 'M');
  const calca_40 = estoque.find(e => e.codigo === 'UNI-002' && e.tamanho === '40');
  const luva_m = estoque.find(e => e.codigo === 'UNI-005' && e.tamanho === 'M');

  if (func1 && camisa_m && calca_40) {
    entregas.push({
      id: uuid(), pedidoId: '', numeroPedido: 'PED-0000',
      funcionarioMatricula: func1.matricula, funcionarioNome: func1.nome,
      centroCusto: func1.centroCusto,
      itens: [
        { itemEstoqueId: camisa_m.id, descricao: camisa_m.descricao, tamanho: 'M', quantidade: 2 },
        { itemEstoqueId: calca_40.id, descricao: calca_40.descricao, tamanho: '40', quantidade: 2 },
      ],
      dataEntrega: new Date(Date.now() - 60 * 86400000).toISOString(),
      entregaPor: 'Administrador Stratos',
    });
  }

  if (func4 && luva_m) {
    entregas.push({
      id: uuid(), pedidoId: '', numeroPedido: 'PED-PREV',
      funcionarioMatricula: func4.matricula, funcionarioNome: func4.nome,
      centroCusto: func4.centroCusto,
      itens: [
        { itemEstoqueId: luva_m.id, descricao: luva_m.descricao, tamanho: 'M', quantidade: 1 },
      ],
      dataEntrega: new Date(Date.now() - 30 * 86400000).toISOString(),
      entregaPor: 'Administrador Stratos',
    });
  }

  return entregas;
}

export function generateSeedASOs(funcionarios: Funcionario[]): ASO[] {
  const now = new Date();
  const ativos = funcionarios.filter(f => f.situacao === 'Ativo').slice(0, 7);

  return ativos.map((func, index) => {
    const dataExame = new Date(now.getTime() - (40 + index * 22) * 86400000);
    const validade = new Date(now.getTime() + ([20, 48, 95, -10, 180, 12, 260][index] || 120) * 86400000);

    return {
      id: uuid(),
      funcionarioMatricula: func.matricula,
      funcionarioNome: func.nome,
      centroCusto: func.centroCusto,
      funcao: func.funcao,
      tipo: index === 0 ? 'Admissional' : index === 3 ? 'Retorno ao Trabalho' : 'Periódico',
      dataExame: dataExame.toISOString(),
      validade: validade.toISOString(),
      clinica: 'Clínica Integrada SST',
      medico: ['Dra. Helena Duarte', 'Dr. Marcelo Pires', 'Dra. Renata Lima'][index % 3],
      aptidao: index === 5 ? 'Apto com restrição' : 'Apto',
      observacoes: index === 5 ? 'Restrição para trabalho em altura até reavaliação.' : '',
      createdAt: dataExame.toISOString(),
      updatedAt: dataExame.toISOString(),
    } as ASO;
  });
}

export function generateSeedTreinamentos(funcionarios: Funcionario[]): Treinamento[] {
  const now = new Date();
  const cursos = [
    { curso: 'Integração de Segurança', norma: 'SST', horas: 4, validadeDias: 365 },
    { curso: 'EPI - Uso, Guarda e Conservação', norma: 'NR-06', horas: 2, validadeDias: 365 },
    { curso: 'Segurança em Instalações Elétricas', norma: 'NR-10', horas: 40, validadeDias: 730 },
    { curso: 'Máquinas e Equipamentos', norma: 'NR-12', horas: 8, validadeDias: 365 },
    { curso: 'Espaço Confinado', norma: 'NR-33', horas: 16, validadeDias: 365 },
    { curso: 'Trabalho em Altura', norma: 'NR-35', horas: 8, validadeDias: 730 },
  ];

  return funcionarios.filter(f => f.situacao === 'Ativo').slice(0, 9).map((func, index) => {
    const curso = cursos[index % cursos.length];
    const dataRealizacao = new Date(now.getTime() - (60 + index * 30) * 86400000);
    const validadeOffset = [35, 90, -8, 180, 12, 420, 55, -20, 250][index] || curso.validadeDias;
    const validade = new Date(now.getTime() + validadeOffset * 86400000);

    return {
      id: uuid(),
      funcionarioMatricula: func.matricula,
      funcionarioNome: func.nome,
      centroCusto: func.centroCusto,
      funcao: func.funcao,
      curso: curso.curso,
      norma: curso.norma,
      cargaHoraria: curso.horas,
      dataRealizacao: dataRealizacao.toISOString(),
      validade: validade.toISOString(),
      instrutor: ['Equipe SST Stratos', 'Eng. Paulo Nogueira', 'Téc. Segurança Larissa Alves'][index % 3],
      observacoes: '',
      createdAt: dataRealizacao.toISOString(),
      updatedAt: dataRealizacao.toISOString(),
    } as Treinamento;
  });
}
