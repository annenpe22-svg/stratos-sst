import { createContext, useContext, useState, useEffect, type ReactNode } from 'react';
import type { User } from '@/types';
import { getUsers, initializeStore } from '@/data/store';

interface AuthContextType {
  user: User | null;
  login: (username: string, password: string) => boolean;
  logout: () => void;
  isAuthenticated: boolean;
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  login: () => false,
  logout: () => {},
  isAuthenticated: false,
});

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);

  useEffect(() => {
    initializeStore();
    const saved = localStorage.getItem('unimina_session');
    if (saved) {
      try {
        const sessionUser = JSON.parse(saved) as User;
        const normalizedUser = sessionUser.username === 'admin'
          ? { ...sessionUser, nome: 'Administrador Stratos' }
          : sessionUser;
        setUser(normalizedUser);
        localStorage.setItem('unimina_session', JSON.stringify(normalizedUser));
      } catch {
        localStorage.removeItem('unimina_session');
      }
    }
  }, []);

  const login = (username: string, password: string): boolean => {
    const users = getUsers();
    const found = users.find(u => u.username === username && u.password === password);
    if (found) {
      setUser(found);
      localStorage.setItem('unimina_session', JSON.stringify(found));
      return true;
    }
    return false;
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('unimina_session');
  };

  return (
    <AuthContext.Provider value={{ user, login, logout, isAuthenticated: !!user }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);
