export type UserRole = 'admin' | 'supervisor';
export type SituacaoFuncionario = 'Ativo' | 'Desligado' | 'Afastado' | 'Suspenso para entrega';
export type StatusPedido = 'Pendente' | 'Aprovado' | 'Rejeitado' | 'Entregue' | 'Espera' | 'Parcial';
export type TipoEspera = 'Total' | 'Parcial';
export type TipoMovimentacao = 'entrada' | 'saida' | 'ajuste';
export type TipoASO = 'Admissional' | 'Periódico' | 'Retorno ao Trabalho' | 'Mudança de Risco' | 'Demissional';
export type AptidaoASO = 'Apto' | 'Apto com restrição' | 'Inapto';
export type StatusSaudeSeguranca = 'Em dia' | 'A vencer' | 'Vencido' | 'Pendente';
export type TipoSanguineo = 'A+' | 'A-' | 'B+' | 'B-' | 'AB+' | 'AB-' | 'O+' | 'O-';

export interface User {
  id: string;
  username: string;
  password: string;
  nome: string;
  role: UserRole;
  matricula?: string;
}

export interface Funcionario {
  id: string;
  matricula: string;
  nome: string;
  gerencia: string;
  turno: string;
  centroCusto: string;
  funcao: string;
  responsavel: string;
  situacao: SituacaoFuncionario;
  createdAt: string;
}

export interface ItemEstoque {
  id: string;
  codigo: string;
  descricao: string;
  categoria: string;
  tamanho: string;
  quantidadeAtual: number;
  estoqueMinimo: number;
  custoUnitario: number;
  status: 'Ativo' | 'Inativo';
  createdAt: string;
}

export interface PedidoItem {
  id: string;
  itemEstoqueId: string;
  descricao: string;
  tamanho: string;
  quantidade: number;
  custoUnitario: number;
}

export interface Pedido {
  id: string;
  numero: string;
  supervisorMatricula: string;
  supervisorNome: string;
  funcionarioMatricula: string;
  funcionarioNome: string;
  centroCusto: string;
  turno: string;
  funcao: string;
  gerencia: string;
  dataSolicitacao: string;
  status: StatusPedido;
  itens: PedidoItem[];
  observacoes: string;
  createdAt: string;
  updatedAt: string;
}

export interface EntregaItem {
  itemEstoqueId: string;
  descricao: string;
  tamanho: string;
  quantidade: number;
}

export interface Entrega {
  id: string;
  pedidoId: string;
  numeroPedido: string;
  funcionarioMatricula: string;
  funcionarioNome: string;
  centroCusto: string;
  itens: EntregaItem[];
  dataEntrega: string;
  entregaPor: string;
}

export interface ListaEspera {
  id: string;
  pedidoId: string;
  funcionarioMatricula: string;
  funcionarioNome: string;
  turno: string;
  centroCusto: string;
  itemEstoqueId: string;
  descricaoItem: string;
  tamanho: string;
  quantidade: number;
  tipoEspera: TipoEspera;
  dataEntrada: string;
  status: 'Aguardando' | 'Atendido' | 'Cancelado';
}

export interface Movimentacao {
  id: string;
  itemEstoqueId: string;
  descricaoItem: string;
  tipo: TipoMovimentacao;
  quantidade: number;
  motivo: string;
  usuario: string;
  dataHora: string;
}

export interface Importacao {
  id: string;
  tipo: 'funcionarios' | 'estoque' | 'asos' | 'treinamentos';
  arquivo: string;
  registros: number;
  usuario: string;
  dataHora: string;
}

export interface ASO {
  id: string;
  funcionarioMatricula: string;
  funcionarioNome: string;
  centroCusto: string;
  funcao: string;
  tipo: TipoASO;
  dataExame: string;
  validade: string;
  clinica: string;
  medico: string;
  aptidao: AptidaoASO;
  observacoes: string;
  createdAt: string;
  updatedAt: string;
}

export interface Treinamento {
  id: string;
  funcionarioMatricula: string;
  funcionarioNome: string;
  centroCusto: string;
  funcao: string;
  curso: string;
  norma: string;
  cargaHoraria: number;
  dataRealizacao: string;
  validade: string;
  instrutor: string;
  observacoes: string;
  createdAt: string;
  updatedAt: string;
}

export interface RegistroCadastral {
  id: string;
  nome: string;
  nomeSocial: string;
  endereco: string;
  bairro: string;
  cidade: string;
  telefone: string;
  cargo: string;
  turmaSupervisor: string[];
  dataNascimento: string;
  contatoEmergencia: string;
  tipoSanguineo: TipoSanguineo | '';
  foto: string;
  createdAt: string;
  updatedAt: string;
}

export interface EmpresaConfig {
  razaoSocial: string;
  nomeFantasia: string;
  cnpj: string;
  inscricaoEstadual: string;
  telefone: string;
  email: string;
  site: string;
  endereco: string;
  bairro: string;
  cidade: string;
  estado: string;
  cep: string;
  responsavelSST: string;
  cargoResponsavel: string;
  observacoes: string;
  logo: string;
  updatedAt: string;
}
