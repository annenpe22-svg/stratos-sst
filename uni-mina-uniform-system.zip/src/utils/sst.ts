import type { StatusSaudeSeguranca } from '@/types';

export function getSSTStatus(validade: string): StatusSaudeSeguranca {
  if (!validade) return 'Pendente';

  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const due = new Date(validade);
  due.setHours(0, 0, 0, 0);
  const days = Math.ceil((due.getTime() - today.getTime()) / 86400000);

  if (days < 0) return 'Vencido';
  if (days <= 60) return 'A vencer';
  return 'Em dia';
}

export function getSSTStatusVariant(status: StatusSaudeSeguranca): 'default' | 'success' | 'warning' | 'danger' | 'info' | 'purple' {
  const variants = {
    'Em dia': 'success',
    'A vencer': 'warning',
    Vencido: 'danger',
    Pendente: 'default',
  } as const;

  return variants[status];
}

export function toInputDate(value: string): string {
  if (!value) return '';
  return new Date(value).toISOString().slice(0, 10);
}

export function fromInputDate(value: string): string {
  return value ? new Date(`${value}T12:00:00`).toISOString() : '';
}