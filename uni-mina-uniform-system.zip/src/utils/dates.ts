export function parseFlexibleDate(value: string): Date | null {
  if (!value) return null;
  const trimmed = value.trim();

  const brMatch = trimmed.match(/^(\d{1,2})[/-](\d{1,2})[/-](\d{2,4})$/);
  if (brMatch) {
    const day = Number(brMatch[1]);
    const month = Number(brMatch[2]) - 1;
    const year = Number(brMatch[3].length === 2 ? `20${brMatch[3]}` : brMatch[3]);
    const date = new Date(year, month, day, 12);
    return Number.isNaN(date.getTime()) ? null : date;
  }

  const parsed = new Date(trimmed);
  return Number.isNaN(parsed.getTime()) ? null : parsed;
}

export function formatDateBR(value: string): string {
  const parsed = parseFlexibleDate(value);
  return parsed ? parsed.toLocaleDateString('pt-BR') : '-';
}

export function getDateMonth(value: string): number | null {
  const parsed = parseFlexibleDate(value);
  return parsed ? parsed.getMonth() + 1 : null;
}

export function getDateYear(value: string): number | null {
  const parsed = parseFlexibleDate(value);
  return parsed ? parsed.getFullYear() : null;
}

export function getDateDay(value: string): number | null {
  const parsed = parseFlexibleDate(value);
  return parsed ? parsed.getDate() : null;
}

export function getAge(value: string, reference = new Date()): number | null {
  const parsed = parseFlexibleDate(value);
  if (!parsed) return null;
  let age = reference.getFullYear() - parsed.getFullYear();
  const hasNotHadBirthday =
    reference.getMonth() < parsed.getMonth() ||
    (reference.getMonth() === parsed.getMonth() && reference.getDate() < parsed.getDate());
  if (hasNotHadBirthday) age--;
  return age >= 0 ? age : null;
}

export function matchesMonthYear(value: string, monthFilter: string, yearFilter: string): boolean {
  const parsed = parseFlexibleDate(value);
  if (!parsed) return !monthFilter && !yearFilter;
  if (yearFilter && parsed.getFullYear() !== Number(yearFilter)) return false;
  if (monthFilter && parsed.getMonth() + 1 !== Number(monthFilter)) return false;
  return true;
}