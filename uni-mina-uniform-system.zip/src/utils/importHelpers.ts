export type ImportRow = Record<string, unknown>;

export function normalizeImportKey(value: unknown): string {
  return String(value ?? '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/[^a-z0-9]/g, '');
}

export function cleanImportValue(value: unknown): string {
  return String(value ?? '').replace(/\s+/g, ' ').trim();
}

export function getImportValue(row: ImportRow, aliases: string[]): string {
  const normalizedAliases = aliases.map(normalizeImportKey);
  const entries = Object.entries(row);

  for (const [key, value] of entries) {
    if (normalizedAliases.includes(normalizeImportKey(key))) {
      return cleanImportValue(value);
    }
  }

  for (const [key, value] of entries) {
    const normalizedKey = normalizeImportKey(key);
    const isCompatible = normalizedAliases.some(alias =>
      normalizedKey.includes(alias) || (normalizedKey.length > 3 && alias.includes(normalizedKey))
    );
    if (isCompatible) {
      return cleanImportValue(value);
    }
  }

  return '';
}

export function getImportNumber(row: ImportRow, aliases: string[], fallback = 0): number {
  const value = getImportValue(row, aliases);
  if (!value) return fallback;

  const numeric = value.includes(',') && value.lastIndexOf(',') > value.lastIndexOf('.')
    ? value.replace(/[^\d,.-]/g, '').replace(/\./g, '').replace(',', '.')
    : value.replace(/[^\d.-]/g, '');

  const parsed = Number(numeric);
  return Number.isFinite(parsed) ? parsed : fallback;
}

export function getFallbackTextValue(
  row: ImportRow,
  excludedValues: string[] = [],
  preferredKeyHints: string[] = []
): string {
  const excluded = new Set(excludedValues.map(normalizeImportKey).filter(Boolean));
  const entries = Object.entries(row).map(([key, value]) => ({
    key: normalizeImportKey(key),
    value: cleanImportValue(value),
  }));

  const isCandidate = (value: string) => {
    const normalized = normalizeImportKey(value);
    const compact = value.replace(/\s/g, '');
    if (!normalized || excluded.has(normalized)) return false;
    if (normalized.length < 3) return false;
    if (/^\d+([.,]\d+)?$/.test(compact)) return false;
    if (/^r?\$?\d/i.test(compact)) return false;
    if (/^(ativo|inativo|critico|normal|sim|nao|yes|no)$/i.test(normalized)) return false;
    return true;
  };

  const preferredHints = preferredKeyHints.map(normalizeImportKey);
  const preferred = entries.find(entry =>
    preferredHints.some(hint => entry.key.includes(hint)) && isCandidate(entry.value)
  );

  if (preferred) return preferred.value;

  return entries.find(entry => isCandidate(entry.value))?.value || '';
}